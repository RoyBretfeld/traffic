def test_smoke():
    assert 2 + 2 == 4