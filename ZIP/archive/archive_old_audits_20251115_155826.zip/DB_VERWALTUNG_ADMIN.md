# DB-Verwaltung im Admin-Bereich

**Datum:** 2025-01-13  
**Feature:** Batch-Geocoding und DB-Verwaltung im Admin-Dashboard  
**Status:** ✅ Implementiert

## Übersicht

Neue Funktionalität im Admin-Bereich, um Tourenpläne hochzuladen, Adressen automatisch zu geocodieren und die Ergebnisse direkt in die Datenbank zu speichern.

## Features

### 1. ✅ Batch-Geocoding

**Upload mehrerer CSV-Dateien:**
- Drag & Drop oder Dateiauswahl
- Unterstützt mehrere Dateien gleichzeitig
- Automatische Geocodierung aller Adressen
- Speicherung direkt in `geo_cache` Tabelle

**Encoding-Support:**
- Erkennt CP850 (Windows-Standard)
- Fallback auf UTF-8
- Robuste Fehlerbehandlung bei kaputten Zeilen

### 2. ✅ Liste verfügbarer Tourenpläne

**Anzeige:**
- Alle CSV-Dateien im `Tourplaene/` Verzeichnis
- Zeigt: Dateiname, Kundenanzahl, Geocode-Status
- Geocoding-Rate in Prozent
- Button zum einzelnen Geocodieren

### 3. ✅ Einzelne Tourenpläne geocodieren

**Funktionalität:**
- Klick auf "Geocodieren" Button
- Verarbeitet nur die ausgewählte Datei
- Live-Fortschrittsanzeige
- Ergebnisstatistiken

### 4. ✅ Alle Tourenpläne geocodieren

**Bulk-Operation:**
- Geocodiert alle verfügbaren Tourenpläne
- Sicherheitsabfrage ("Wirklich ALLE?")
- Sequentielle Verarbeitung
- Gesamtstatistiken über alle Dateien

### 5. ✅ DB-Statistiken

**Live-Metriken:**
- **Kunden gesamt**: Anzahl aller Kundendatensätze
- **Geocodiert**: Anzahl mit Koordinaten
- **Fehlend**: Anzahl ohne Koordinaten
- **Geocoding-Rate**: Prozentsatz der geocodierten Kunden

## Frontend-Implementierung

### HTML-Struktur

**Neuer Tab "DB-Verwaltung":**
```html
<li class="nav-item" role="presentation">
    <button class="nav-link" id="db-tab" 
            data-bs-toggle="tab" data-bs-target="#db">
        <i class="fas fa-database"></i> DB-Verwaltung
    </button>
</li>
```

**Sections:**
1. **Upload-Bereich**: File-Input mit Upload-Button
2. **Tourenpläne-Liste**: Scrollbare Liste mit Geocode-Buttons
3. **Fortschrittsanzeige**: Progress-Bar und Status-Meldungen
4. **Ergebnis-Karten**: 4 Metriken (Erfolgreich, Übersprungen, Fehler, Gesamt)
5. **DB-Statistiken**: 4 Karten mit Live-Metriken

### JavaScript-Funktionen

```javascript
// Hauptfunktionen
uploadTourplansForGeocoding()     // Upload und Batch-Geocoding
loadAvailableTourplans()          // Lade Tourenpläne-Liste
geocodeSingleTourplan(filename)   // Geocode einzelne Datei
geocodeAllTourplans()             // Geocode alle Dateien
loadDBStats()                     // Lade DB-Statistiken

// Helper-Funktionen
updateGeocodingProgress(current, total, percent)
updateGeocodingStatus(message, type)
```

**Features:**
- Async/Await für alle API-Calls
- Try-Catch Fehlerbehandlung
- Progress-Updates in Echtzeit
- Automatisches Neuladen nach Geocoding

## Backend-Implementierung

### Neue Datei: `backend/routes/db_management_api.py`

**Endpunkte:**

#### 1. POST `/api/tourplan/batch-geocode`
```python
async def batch_geocode_tourplan(file: UploadFile = File(...)):
    """
    Lädt einen Tourplan hoch, geocodiert alle Adressen 
    und speichert sie in die DB.
    """
```

**Logik:**
- Speichert Datei in `Tourplaene/` Verzeichnis
- Liest CSV mit `pandas` (CP850 Encoding)
- Validiert Spalten (Name, Straße, PLZ, Ort)
- Geocodiert jede Adresse mit `geocode_address()`
- Speichert in `geo_cache` mit `geo_upsert()`
- Zählt Erfolge, Übersprungen, Fehler

**Response:**
```json
{
  "success": true,
  "total_customers": 150,
  "geocoded_count": 145,
  "skipped_count": 3,
  "error_count": 2
}
```

#### 2. GET `/api/tourplan/list`
```python
async def list_tourplans():
    """
    Gibt eine Liste aller verfügbaren Tourenpläne zurück.
    """
```

**Logik:**
- Scannt `Tourplaene/` Verzeichnis nach `*.csv`
- Liest jede Datei für Statistiken
- Zählt Kunden und geocodierte Einträge
- Berechnet Geocoding-Rate

**Response:**
```json
{
  "success": true,
  "tourplans": [
    {
      "filename": "tour_2025-01-13.csv",
      "customer_count": 150,
      "geocoded_count": 145,
      "geocode_rate": 96.7
    }
  ]
}
```

#### 3. POST `/api/tourplan/geocode-file`
```python
async def geocode_single_file(request: GeocodeFileRequest):
    """
    Geocodiert einen einzelnen Tourplan 
    (aus dem Tourplaene-Verzeichnis).
    """
```

**Request Body:**
```json
{
  "filename": "tour_2025-01-13.csv"
}
```

**Logik:**
- Prüft ob Datei existiert (404 wenn nicht)
- Liest CSV und geocodiert alle Adressen
- Speichert in DB
- Gibt Statistiken zurück

#### 4. GET `/api/db/stats`
```python
async def get_db_stats():
    """
    Gibt DB-Statistiken zurück (Kunden, Geocodes, etc.).
    """
```

**Logik:**
- Verbindet zu `customers.db` (ENGINE)
- Zählt Kunden total
- Zählt geocodierte Kunden (WHERE lat/lon NOT NULL)
- Berechnet Fehlende und Rate

**Response:**
```json
{
  "success": true,
  "total_customers": 5000,
  "geocoded_customers": 4850,
  "missing_geocodes": 150,
  "geocode_rate": 97.0
}
```

### Router-Registrierung

**In `backend/app_setup.py`:**
```python
from backend.routes.db_management_api import router as db_management_api_router

# In setup_routers():
routers = [
    # ... andere Router ...
    system_rules_api_router,
    db_management_api_router
]
```

## Technische Details

### Geocoding-Strategie

**3-stufiger Lookup:**
1. **DB-Cache**: Prüfe `geo_cache` Tabelle
2. **Geoapify API**: Falls nicht in DB, geocodiere mit API
3. **Speichere**: Erfolgreiche Geocodes in DB für spätere Verwendung

**Vorteile:**
- Reduziert API-Calls (spart Kosten)
- Schnellere Verarbeitung (DB-Lookup)
- Persistente Speicherung

### CSV-Parsing

**Robuste Implementierung:**
```python
df = pd.read_csv(
    file_path, 
    sep=';', 
    encoding='cp850',  # Windows-Standard
    on_bad_lines='skip'  # Ignoriere kaputte Zeilen
)
```

**Spalten-Validierung:**
```python
required_cols = ['Name', 'Straße', 'PLZ', 'Ort']
missing_cols = [col for col in required_cols if col not in df.columns]
if missing_cols:
    return error_response(f"Fehlende Spalten: {', '.join(missing_cols)}")
```

### Error Handling

**Frontend:**
- Try-Catch für alle API-Calls
- User-friendly Fehlermeldungen
- Automatische Retry-Logik (manuell)

**Backend:**
- Logging für alle Fehler
- Safe-Print für Console-Output (UnicodeEncodeError-Safe)
- HTTP-Status-Codes: 200 (OK), 400 (Bad Request), 404 (Not Found), 500 (Internal Error)

## Verbesserungen gegenüber bestehenden Systemen

### Vorher (Index.html Workflow)
- Geocoding nur bei Tour-Upload
- Keine Batch-Verarbeitung
- Keine Statistiken
- Keine Admin-Kontrolle

### Nachher (Admin DB-Verwaltung)
- ✅ Dediziertes Batch-Geocoding
- ✅ Vorab-Geocoding vor Tour-Upload
- ✅ Live-Statistiken
- ✅ Admin-gesteuerter Prozess
- ✅ Bulk-Operationen

## Verwendung

### 1. CSV-Dateien hochladen

1. Admin-Bereich öffnen (`/admin.html`)
2. Tab "DB-Verwaltung" auswählen
3. CSV-Dateien auswählen (mehrere möglich)
4. "Hochladen" Button klicken
5. Fortschritt beobachten
6. Ergebnisse prüfen

### 2. Bestehende Tourenpläne geocodieren

1. "Liste aktualisieren" klicken
2. Einzelne Datei: "Geocodieren" Button
3. Alle Dateien: "Alle geocodieren" Button
4. Bestätigung bei "Alle geocodieren"
5. Fortschritt und Ergebnisse prüfen

### 3. DB-Statistiken prüfen

1. Automatisches Laden beim Tab-Öffnen
2. "Statistiken aktualisieren" für Refresh
3. Zeigt: Total, Geocodiert, Fehlend, Rate

## Zukünftige Erweiterungen

**Mögliche Features:**
- ⏭️ Export-Funktion (Geocodierte Daten als CSV)
- ⏭️ Geocoding-Queue für große Datenmengen
- ⏭️ Rate-Limiting für API-Calls
- ⏭️ Geocoding-Log (Audit-Trail)
- ⏭️ Fehlerhafte Adressen manuell bearbeiten
- ⏭️ Bulk-Update von Koordinaten
- ⏭️ Geocoding-Validierung (Plausibilitäts-Check)

## Testing

**Manuelle Tests:**
1. Upload von 1 CSV-Datei → Erfolg?
2. Upload von mehreren CSV-Dateien → Erfolg?
3. Geocoding einzelner Tourplan → Statistiken korrekt?
4. "Alle geocodieren" → Alle verarbeitet?
5. DB-Statistiken → Zahlen plausibel?
6. Fehlende Spalten → Fehlermeldung?
7. Encoding (Umlaute) → Korrekt dargestellt?

## Zusammenfassung

Die DB-Verwaltung im Admin-Bereich bietet eine benutzerfreundliche und effiziente Möglichkeit, Tourenpläne zu geocodieren und die Datenbank zu pflegen. Die Implementierung ist robust, gut dokumentiert und bereit für den produktiven Einsatz.

**Vorteile:**
- ✅ Batch-Geocoding spart Zeit
- ✅ DB-Cache reduziert API-Calls
- ✅ Live-Statistiken für Transparenz
- ✅ Admin-Kontrolle für Datenqualität
- ✅ Robuste Fehlerbehandlung

