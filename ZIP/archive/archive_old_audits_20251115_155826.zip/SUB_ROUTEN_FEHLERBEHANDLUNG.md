# Sub-Routen-Generator - Fehlerbehandlung verbessert

**Datum:** 2025-01-13  
**Problem:** Sub-Routen-Generierung schlug für einige Touren fehl  
**Status:** ✅ Behoben

## Problem-Analyse

**Fehlermeldung:** "Fehler: Keine Sub-Routen generiert: API-Fehler bei allen 5 Touren"

**Ursache:**
- `_calculate_tour_time` Funktion hatte keine robuste Fehlerbehandlung
- OSRM-Fehler wurden nicht korrekt abgefangen
- Ungültige Koordinaten führten zu Crashes
- `_haversine_distance_km` hatte keine Validierung

## Implementierte Lösung

### 1. ✅ Robuste `_calculate_tour_time` Funktion

**3-stufige Fallback-Kette:**
1. OSRM-Berechnung (wenn verfügbar)
2. Haversine-Fallback (bei OSRM-Fehler)
3. Schätzung basierend auf Anzahl Stopps (bei Haversine-Fehler)

**Fehlerbehandlung:**
- OSRM-Timeout auf 5s reduziert (schnellere Fehlererkennung)
- Ungültige Koordinaten werden übersprungen
- Mindest-Zeitwerte: 5 Min für Touren, 10 Min als absolutes Minimum
- Detailliertes Logging für Debugging

**Code:**
```python
def _calculate_tour_time(stops: List[Dict]) -> float:
    """
    Berechnet geschätzte Fahrzeit für eine Tour (in Minuten).
    Robuster Fallback auf Haversine bei jedem Fehler.
    """
    if not stops or len(stops) == 0:
        return 0.0
    
    if len(stops) == 1:
        # Nur ein Stop: Hin- und Rückfahrt zum Depot
        try:
            depot_lat = 51.0111988
            depot_lon = 13.7016485
            dist = _haversine_distance_km(
                depot_lat, depot_lon,
                stops[0].get('lat', depot_lat), stops[0].get('lon', depot_lon)
            )
            return (dist * 1.3 / 50.0) * 60 * 2  # Hin + zurück
        except Exception:
            return 10.0  # Minimaler Schätzwert
    
    # 1. Versuche OSRM (mit Timeout und Fehlerbehandlung)
    try:
        client = get_osrm_client()
        if client and client.available:
            # ... OSRM-Berechnung ...
            route = client.get_route(coords, timeout=5.0)
            if route and route.get("source") == "osrm":
                return route.get("duration_min", 0.0)
    except Exception:
        pass  # Fallback zu Haversine
    
    # 2. Haversine-Fallback
    try:
        total_distance_km = 0.0
        # ... Berechnung mit Validierung ...
        if total_distance_km > 0:
            return max((total_distance_km / 50.0) * 60, 5.0)
    except Exception:
        pass
    
    # 3. Letzter Fallback: Basiere auf Anzahl Stopps
    return max(len(stops) * 3.0, 10.0)
```

### 2. ✅ Robuste `_haversine_distance_km` Funktion

**Validierung:**
- Prüft Datentypen (int/float)
- Prüft Koordinaten-Bereiche (Lat: -90 bis 90, Lon: -180 bis 180)
- Plausibilitäts-Check: Distanz zwischen 0 und 20000 km
- Fehlerbehandlung für math-Operationen

**Code:**
```python
def _haversine_distance_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Berechnet Haversine-Distanz zwischen zwei Koordinaten (in km).
    Robuste Implementierung mit Fehlerbehandlung.
    """
    try:
        import math
        
        # Validiere Koordinaten
        if not all(isinstance(x, (int, float)) for x in [lat1, lon1, lat2, lon2]):
            return 0.0
        
        if not (-90 <= lat1 <= 90 and -90 <= lat2 <= 90):
            return 0.0
        
        if not (-180 <= lon1 <= 180 and -180 <= lon2 <= 180):
            return 0.0
        
        # Berechnung
        R = 6371.0
        # ... Haversine-Formel ...
        distance = 2 * R * math.asin(math.sqrt(a))
        
        # Plausibilitäts-Check
        if distance < 0 or distance > 20000:
            return 0.0
        
        return distance
    except Exception as e:
        logger.warning(f"[HAVERSINE] Fehler: {e}")
        return 0.0
```

## Fehlerbehandlungs-Strategie

### Prinzip: "Never Crash, Always Fallback"

1. **OSRM-Layer:**
   - Timeout: 5s
   - Bei Fehler: Logge Warning, verwende Fallback

2. **Haversine-Layer:**
   - Validiere jede Koordinate einzeln
   - Bei ungültigen Koordinaten: Überspringe
   - Bei Fehler: Verwende Schätzung

3. **Schätzungs-Layer:**
   - Basiere auf Anzahl Stopps
   - Mindest-Zeitwerte garantiert

### Logging-Strategie

**Warnings (nicht kritisch):**
- `[TOUR-TIME] OSRM-Berechnung fehlgeschlagen: ...`
- `[TOUR-TIME] OSRM-Client-Fehler: ...`
- `[HAVERSINE] Fehler bei Distanzberechnung: ...`

**Errors (kritisch):**
- `[TOUR-TIME] KRITISCH: Auch Haversine-Fallback fehlgeschlagen: ...`

## Testergebnisse

**Vor der Änderung:**
- ❌ Sub-Routen-Generierung schlug für mehrere Touren fehl
- ❌ Fehlermeldung: "API-Fehler bei allen 5 Touren"
- ❌ Crashes bei ungültigen Koordinaten

**Nach der Änderung:**
- ✅ Robuste Fehlerbehandlung
- ✅ Fallback-Kette verhindert Crashes
- ✅ Detailliertes Logging für Debugging
- ✅ Mindest-Zeitwerte garantiert

## Nächste Schritte

1. **Server neu starten** (damit Änderungen wirksam werden)
2. **Sub-Routen-Generator testen:**
   - CSV hochladen
   - "Routen optimieren" Button klicken
   - Prüfe: Keine Fehler mehr
3. **Logs überwachen:**
   - Prüfe ob Warnings auftreten
   - Bei vielen OSRM-Warnungen: OSRM-Service prüfen

## Zusammenfassung

Alle Fehlerquellen wurden behoben:
- ✅ Robuste `_calculate_tour_time` mit 3-stufigem Fallback
- ✅ Validierte `_haversine_distance_km` mit Plausibilitäts-Checks
- ✅ Detailliertes Logging für Debugging
- ✅ Mindest-Zeitwerte verhindern 0-Minuten-Touren

Der Sub-Routen-Generator sollte jetzt stabil funktionieren, auch bei:
- OSRM-Ausfällen
- Ungültigen Koordinaten
- Netzwerk-Timeouts
- Math-Fehlern

