# Debug-Logging massiv erweitert

**Datum:** 2025-01-13  
**Problem:** Fehler sind nicht aussagekräftig genug  
**Lösung:** Umfangreiches Debug-Logging in `workflow_api.py`

## Hinzugefügte Debug-Ausgaben

### 1. **Request-Start (mit Trace-ID)**
```
================================================================================
[TOUR-OPTIMIZE] 🚀 START - Trace-ID: abc123de
================================================================================
[TOUR-OPTIMIZE] 📥 Request empfangen:
  • Tour ID: W-07.00
  • BAR Tour: false
  • Anzahl Stopps: 45
  • Trace-ID: abc123de
```

### 2. **Koordinaten-Validierung**
```
[TOUR-OPTIMIZE] 📍 Koordinaten-Check:
  • Gesamt Stopps: 45
  • Mit Koordinaten: 42
  • Ohne Koordinaten: 3
```

Bei fehlenden Koordinaten:
```
[TOUR-OPTIMIZE] ⚠️ KEIN STOP HAT KOORDINATEN!
  Stop 0: lat=None, lon=None, name=Max Mustermann GmbH
  Stop 1: lat=None, lon=None, name=Beispiel AG
  Stop 2: lat=None, lon=None, name=Demo KG
```

### 3. **Optimierungs-Phase**
```
[TOUR-OPTIMIZE] 🔄 Starte Optimierung für Tour W-07.00...
[TOUR-OPTIMIZE] 📊 Verwende 42 valide Stopps
[TOUR-OPTIMIZE] 🎯 Methode: optimize_tour_stops() (Backup-Version)
[TOUR-OPTIMIZE] ⚙️ Versuche Optimierung...
```

**LLM aktiviert:**
```
[TOUR-OPTIMIZE] 🤖 LLM ist aktiviert, versuche LLM-Optimizer...
[TOUR-OPTIMIZE] 🔄 Rufe llm_optimizer.optimize_route() auf...
[TOUR-OPTIMIZE] ✅ LLM-Optimierung ERFOLGREICH!
  • Methode: gpt-4o-mini
  • Optimierte Stopps: 42
```

**LLM Fallback:**
```
[TOUR-OPTIMIZE] ⚠️ LLM-FEHLER: ConnectionError: API not reachable
[TOUR-OPTIMIZE] 🔄 Fallback auf Nearest-Neighbor...
[TOUR-OPTIMIZE] ✅ Nearest-Neighbor abgeschlossen: 42 Stopps
```

**LLM deaktiviert:**
```
[TOUR-OPTIMIZE] ℹ️ LLM ist DEAKTIVIERT
[TOUR-OPTIMIZE] 🔄 Verwende Nearest-Neighbor direkt...
[TOUR-OPTIMIZE] ✅ Nearest-Neighbor abgeschlossen: 42 Stopps
```

### 4. **Stopps-Kopie**
```
[TOUR-OPTIMIZE] 📋 Erstelle Stopps-Kopien...
[TOUR-OPTIMIZE] 📦 Optimierte Stopps: 42
```

Wenn fehlerhaft:
```
[TOUR-OPTIMIZE] ❌ KRITISCH: Optimierung gab KEINE Stopps zurück!
```

### 5. **Zeitberechnung**
```
[TOUR-OPTIMIZE] ⏱️ Berechne Zeitbudget...
  • Fahrzeit: 45.3 Min
  • Servicezeit: 84 Min
  • Gesamtzeit: 129.3 Min
```

Mit Fehler:
```
[TOUR-OPTIMIZE] ⚠️ Fehler bei _calculate_tour_time: ValueError: invalid coordinates
  • Fahrzeit (Fallback): 126.0 Min
```

### 6. **Variablen-Validierung**
```
[TOUR-OPTIMIZE] 🔍 Validiere Variablen...
[TOUR-OPTIMIZE] ✅ Alle Variablen validiert
```

Wenn fehlende Variablen:
```
[TOUR-OPTIMIZE] ⚠️ estimated_driving_time fehlt, berechne neu...
  • Neu berechnet: 45.3 Min
[TOUR-OPTIMIZE] ⚠️ reasoning fehlt, setze Default
[TOUR-OPTIMIZE] ⚠️ method fehlt, setze 'unknown'
```

### 7. **Sub-Touren**
```
[TOUR-OPTIMIZE] 📦 Prüfe Timebox-Bedingungen...
  • Estimated Total Time: 129.3 Min
[TOUR-OPTIMIZE] ✅ Response enthält 3 Sub-Touren
```

Oder:
```
[TOUR-OPTIMIZE] ℹ️ Keine Aufteilung nötig (is_split=false)
```

### 8. **Erfolgreicher Abschluss**
```
================================================================================
[TOUR-OPTIMIZE] ✅ ERFOLGREICH ABGESCHLOSSEN - Trace-ID: abc123de
  • Tour ID: W-07.00
  • Optimierte Stopps: 42
  • Methode: nearest_neighbor
  • Gesamtzeit: 129.3 Min
  • Aufgeteilt: false
================================================================================
```

### 9. **Kritischer Fehler**
```
[TOUR-OPTIMIZE] ❌❌❌ KRITISCHER FEHLER bei Optimierung ❌❌❌
  • Exception-Typ: ValueError
  • Fehlermeldung: invalid coordinates: lat=None
  • Tour ID: W-07.00
  • Anzahl valid_stops: 42
[TOUR-OPTIMIZE] 📋 Vollständiger Traceback:
Traceback (most recent call last):
  File "...", line 123, in optimize_tour_with_ai
    ...
ValueError: invalid coordinates: lat=None

[TOUR-OPTIMIZE] 🚨 KRITISCHER FALLBACK: Verwende Identität (Original-Reihenfolge)
  • Fallback Stopps: 42
```

### 10. **Exception-Handler**

**HTTPException:**
```
================================================================================
[TOUR-OPTIMIZE] ⚠️ HTTPException abgefangen
  • Status Code: 503
  • Detail: OSRM Service unavailable
  • Trace-ID: abc123de
================================================================================
```

**Database Error:**
```
================================================================================
[TOUR-OPTIMIZE] 🔴 DATENBANK-FEHLER
  • Fehlertyp: OperationalError
  • Fehlermeldung: database is locked
  • Trace-ID: abc123de
[TOUR-OPTIMIZE] Vollständiger Traceback:
...
================================================================================
```

**Unerwarteter Fehler:**
```
================================================================================
[TOUR-OPTIMIZE] 🔴🔴🔴 UNERWARTETER FEHLER 🔴🔴🔴
  • Exception-Typ: AttributeError
  • Fehlermeldung: 'NoneType' object has no attribute 'get'
  • Trace-ID: abc123de
[TOUR-OPTIMIZE] Vollständiger Traceback:
...
================================================================================
```

## Vorteile

### 1. **Trace-ID für jeden Request**
- Eindeutige Identifikation jedes API-Calls
- Zuordnung von Logs zu spezifischen Requests

### 2. **Klare Phasen-Trennung**
- Request → Validierung → Optimierung → Zeitberechnung → Response
- Jede Phase ist visuell getrennt (═════)

### 3. **Emoji-Indikatoren**
- 🚀 START
- 📥 Request
- 📍 Koordinaten
- 🔄 Prozess läuft
- ✅ Erfolg
- ⚠️ Warnung
- ❌ Fehler
- 🔴 Kritischer Fehler

### 4. **Kontext-Informationen**
- Jeder Fehler zeigt:
  - Exception-Typ
  - Fehlermeldung
  - Tour ID
  - Anzahl Stopps
  - Vollständiger Traceback

### 5. **Fallback-Dokumentation**
- Jeder Fallback wird geloggt
- Grund für Fallback ist dokumentiert

### 6. **Performance-Metriken**
- Fahrzeit, Servicezeit, Gesamtzeit
- Anzahl Stopps
- Methode

## Testing

Nach Server-Restart sollten die Logs zeigen:

1. **Erfolgreicher Workflow:**
   ```
   START → Request → Koordinaten OK → Optimierung → Zeitberechnung → SUCCESS
   ```

2. **Fehler-Workflow:**
   ```
   START → Request → Koordinaten OK → Optimierung → FEHLER → Traceback → Fallback → SUCCESS
   ```

3. **Kritischer Fehler:**
   ```
   START → Request → FEHLER: Keine Koordinaten → ERROR Response
   ```

## Verwendung

```bash
# Server starten
python start_server.py

# In einem zweiten Terminal: Logs beobachten
# Die Logs erscheinen direkt in der Console
```

**Wichtig:** Alle Logs verwenden `safe_print()` → Keine UnicodeEncodeError mehr!

## Nächste Schritte

1. Server neu starten
2. CSV hochladen
3. Sub-Routen generieren
4. **Logs genau lesen**
5. Fehler identifizieren

Die Logs sollten jetzt **genau** zeigen:
- Wo der Fehler auftritt
- Warum der Fehler auftritt
- Welche Daten betroffen sind
- Welcher Fallback verwendet wird

