# Session-Zusammenfassung - Systemregeln Editierung

**Datum:** 2025-01-13  
**Thema:** Systemregeln im Admin-Bereich editierbar machen

## Durchgeführte Änderungen

### 1. Systemregeln-API erweitert (`backend/routes/system_rules_api.py`)
- ✅ JSON-Datei-Support hinzugefügt (`config/system_rules.json`)
- ✅ `PUT /api/system/rules` Endpoint zum Speichern implementiert
- ✅ Authentifizierung für PUT-Requests (nur für Admins)
- ✅ Validierung mit Pydantic Models
- ✅ Fallback auf Environment-Variablen für Kompatibilität

### 2. Frontend erweitert (`frontend/admin.html`)
- ✅ Editier-Formular im Tab "Systemregeln" hinzugefügt
- ✅ Alle Systemregeln können bearbeitet werden:
  - Zeitbudget ohne Rückfahrt (1-120 Min)
  - Zeitbudget mit Rückfahrt (1-180 Min)
  - Service-Zeit pro Stop (0.5-10.0 Min)
  - Durchschnittsgeschwindigkeit (10-100 km/h)
  - Sicherheitsfaktor (1.0-2.0)
  - Depot-Koordinaten (Lat/Lon)
- ✅ Detaillierte Erklärung des Sicherheitsfaktors hinzugefügt
- ✅ Client-seitige Validierung vor dem Senden
- ✅ Verbesserte Fehlerbehandlung mit detaillierten Meldungen

### 3. API-Registrierung (`backend/app_setup.py`)
- ✅ `system_rules_api_router` importiert und registriert

### 4. Fehlerbehandlung verbessert
- ✅ Frontend: Detaillierte Validierung und Fehlermeldungen
- ✅ Frontend: `credentials: 'include'` für Cookie-Authentifizierung
- ✅ Backend: Verbesserte Fehlerbehandlung und Logging
- ✅ Backend: Zusätzliche Validierung (ohne Rückfahrt < mit Rückfahrt)

## Offene Punkte

### 1. Server-Neustart erforderlich
- **Problem:** `PUT /api/system/rules` gibt 404 Not Found
- **Ursache:** Server läuft noch mit alter Version (API nicht registriert)
- **Lösung:** Server neu starten (`python start_server.py`)
- **Status:** ⏳ Wartet auf Server-Neustart

### 2. OSRM-Problem (nicht kritisch)
- **Problem:** OSRM Health-Check zeigt "All connection attempts failed"
- **Ursache:** Docker Desktop läuft nicht / OSRM Container nicht gestartet
- **Status:** ⏸️ Zurückgestellt (App funktioniert mit Fallback)

## Nächste Schritte

1. **Server neu starten** (damit Systemregeln-API verfügbar wird)
2. **Systemregeln testen** (Speichern sollte nach Neustart funktionieren)
3. **OSRM optional starten** (wenn benötigt, aber nicht kritisch)

## Dateien geändert

- `backend/routes/system_rules_api.py` - API erweitert
- `backend/app_setup.py` - Router registriert
- `frontend/admin.html` - Editier-Formular hinzugefügt

## Neue Dateien

- `config/system_rules.json` - Wird automatisch erstellt beim ersten Zugriff

## Technische Details

### Sicherheitsfaktor-Erklärung
Der Sicherheitsfaktor kompensiert die Differenz zwischen Luftlinie (Haversine) und tatsächlicher Straßenentfernung im Stadtverkehr:
- **Standard:** 1.3 (30% Aufschlag)
- **Berechnung:** `Straßenentfernung = Haversine-Distanz × Sicherheitsfaktor`
- **Beispiel:** 10 km Luftlinie → 13 km Straßenentfernung (bei Faktor 1.3)
- **Anpassung:** 1.1-1.2 (einfach), 1.3 (Standard), 1.4-1.5 (komplex)

### API-Endpoints

- `GET /api/system/rules` - Lädt aktuelle Systemregeln
- `PUT /api/system/rules` - Speichert Systemregeln (authentifiziert)

### Authentifizierung
- PUT-Requests erfordern Admin-Session
- Session wird über Cookie `admin_session` überprüft
- Bei fehlender Authentifizierung: 401 Unauthorized

