# Cursor Tasks: OSRM Metrics & Server-Stabilität

**Ziel:** Server stabil, weniger 5xx, OSRM verbindlich erreichbar. Dieser Task bündelt Minimal-Patches und überprüfbare Tests.

---

## 1) Metrics: 5xx/4xx hart mitzählen ✅

**Datei:** `backend/middlewares/error_tally.py`

```python
from starlette.requests import Request
from starlette.responses import Response, JSONResponse

METRICS = {"http_4xx": 0, "http_5xx": 0}

async def error_tally(request: Request, call_next):
    try:
        resp: Response = await call_next(request)
        if 400 <= resp.status_code < 500:
            METRICS["http_4xx"] += 1
        elif 500 <= resp.status_code < 600:
            METRICS["http_5xx"] += 1
        return resp
    except Exception:
        METRICS["http_5xx"] += 1
        return JSONResponse({"detail": "internal"}, status_code=500)
```

**Registriert:** in `backend/app_setup.py` → `setup_middleware()`

**Endpoint:** `GET /metrics/simple` → gibt `METRICS` zurück

**Akzeptanzkriterium:** `GET /metrics/simple` liefert Zähler; nach Smoke-Tests steigen 4xx/5xx konsistent.

---

## 2) OSRM Dienst sicher starten (Proxmox-Container 101)

**Ziel-Port:** `5011` (5000 ist belegt durch Frigate)

**Script:** `scripts/osrm_prep_and_run.sh`

**Schritte im CT (101):**

1. **Region-Datei laden** (falls noch nicht):
```bash
mkdir -p /var/lib/osrm
cd /var/lib/osrm
curl -L -o region.osm.pbf https://download.geofabrik.de/europe/germany/sachsen-latest.osm.pbf
```

2. **Preprocessing & Run via Docker** (Host-Net oder Portmap):
```bash
# Preprocess
docker run --rm -t -v /var/lib/osrm:/data osrm/osrm-backend:latest \
  osrm-extract -p /opt/car.lua /data/region.osm.pbf

docker run --rm -t -v /var/lib/osrm:/data osrm/osrm-backend:latest \
  osrm-partition /data/region.osrm

docker run --rm -t -v /var/lib/osrm:/data osrm/osrm-backend:latest \
  osrm-customize /data/region.osrm

# Start (Variante A: Host-Netz)
docker run -d --name osrm \
  --network host \
  -v /var/lib/osrm:/data \
  osrm/osrm-backend:latest \
  osrm-routed --algorithm mld --port 5011 /data/region.osrm
```

3. **Health-Check im CT:**
```bash
ss -ltnp | grep :5011 || echo "OSRM NICHT LISTENING"
curl -s "http://127.0.0.1:5011/route/v1/driving/13.7373,51.0504;13.7283,51.0615?overview=false" | head
```

**Akzeptanzkriterien:** Port **5011** Lauscht; `route`-Antwort liefert `code: Ok`.

---

## 3) Env sauber trennen (Home vs Work) ✅

**Datei:** `.env.example` und `config.env`

```
# Home (Docker Desktop - App läuft lokal außerhalb Docker)
OSRM_BASE_URL=http://127.0.0.1:5000

# Home (Docker Desktop - App läuft auch im Docker-Netzwerk)
# OSRM_BASE_URL=http://osrm:5000

# Work (Proxmox CT 101)
# OSRM_BASE_URL=http://172.16.1.191:5011
```

**Programmstart-Log muss zeigen:**
```
OSRM URL: http://127.0.0.1:5000  # wenn Home (Docker Desktop) aktiv
```

**Status:** OSRM-Client loggt bereits beim Initialisieren (Zeile 59 in `services/osrm_client.py`)

**Hinweis:** 
- Docker Desktop: OSRM läuft im Container auf Port 5000
- Wenn App lokal läuft: `http://127.0.0.1:5000`
- Wenn App auch im Docker läuft: `http://osrm:5000` (Docker-Netzwerk)

---

## 4) Health-Trio – messbare Smoke-Checks ✅

**Endpoints:**
- `GET /health/status` - Kombinierter Status (Server, DB, OSRM)
- `GET /health/db` - Datenbank-Status
- `GET /health/osrm` - OSRM-Status

**Erwartung:** `health/osrm` ✅ sobald OSRM erreichbar ist.

**Status:** Bereits implementiert in `backend/routes/health_check.py`

---

## 5) Frontend-Fetch Guard (Single-read) ✅

**Anti-Duplikat-Lesen** in deinem Fetch-Wrapper sicherstellen:

```js
async function fetchJSON(url, opts={}){
  const res = await fetch(url, opts);
  const ct = res.headers.get('content-type')||'';
  const payload = ct.includes('application/json') ? await res.json() : await res.text();
  if(!res.ok){
    throw { status: res.status, body: payload };
  }
  return payload;
}
```

**Akzeptanzkriterium:** Kein „body used already“-Fehler mehr.

**Status:** Implementiert in `frontend/index.html` (Zeile ~1170)

---

## 6) Statuscode-Policy (402 raus)

**In allen Error-Returns:**

* 400/422: Validation/Userfehler
* 429/504: Rate-Limit/Timeout (z.B. OSRM Timeout)
* 500: Uncaught, mit Trace-ID

**Status:** Zu prüfen und durchzusetzen

---

## 7) Testliste (manuell, kurz)

* `GET /` → 200/HTML
* `GET /openapi.json` → 200/JSON
* `POST /api/tour/route-details` (2 Punkte) → 200 + Geometrie vorhanden
* `GET /health/osrm` → 200 `{ok:true}`
* `GET /metrics/simple` → Zähler erhöht sich korrekt

---

## 8) Abnahme-Kriterium „Weniger Fehler"

* Vorher/Nachher `GET /metrics/simple`: `http_5xx` stagniert nach Fixes trotz 10 wiederholter Routen-Calls.
* Logs zeigen: „OSRM-Client initialisiert: [http://172.16.1.191:5011](http://172.16.1.191:5011)" und keine `Failed to connect`-Meldungen.

---

## 9) Artefakte für ZIP/Revision

* ✅ Diesen Plan als `ZIP/CURSOR_TASKS_OSRM_METRICS.md`
* ✅ Neue Dateien:
  * `backend/middlewares/error_tally.py`
  * `scripts/osrm_prep_and_run.sh`
* ✅ Geänderte Dateien:
  * `backend/app_setup.py` (Middleware-Registrierung + `/metrics/simple`)
  * `.env.example` (OSRM_URL Varianten)
  * `frontend/index.html` (fetchJSON Funktion)

---

## ✅ Implementierungs-Status

| Task | Status | Datei |
|------|--------|-------|
| 1. Metrics-Middleware | ✅ | `backend/middlewares/error_tally.py` |
| 2. OSRM-Script | ✅ | `scripts/osrm_prep_and_run.sh` |
| 3. Env-Beispiel | ✅ | `.env.example` |
| 4. Health-Checks | ✅ | Bereits vorhanden |
| 5. Fetch Guard | ✅ | `frontend/index.html` |
| 6. Statuscode-Policy | ⏳ | Zu prüfen |
| 7. Testliste | ⏳ | Manuell durchzuführen |
| 8. Abnahme | ⏳ | Nach Tests |

---

**Letzte Aktualisierung:** 2025-11-13

