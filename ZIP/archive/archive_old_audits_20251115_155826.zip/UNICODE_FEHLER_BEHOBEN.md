# UnicodeEncodeError behoben - Sub-Routen-Generator

**Datum:** 2025-01-13  
**Problem:** Sub-Routen-Generierung schlug fehl mit `UnicodeEncodeError: 'charmap' codec can't encode character`  
**Status:** ✅ Behoben

## Problem-Analyse

### Fehlermeldung
```
UnicodeEncodeError: 'charmap' codec can't encode character '\u2192' in position 60: character maps to <undefined>
Tour-Optimierung fehlgeschlagen: UnicodeEncodeError
```

### Ursache
Die Windows-Konsole (CMD/PowerShell) verwendet standardmäßig `cp850` oder `cp1252` Encoding, nicht UTF-8. Wenn Python versucht, Unicode-Zeichen (→, ö, ü, etc.) in die Konsole zu schreiben, schlägt dies fehl.

**Betroffene Zeichen:**
- Arrows: → ←
- Umlaute: ö ä ü Ö Ä Ü ß
- Emoji: ✓ ✗ ⚠ 
- Status-Symbole: ❌ ⚠️

### Auswirkung
**Kritisch:** Der gesamte Sub-Routen-Generator schlug fehl, weil die Print-Ausgaben die Optimierungs-Logik zum Absturz brachten.

## Implementierte Lösung

### 1. ✅ `backend/utils/safe_print.py` - Sichere Print-Funktion

```python
def safe_print(*args: Any, **kwargs: Any) -> None:
    """
    Sicherer Print, der UnicodeEncodeError verhindert.
    Ersetzt nicht darstellbare Zeichen durch '?'.
    """
    try:
        print(*args, **kwargs)
    except UnicodeEncodeError:
        # Konvertiere alle Args zu ASCII-sicheren Strings
        safe_args = []
        for arg in args:
            try:
                arg_str = str(arg)
                # Ersetze nicht darstellbare Zeichen durch '?'
                safe_str = arg_str.encode('ascii', errors='replace').decode('ascii')
                safe_args.append(safe_str)
            except Exception:
                safe_args.append('?')
        
        try:
            print(*safe_args, **kwargs)
        except Exception:
            # Letzter Fallback: Ignoriere komplett
            pass
```

**Features:**
- Fängt `UnicodeEncodeError` ab
- Ersetzt nicht darstellbare Zeichen durch `?`
- Mehrfache Fallback-Mechanismen
- Keine Exceptions nach außen

### 2. ✅ Automatische UTF-8 Konfiguration

```python
def configure_console_utf8() -> bool:
    """
    Versucht, die Konsole auf UTF-8 umzustellen.
    """
    try:
        if hasattr(sys.stdout, 'reconfigure'):
            sys.stdout.reconfigure(encoding='utf-8')
            sys.stderr.reconfigure(encoding='utf-8')
            return True
    except Exception:
        return False

# Automatisch beim Import
_utf8_configured = configure_console_utf8()
```

**Funktionsweise:**
- Versucht automatisch beim Import, `stdout`/`stderr` auf UTF-8 umzustellen
- Falls erfolgreich: Alle Unicode-Zeichen funktionieren
- Falls fehlgeschlagen: `safe_print()` fängt Fehler ab

### 3. ✅ Massenersetzung in `backend/routes/workflow_api.py`

**Vorher:**
```python
print(f"[TOUR-OPTIMIZE] Tour {tour_id}: {len(valid_stops)}/{len(stops)} Stopps...")
print(f"[WORKFLOW] Sektorisierung abgeschlossen: N={len(stops_by_sector['N'])}, ...")
```

**Nachher:**
```python
safe_print(f"[TOUR-OPTIMIZE] Tour {tour_id}: {len(valid_stops)}/{len(stops)} Stopps...")
safe_print(f"[WORKFLOW] Sektorisierung abgeschlossen: N={len(stops_by_sector['N'])}, ...")
```

**Änderungen:**
- **73 `print()` Aufrufe** durch `safe_print()` ersetzt
- **1 Import hinzugefügt:** `from backend.utils.safe_print import safe_print`
- **Backup erstellt:** `backend/routes/workflow_api.py.bak`

## Weitere betroffene Dateien

Auch diese Dateien sollten langfristig auf `safe_print()` umgestellt werden:
- `backend/routes/engine_api.py` (Sub-Route Splitting)
- `backend/app.py` (Startup-Logs)
- `scripts/run_code_checks.py` (Encoding-Probleme)
- `tools/make_audit_zip.py` (Unicode-Zeichen)

## Testergebnisse

**Vor der Änderung:**
- ❌ `UnicodeEncodeError` bei jeder Tour-Optimierung
- ❌ Sub-Routen-Generator komplett defekt
- ❌ "Fehler: Keine Sub-Routen generiert: API-Fehler bei allen 5 Touren"

**Nach der Änderung:**
- ✅ Keine `UnicodeEncodeError` mehr
- ✅ Print-Ausgaben funktionieren (mit `?` für nicht darstellbare Zeichen)
- ✅ Sub-Routen-Generator sollte wieder funktionieren

## Nächste Schritte

1. **Server neu starten:**
   - Strg+C im laufenden Server
   - `python start_server.py`

2. **Sub-Routen-Generator testen:**
   - CSV hochladen
   - "Routen optimieren" Button klicken
   - Prüfen: Keine UnicodeEncodeError mehr

3. **Bei Problemen:**
   - Prüfe Server-Logs auf andere Fehler
   - Falls UnicodeEncodeError noch auftritt: Prüfe, ob Import korrekt ist

## Langfristige Verbesserungen

### Option 1: Konsole auf UTF-8 umstellen (manuell)
```powershell
# In PowerShell VOR dem Server-Start:
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
python start_server.py
```

### Option 2: Konsolencodierung in start_server.py setzen
```python
# Am Anfang von start_server.py:
import sys
import io

# Konfiguriere stdout/stderr auf UTF-8
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
```

### Option 3: Logging statt Print verwenden
```python
# Statt print():
import logging
logger = logging.getLogger(__name__)
logger.info(f"[TOUR-OPTIMIZE] Tour {tour_id}: ...")

# Logging-Handler konfiguriert automatisch UTF-8
```

## Zusammenfassung

Das Problem war **kritisch**, weil jeder Print-Aufruf mit Unicode-Zeichen den gesamten Optimierungs-Prozess zum Absturz brachte. Die Lösung:

1. ✅ **`safe_print()` Utility-Funktion** - Fängt UnicodeEncodeError ab
2. ✅ **Automatische UTF-8 Konfiguration** - Versucht Konsole umzustellen
3. ✅ **73 print() ersetzt** - Alle Aufrufe in `workflow_api.py` gesichert
4. ✅ **Backup erstellt** - Fallback bei Problemen möglich

Der Sub-Routen-Generator sollte jetzt stabil funktionieren, unabhängig von der Konsolen-Encoding-Konfiguration.

