"""
Exception Envelope Middleware
Fängt alle Exceptions ab und gibt strukturierte 500er mit Trace-ID zurück.
"""
import uuid
import traceback
import logging
from fastapi import Request, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

logger = logging.getLogger(__name__)


class ErrorEnvelopeMiddleware(BaseHTTPMiddleware):
    """
    Middleware die alle unhandled Exceptions abfängt und strukturierte 500er zurückgibt.
    """
    
    async def dispatch(self, request: Request, call_next):
        # Hole Trace-ID aus Request (wird von TraceIDMiddleware gesetzt)
        trace_id = request.state.get("trace_id", str(uuid.uuid4())[:8])
        
        try:
            response = await call_next(request)
            return response
        except Exception as exc:
            # Logge Exception mit Trace-ID
            error_detail = str(exc)
            error_type = type(exc).__name__
            
            logger.exception(
                f"Unhandled exception in {request.method} {request.url.path}",
                extra={
                    "trace_id": trace_id,
                    "path": str(request.url.path),
                    "method": request.method,
                    "error_type": error_type,
                    "error_detail": error_detail[:200]  # Erste 200 Zeichen
                }
            )
            
            # Strukturierte 500er Response
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content={
                    "success": False,
                    "error": f"Internal Server Error: {error_type}",
                    "error_detail": error_detail[:500],  # Erste 500 Zeichen
                    "trace_id": trace_id,
                    "path": str(request.url.path),
                    "method": request.method
                }
            )

