"""
Trace-ID Middleware
Setzt X-Request-ID Header für Request-Tracing.
"""
import uuid
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp


class TraceIDMiddleware(BaseHTTPMiddleware):
    """
    Middleware die eine Trace-ID für jeden Request generiert und im Request-State speichert.
    """
    
    async def dispatch(self, request: Request, call_next):
        # Hole Trace-ID aus Header oder generiere neue
        trace_id_header = request.headers.get("X-Request-ID")
        trace_id = trace_id_header if trace_id_header else str(uuid.uuid4())[:8]
        
        # Speichere Trace-ID im Request-State
        request.state.trace_id = trace_id
        
        # Rufe nächste Middleware/Handler auf
        response = await call_next(request)
        
        # Füge Trace-ID zum Response-Header hinzu
        response.headers["X-Request-ID"] = trace_id
        
        return response

