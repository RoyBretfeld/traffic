"""
Pydantic Schemas für Request-Validierung
"""
from pydantic import BaseModel, Field, validator
from typing import List, Optional, Literal


class StopModel(BaseModel):
    """Einzelner Stop in einer Tour"""
    customer_number: Optional[str] = None
    name: Optional[str] = None
    address: Optional[str] = None
    lat: Optional[float] = Field(None, ge=-90, le=90)
    lon: Optional[float] = Field(None, ge=-180, le=180)
    bar_flag: Optional[bool] = False
    
    @validator('lat', 'lon')
    def validate_coordinates(cls, v, field):
        if v is not None:
            if field.name == 'lat' and not (-90 <= v <= 90):
                raise ValueError(f"Latitude muss zwischen -90 und 90 liegen, got {v}")
            if field.name == 'lon' and not (-180 <= v <= 180):
                raise ValueError(f"Longitude muss zwischen -180 und 180 liegen, got {v}")
        return v


class OptimizeTourRequest(BaseModel):
    """Request für Tour-Optimierung"""
    tour_id: str = Field(..., min_length=1, max_length=100)
    stops: List[StopModel] = Field(..., min_items=1, max_items=200)
    is_bar_tour: Optional[bool] = False
    profile: Literal["car", "bike", "foot"] = "car"
    strategy: Literal["mld", "ch"] = "mld"
    
    @validator('stops')
    def validate_stops_have_coordinates(cls, v):
        """Validiere dass mindestens ein Stop Koordinaten hat"""
        valid_stops = [s for s in v if s.lat is not None and s.lon is not None]
        if len(valid_stops) == 0:
            raise ValueError("Mindestens ein Stop muss gültige Koordinaten (lat, lon) haben")
        return v

