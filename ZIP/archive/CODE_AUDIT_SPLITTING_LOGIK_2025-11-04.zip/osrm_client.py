"""
OSRM Client Service
Client für OSRM (Open Source Routing Machine) API zur Berechnung von Routen und Distanzmatrizen.

Dieser Service ist optional und verwendet Fallbacks (Haversine) wenn OSRM nicht verfügbar ist.
"""

import os
import logging
from typing import List, Dict, Optional, Tuple
import math

logger = logging.getLogger(__name__)


class OSRMClient:
    """
    OSRM Client für Routenberechnung.
    
    Wenn OSRM nicht verfügbar ist, werden Fallbacks verwendet (Haversine-Distanz).
    """
    
    def __init__(self, base_url: Optional[str] = None):
        """
        Initialisiert den OSRM Client.
        
        Args:
            base_url: OSRM Server URL (z.B. "http://router.project-osrm.org")
                     Wenn None, wird versucht eine lokale OSRM-Instanz zu verwenden
        """
        # Unterstütze sowohl OSRM_URL als auch OSRM_BASE_URL
        env_url = os.getenv("OSRM_URL") or os.getenv("OSRM_BASE_URL")
        self.base_url = base_url or env_url or "http://router.project-osrm.org"
        self.logger = logger
        
        # Prüfe ob OSRM verfügbar ist
        self._available = self._check_availability()
    
    @property
    def available(self) -> bool:
        """Gibt zurück ob OSRM verfügbar ist"""
        return self._available
    
    def _check_availability(self) -> bool:
        """
        Prüft ob OSRM verfügbar ist.
        
        Returns:
            True wenn OSRM verfügbar ist, sonst False (verwendet dann Fallbacks)
        """
        try:
            import requests
            # Test-Route: Berlin (einfacher Test)
            test_url = f"{self.base_url}/route/v1/driving/13.388860,52.517037;13.397634,52.529407?overview=false"
            response = requests.get(test_url, timeout=3)
            if response.status_code == 200:
                self.logger.info(f"[OSRM] Server verfügbar: {self.base_url}")
                return True
            else:
                self.logger.warning(f"[OSRM] Server antwortet mit Status {response.status_code}")
                return False
        except ImportError:
            self.logger.warning("[OSRM] requests-Modul nicht verfügbar, verwende Fallback")
            return False
        except Exception as e:
            self.logger.warning(f"[OSRM] Verfügbarkeitsprüfung fehlgeschlagen: {e}, verwende Fallback")
            return False
    
    def get_route(self, coords: List[Tuple[float, float]]) -> Optional[Dict]:
        """
        Berechnet eine Route zwischen Koordinaten.
        
        Args:
            coords: Liste von (lat, lon) Tupeln (min. 2 Punkte)
            
        Returns:
            Dict mit:
                - geometry: GeoJSON Geometry (optional)
                - distance_km: Distanz in Kilometern
                - duration_min: Dauer in Minuten
            Oder None wenn Route nicht berechnet werden kann
        """
        if len(coords) < 2:
            return None
        
        # Versuche echte OSRM-Route wenn verfügbar
        if self._available:
            try:
                import requests
                # OSRM Route API: /route/v1/{profile}/{coordinates}?overview=false
                coords_str = ";".join([f"{lon},{lat}" for lat, lon in coords])
                route_url = f"{self.base_url}/route/v1/driving/{coords_str}?overview=false&alternatives=false"
                
                response = requests.get(route_url, timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    if data.get("code") == "Ok" and data.get("routes"):
                        route = data["routes"][0]
                        distance_m = route.get("distance", 0)  # Meter
                        duration_s = route.get("duration", 0)  # Sekunden
                        
                        return {
                            "geometry": route.get("geometry"),  # Polyline-encoded
                            "distance_km": round(distance_m / 1000.0, 2),
                            "duration_min": round(duration_s / 60.0, 2),
                            "source": "osrm"
                        }
            except Exception as e:
                self.logger.warning(f"OSRM Route-Request fehlgeschlagen: {e}, verwende Fallback")
        
        # Fallback: Haversine-Distanz berechnen
        total_distance_km = 0.0
        total_duration_min = 0.0
        
        for i in range(len(coords) - 1):
            lat1, lon1 = coords[i]
            lat2, lon2 = coords[i + 1]
            
            # Haversine-Distanz
            distance_km = self._haversine_distance(lat1, lon1, lat2, lon2)
            # Multipliziere mit 1.3 für reale Straßendistanz
            distance_km *= 1.3
            # Geschwindigkeit: 50 km/h (Durchschnitt Stadt)
            duration_min = (distance_km / 50.0) * 60
            
            total_distance_km += distance_km
            total_duration_min += duration_min
        
        return {
            "geometry": None,  # GeoJSON Geometry (optional)
            "distance_km": round(total_distance_km, 2),
            "duration_min": round(total_duration_min, 2),
            "source": "haversine"
        }
    
    def get_distance_matrix(
        self,
        coords: List[Tuple[float, float]],
        sources: Optional[List[int]] = None,
        destinations: Optional[List[int]] = None
    ) -> Optional[Dict[Tuple[int, int], Dict[str, float]]]:
        """
        Berechnet eine Distanzmatrix zwischen Koordinaten.
        
        Args:
            coords: Liste von (lat, lon) Tupeln
            sources: Liste von Indizes für Quellen (wenn None: alle)
            destinations: Liste von Indizes für Ziele (wenn None: alle)
            
        Returns:
            Dict mit Keys (i, j) -> {"km": float, "minutes": float}
            Oder None wenn Matrix nicht berechnet werden kann
        """
        if len(coords) < 2:
            return None
        
        # Versuche echte OSRM Table API wenn verfügbar
        if self._available:
            try:
                import requests
                # Wenn sources/destinations nicht angegeben, verwende alle
                if sources is None:
                    sources = list(range(len(coords)))
                if destinations is None:
                    destinations = list(range(len(coords)))
                
                # OSRM Table API: /table/v1/{profile}/{coordinates}?sources={sources}&destinations={destinations}
                coords_str = ";".join([f"{lon},{lat}" for lat, lon in coords])
                sources_str = ",".join(map(str, sources))
                destinations_str = ",".join(map(str, destinations))
                
                table_url = f"{self.base_url}/table/v1/driving/{coords_str}?sources={sources_str}&destinations={destinations_str}"
                
                response = requests.get(table_url, timeout=15)
                if response.status_code == 200:
                    data = response.json()
                    if data.get("code") == "Ok" and "durations" in data and "distances" in data:
                        durations = data["durations"]  # Matrix in Sekunden
                        distances = data["distances"]   # Matrix in Metern
                        
                        matrix = {}
                        for i, src_idx in enumerate(sources):
                            for j, dst_idx in enumerate(destinations):
                                if src_idx == dst_idx:
                                    matrix[(src_idx, dst_idx)] = {"km": 0.0, "minutes": 0.0}
                                    continue
                                
                                # OSRM gibt Distanzen in Metern und Zeiten in Sekunden zurück
                                distance_m = distances[i][j] if i < len(distances) and j < len(distances[i]) else 0
                                duration_s = durations[i][j] if i < len(durations) and j < len(durations[i]) else 0
                                
                                matrix[(src_idx, dst_idx)] = {
                                    "km": round(distance_m / 1000.0, 2),
                                    "minutes": round(duration_s / 60.0, 2)
                                }
                        
                        self.logger.info(f"[OSRM] Table API erfolgreich: {len(sources)}×{len(destinations)} Matrix")
                        return matrix
                    else:
                        self.logger.warning(f"[OSRM] Table API antwortete ohne Daten: {data.get('code', 'unknown')}")
            except Exception as e:
                self.logger.warning(f"[OSRM] Table API Fehler: {e}, verwende Fallback")
        
        # Fallback: Haversine-Distanz berechnen
        try:
            # Wenn sources/destinations nicht angegeben, verwende alle
            if sources is None:
                sources = list(range(len(coords)))
            if destinations is None:
                destinations = list(range(len(coords)))
            
            matrix = {}
            
            for src_idx in sources:
                for dst_idx in destinations:
                    if src_idx == dst_idx:
                        matrix[(src_idx, dst_idx)] = {"km": 0.0, "minutes": 0.0}
                        continue
                    
                    lat1, lon1 = coords[src_idx]
                    lat2, lon2 = coords[dst_idx]
                    
                    # Haversine-Distanz
                    distance_km = self._haversine_distance(lat1, lon1, lat2, lon2)
                    # Multipliziere mit 1.3 für reale Straßendistanz
                    distance_km *= 1.3
                    # Geschwindigkeit: 50 km/h
                    duration_min = (distance_km / 50.0) * 60
                    
                    matrix[(src_idx, dst_idx)] = {
                        "km": round(distance_km, 2),
                        "minutes": round(duration_min, 2)
                    }
            
            return matrix
            
        except Exception as e:
            self.logger.warning(f"Distance Matrix Berechnung fehlgeschlagen: {e}")
            return None
    
    @staticmethod
    def _haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """
        Berechnet die Haversine-Distanz zwischen zwei Koordinaten.
        
        Args:
            lat1, lon1: Erste Koordinate
            lat2, lon2: Zweite Koordinate
            
        Returns:
            Distanz in Kilometern
        """
        # Erdradius in Kilometern
        R = 6371.0
        
        # Grad zu Radiant
        lat1_rad = math.radians(lat1)
        lat2_rad = math.radians(lat2)
        delta_lat = math.radians(lat2 - lat1)
        delta_lon = math.radians(lon2 - lon1)
        
        # Haversine-Formel
        a = (
            math.sin(delta_lat / 2) ** 2 +
            math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(delta_lon / 2) ** 2
        )
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        
        distance = R * c
        return distance


# Für Import-Kompatibilität
import os

