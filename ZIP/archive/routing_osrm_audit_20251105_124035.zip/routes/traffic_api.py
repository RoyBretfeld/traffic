"""
Traffic API - Endpoints für Baustellen und Verkehrsdaten
"""

from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/traffic", tags=["traffic"])


class ConstructionSiteResponse(BaseModel):
    """Baustellen-Daten für API-Response"""
    id: str
    lat: float
    lon: float
    geometry: List[List[float]]  # [[lat, lon], ...]
    construction_type: str
    description: Optional[str]
    start_date: Optional[str]
    end_date: Optional[str]
    access_restriction: Optional[str]


class TrafficConditionResponse(BaseModel):
    """Verkehrslage-Daten für API-Response"""
    lat: float
    lon: float
    severity: str
    delay_minutes: int
    description: Optional[str]


@router.get("/construction/nearby")
async def get_construction_nearby(
    lat: float = Query(..., description="Breitengrad"),
    lon: float = Query(..., description="Längengrad"),
    radius_km: float = Query(5.0, description="Radius in Kilometern")
):
    """
    Holt Baustellen in der Nähe eines Punktes.
    """
    try:
        from services.construction_service import ConstructionService
        
        service = ConstructionService()
        
        # Berechne Bounding Box
        buffer_deg = radius_km * 0.01  # ~0.01 Grad ≈ 1km
        min_lat = lat - buffer_deg
        max_lat = lat + buffer_deg
        min_lon = lon - buffer_deg
        max_lon = lon + buffer_deg
        
        sites = service.get_construction_sites_in_bbox(min_lat, min_lon, max_lat, max_lon)
        
        return {
            "count": len(sites),
            "sites": [
                {
                    "id": site.id,
                    "lat": site.lat,
                    "lon": site.lon,
                    "geometry": [[coord[0], coord[1]] for coord in site.geometry],
                    "construction_type": site.construction_type,
                    "description": site.description,
                    "start_date": site.start_date,
                    "end_date": site.end_date,
                    "access_restriction": site.access_restriction,
                }
                for site in sites
            ]
        }
    except Exception as e:
        logger.error(f"Fehler beim Abrufen von Baustellen: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/construction/bbox")
async def get_construction_bbox(
    min_lat: float = Query(..., description="Süd-West Breitengrad"),
    min_lon: float = Query(..., description="Süd-West Längengrad"),
    max_lat: float = Query(..., description="Nord-Ost Breitengrad"),
    max_lon: float = Query(..., description="Nord-Ost Längengrad"),
):
    """
    Holt alle Baustellen in einem Bounding Box.
    """
    try:
        from services.construction_service import ConstructionService
        
        service = ConstructionService()
        sites = service.get_construction_sites_in_bbox(min_lat, min_lon, max_lat, max_lon)
        
        return {
            "count": len(sites),
            "sites": [
                {
                    "id": site.id,
                    "lat": site.lat,
                    "lon": site.lon,
                    "geometry": [[coord[0], coord[1]] for coord in site.geometry],
                    "construction_type": site.construction_type,
                    "description": site.description,
                    "start_date": site.start_date,
                    "end_date": site.end_date,
                    "access_restriction": site.access_restriction,
                }
                for site in sites
            ]
        }
    except Exception as e:
        logger.error(f"Fehler beim Abrufen von Baustellen: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/construction/route-check")
async def check_route_through_construction(
    route_geometry: List[List[float]]  # [[lat, lon], ...]
):
    """
    Prüft ob eine Route durch Baustellen führt.
    
    Args:
        route_geometry: Liste von [lat, lon] Koordinaten
    """
    try:
        from services.construction_service import ConstructionService
        
        service = ConstructionService()
        
        # Konvertiere zu Tuple-Format
        route_tuples = [(coord[0], coord[1]) for coord in route_geometry]
        
        goes_through, affected_sites = service.check_route_through_construction(route_tuples)
        
        return {
            "goes_through_construction": goes_through,
            "affected_sites_count": len(affected_sites),
            "affected_sites": [
                {
                    "id": site.id,
                    "lat": site.lat,
                    "lon": site.lon,
                    "construction_type": site.construction_type,
                    "description": site.description,
                }
                for site in affected_sites
            ]
        }
    except Exception as e:
        logger.error(f"Fehler bei Route-Prüfung: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/conditions")
async def get_traffic_conditions(
    min_lat: float = Query(..., description="Süd-West Breitengrad"),
    min_lon: float = Query(..., description="Süd-West Längengrad"),
    max_lat: float = Query(..., description="Nord-Ost Breitengrad"),
    max_lon: float = Query(..., description="Nord-Ost Längengrad"),
):
    """
    Holt Verkehrslagen in einem Gebiet.
    """
    try:
        from services.traffic_data_service import TrafficDataService
        
        service = TrafficDataService()
        conditions = service.get_traffic_conditions_in_area(min_lat, min_lon, max_lat, max_lon)
        
        return {
            "count": len(conditions),
            "conditions": [
                {
                    "lat": cond.lat,
                    "lon": cond.lon,
                    "severity": cond.severity,
                    "delay_minutes": cond.delay_minutes,
                    "description": cond.description,
                }
                for cond in conditions
            ]
        }
    except Exception as e:
        logger.error(f"Fehler beim Abrufen von Verkehrslagen: {e}")
        raise HTTPException(status_code=500, detail=str(e))

