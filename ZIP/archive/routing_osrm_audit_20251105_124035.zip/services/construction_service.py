"""
Construction Service - Baustellen-Daten aus OpenStreetMap
Holt Baustellen-Informationen über Overpass API und integriert sie in Routing
"""

import os
import logging
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
import httpx

logger = logging.getLogger(__name__)


@dataclass
class ConstructionSite:
    """Datenstruktur für eine Baustelle"""
    id: str
    lat: float
    lon: float
    geometry: List[Tuple[float, float]]  # Polygon oder Linie
    construction_type: str  # z.B. "road_construction", "bridge", "tunnel"
    description: Optional[str]
    start_date: Optional[str]
    end_date: Optional[str]
    access_restriction: Optional[str]  # "no", "private", etc.
    osm_tags: Dict[str, str]


class ConstructionService:
    """
    Service für Baustellen-Daten aus OpenStreetMap via Overpass API.
    """
    
    def __init__(self, overpass_url: Optional[str] = None):
        """
        Initialisiert den Construction Service.
        
        Args:
            overpass_url: Overpass API URL (Standard: öffentlicher Server)
        """
        self.overpass_url = overpass_url or os.getenv(
            "OVERPASS_API_URL", 
            "https://overpass-api.de/api/interpreter"
        )
        self.logger = logger
        
        # Cache für Baustellen-Daten (TTL: 1 Stunde)
        self._cache: Dict[str, Tuple[List[ConstructionSite], datetime]] = {}
        self._cache_ttl_seconds = 3600
    
    def get_construction_sites_in_bbox(
        self, 
        min_lat: float, 
        min_lon: float, 
        max_lat: float, 
        max_lon: float
    ) -> List[ConstructionSite]:
        """
        Holt alle Baustellen in einem Bounding Box.
        
        Args:
            min_lat, min_lon: Süd-West Ecke
            max_lat, max_lon: Nord-Ost Ecke
            
        Returns:
            Liste von Baustellen
        """
        cache_key = f"{min_lat},{min_lon},{max_lat},{max_lon}"
        
        # Prüfe Cache
        if cache_key in self._cache:
            sites, cached_time = self._cache[cache_key]
            age = (datetime.now() - cached_time).total_seconds()
            if age < self._cache_ttl_seconds:
                self.logger.debug(f"[CONSTRUCTION] Cache-Hit: {len(sites)} Baustellen")
                return sites
        
        try:
            # Overpass Query für Baustellen
            query = f"""
            [out:json][timeout:25];
            (
              // Straßen mit Baustellen-Tag
              way["highway"]["construction"]({min_lat},{min_lon},{max_lat},{max_lon});
              way["highway"="construction"]({min_lat},{min_lon},{max_lat},{max_lon});
              
              // Barrieren/Baustellen
              way["barrier"="construction"]({min_lat},{min_lon},{max_lat},{max_lon});
              
              // Zugangsbeschränkungen durch Baustellen
              way["access"="no"]["construction"]({min_lat},{min_lon},{max_lat},{max_lon});
              
              // Relationen mit Baustellen
              relation["highway"]["construction"]({min_lat},{min_lon},{max_lat},{max_lon});
            );
            out geom;
            """
            
            response = httpx.post(
                self.overpass_url,
                content=query,
                timeout=30.0,
                headers={"Content-Type": "text/plain"}
            )
            response.raise_for_status()
            data = response.json()
            
            sites = self._parse_overpass_response(data)
            
            # Cache aktualisieren
            self._cache[cache_key] = (sites, datetime.now())
            
            self.logger.info(f"[CONSTRUCTION] {len(sites)} Baustellen gefunden in BBox")
            return sites
            
        except Exception as e:
            self.logger.error(f"[CONSTRUCTION] Fehler beim Abrufen von Baustellen: {e}")
            return []
    
    def get_construction_sites_near_route(
        self,
        route_geometry: List[Tuple[float, float]],
        buffer_km: float = 0.5
    ) -> List[ConstructionSite]:
        """
        Holt Baustellen in der Nähe einer Route.
        
        Args:
            route_geometry: Liste von (lat, lon) Koordinaten der Route
            buffer_km: Buffer in Kilometern um die Route
            
        Returns:
            Liste von Baustellen die die Route beeinflussen könnten
        """
        if not route_geometry:
            return []
        
        # Berechne Bounding Box mit Buffer
        lats = [coord[0] for coord in route_geometry]
        lons = [coord[1] for coord in route_geometry]
        
        # Buffer: ~0.01 Grad ≈ 1km (ungefähr)
        buffer_deg = buffer_km * 0.01
        
        min_lat = min(lats) - buffer_deg
        max_lat = max(lats) + buffer_deg
        min_lon = min(lons) - buffer_deg
        max_lon = max(lons) + buffer_deg
        
        all_sites = self.get_construction_sites_in_bbox(min_lat, min_lon, max_lat, max_lon)
        
        # Filtere Baustellen die tatsächlich die Route beeinflussen
        # (vereinfacht: wenn Baustelle in Buffer-Bereich)
        nearby_sites = []
        for site in all_sites:
            # Prüfe ob Baustelle nahe genug an Route ist
            min_distance = self._min_distance_to_route(site, route_geometry)
            if min_distance <= buffer_km:
                nearby_sites.append(site)
        
        self.logger.info(f"[CONSTRUCTION] {len(nearby_sites)} Baustellen nahe Route")
        return nearby_sites
    
    def check_route_through_construction(
        self,
        route_geometry: List[Tuple[float, float]]
    ) -> Tuple[bool, List[ConstructionSite]]:
        """
        Prüft ob eine Route durch Baustellen führt.
        
        Args:
            route_geometry: Liste von (lat, lon) Koordinaten der Route
            
        Returns:
            Tuple (führt_durch_baustelle, betroffene_baustellen)
        """
        nearby_sites = self.get_construction_sites_near_route(route_geometry, buffer_km=0.1)
        
        # Vereinfachte Prüfung: Wenn Baustelle sehr nah an Route ist
        # (in Produktion: präzise Geometrie-Intersection)
        affected_sites = []
        for site in nearby_sites:
            min_dist = self._min_distance_to_route(site, route_geometry)
            if min_dist < 0.05:  # < 50m
                affected_sites.append(site)
        
        return len(affected_sites) > 0, affected_sites
    
    def _parse_overpass_response(self, data: Dict) -> List[ConstructionSite]:
        """Parse Overpass API Response zu ConstructionSite Objekten"""
        sites = []
        
        elements = data.get("elements", [])
        for element in elements:
            if element.get("type") not in ["way", "relation"]:
                continue
            
            tags = element.get("tags", {})
            
            # Baustellen-Typ bestimmen
            construction_type = tags.get("construction", "road_construction")
            if "highway" in tags and tags["highway"] == "construction":
                construction_type = "road_construction"
            
            # Geometrie extrahieren
            geometry = []
            if "geometry" in element:
                for point in element["geometry"]:
                    geometry.append((point["lat"], point["lon"]))
            elif "lat" in element and "lon" in element:
                geometry.append((element["lat"], element["lon"]))
            
            if not geometry:
                continue
            
            # Zentrum berechnen (für Marker)
            center_lat = sum(coord[0] for coord in geometry) / len(geometry)
            center_lon = sum(coord[1] for coord in geometry) / len(geometry)
            
            site = ConstructionSite(
                id=f"{element['type']}_{element['id']}",
                lat=center_lat,
                lon=center_lon,
                geometry=geometry,
                construction_type=construction_type,
                description=tags.get("note") or tags.get("description"),
                start_date=tags.get("start_date"),
                end_date=tags.get("end_date"),
                access_restriction=tags.get("access"),
                osm_tags=tags
            )
            
            sites.append(site)
        
        return sites
    
    def _min_distance_to_route(self, site: ConstructionSite, route: List[Tuple[float, float]]) -> float:
        """
        Berechnet minimale Distanz zwischen Baustelle und Route (in km).
        Vereinfachte Implementierung: Distanz zum nächsten Route-Punkt.
        """
        if not route or not site.geometry:
            return float('inf')
        
        min_dist = float('inf')
        
        # Für jeden Punkt der Route: Distanz zu Baustellen-Zentrum
        for route_lat, route_lon in route:
            dist = ConstructionService._haversine_distance(
                route_lat, route_lon, site.lat, site.lon
            )
            min_dist = min(min_dist, dist)
        
        return min_dist
    
    @staticmethod
    def _haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Haversine-Distanz in Kilometern"""
        import math
        R = 6371.0
        lat1_rad = math.radians(lat1)
        lat2_rad = math.radians(lat2)
        delta_lat = math.radians(lat2 - lat1)
        delta_lon = math.radians(lon2 - lon1)
        
        a = (
            math.sin(delta_lat / 2) ** 2 +
            math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(delta_lon / 2) ** 2
        )
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return R * c

