"""
Traffic Data Service - Live-Verkehrsdaten
Optionaler Service für weitere Verkehrsdaten (Ergänzung zu Baustellen)
"""

import os
import logging
from typing import List, Dict, Optional
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class TrafficCondition:
    """Datenstruktur für Verkehrslage"""
    lat: float
    lon: float
    severity: str  # "low", "medium", "high", "severe"
    delay_minutes: int
    description: Optional[str]


class TrafficDataService:
    """
    Service für Live-Verkehrsdaten.
    Aktuell fokussiert auf Baustellen (via ConstructionService).
    Kann später erweitert werden für:
    - Mapbox Traffic API
    - HERE Traffic API
    - Community-basierte Daten
    """
    
    def __init__(self):
        """Initialisiert den Traffic Data Service"""
        self.logger = logger
        self.mapbox_token = os.getenv("MAPBOX_ACCESS_TOKEN")
        
        # Importiere Construction Service für Baustellen
        try:
            from services.construction_service import ConstructionService
            self.construction_service = ConstructionService()
        except Exception as e:
            self.logger.warning(f"[TRAFFIC] Construction Service nicht verfügbar: {e}")
            self.construction_service = None
    
    def get_traffic_conditions_in_area(
        self,
        min_lat: float,
        min_lon: float,
        max_lat: float,
        max_lon: float
    ) -> List[TrafficCondition]:
        """
        Holt Verkehrslagen in einem Gebiet.
        
        Args:
            min_lat, min_lon, max_lat, max_lon: Bounding Box
            
        Returns:
            Liste von Verkehrslagen
        """
        conditions = []
        
        # Baustellen als Verkehrslagen einbeziehen
        if self.construction_service:
            construction_sites = self.construction_service.get_construction_sites_in_bbox(
                min_lat, min_lon, max_lat, max_lon
            )
            
            for site in construction_sites:
                # Schätze Verzögerung basierend auf Baustellen-Typ
                delay_minutes = self._estimate_construction_delay(site)
                
                condition = TrafficCondition(
                    lat=site.lat,
                    lon=site.lon,
                    severity="high" if delay_minutes > 10 else "medium",
                    delay_minutes=delay_minutes,
                    description=f"Baustelle: {site.construction_type}"
                )
                conditions.append(condition)
        
        # Hier könnten weitere Datenquellen integriert werden:
        # - Mapbox Traffic API
        # - HERE Traffic API
        # etc.
        
        return conditions
    
    def _estimate_construction_delay(self, site) -> int:
        """Schätzt Verzögerung in Minuten basierend auf Baustellen-Typ"""
        # Vereinfachte Schätzung
        construction_type = site.construction_type.lower()
        
        if "bridge" in construction_type or "tunnel" in construction_type:
            return 15  # Höhere Verzögerung bei Brücken/Tunneln
        elif "road_construction" in construction_type:
            return 10  # Standard Baustelle
        elif site.access_restriction == "no":
            return 20  # Komplette Sperrung
        else:
            return 5  # Leichte Einschränkung

