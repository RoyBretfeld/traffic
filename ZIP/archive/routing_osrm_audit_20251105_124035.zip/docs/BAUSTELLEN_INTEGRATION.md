# Baustellen-Integration und OSRM-Fix

## Übersicht

Diese Implementierung fügt Baustellen-Daten aus OpenStreetMap in die Routing-Berechnung ein und behebt das Problem, dass OSRM-Routen nicht vollständig gezeichnet wurden.

## Änderungen

### 1. OSRM-Routing Fix

**Problem:** OSRM-Routen wurden nicht vollständig gezeichnet, weil `overview=false` verwendet wurde.

**Lösung:**
- `services/osrm_client.py`: `overview=false` → `overview=full` geändert
- `geometries=polyline` Parameter hinzugefügt
- Geometrie-Validierung implementiert

**Dateien:**
- `services/osrm_client.py`

### 2. Baustellen-Service

**Neuer Service:** `services/construction_service.py`

Holt Baustellen-Daten aus OpenStreetMap über Overpass API:
- Abfrage für `highway=construction`, `construction=*` Tags
- Barrieren und Zugangsbeschränkungen
- Caching für 1 Stunde

**Funktionen:**
- `get_construction_sites_in_bbox()` - Baustellen in Bounding Box
- `get_construction_sites_near_route()` - Baustellen nahe Route
- `check_route_through_construction()` - Prüft ob Route durch Baustelle führt

### 3. Routing-Integration

**Datei:** `backend/services/real_routing.py`

Baustellen werden automatisch in Routing-Berechnung einbezogen:
- Prüft ob Route durch Baustellen führt
- Fügt Verzögerungen hinzu (10-20 Min je nach Typ)
- Markiert umfahrene Baustellen in `avoided_issues`
- Setzt `construction_avoided` Flag

### 4. API-Endpoints

**Neue Datei:** `routes/traffic_api.py`

Endpoints:
- `GET /api/traffic/construction/nearby` - Baustellen in der Nähe
- `GET /api/traffic/construction/bbox` - Baustellen in Bounding Box
- `POST /api/traffic/construction/route-check` - Prüft Route gegen Baustellen
- `GET /api/traffic/conditions` - Verkehrslagen

### 5. Frontend-Integration

**Datei:** `frontend/index.html`

Neue Features:
- Baustellen werden automatisch beim Karten-Start geladen
- Orange Marker für Baustellen
- Popup mit Baustellen-Informationen
- Geometrie wird als gestrichelte Linie angezeigt
- Toggle-Button in Navbar zum Ein-/Ausblenden
- Auto-Update bei Kartenbewegung

## Verwendung

### Backend

Baustellen werden automatisch in Routing-Berechnung einbezogen:

```python
from backend.services.real_routing import RealRoutingService, RoutePoint

service = RealRoutingService()
route = await service.calculate_route([
    RoutePoint(lat=51.0, lon=13.7, address="Start", name="Start"),
    RoutePoint(lat=51.1, lon=13.8, address="Ziel", name="Ziel")
])

# Route enthält jetzt:
# - total_traffic_delay: Verzögerung durch Baustellen
# - avoided_issues: Liste umfahrener Baustellen
# - segments[].construction_avoided: Flag
```

### API

```bash
# Baustellen in Bounding Box
GET /api/traffic/construction/bbox?min_lat=51.0&min_lon=13.7&max_lat=51.1&max_lon=13.8

# Baustellen nahe Punkt
GET /api/traffic/construction/nearby?lat=51.0&lon=13.7&radius_km=5.0

# Route prüfen
POST /api/traffic/construction/route-check
Body: {"route_geometry": [[51.0, 13.7], [51.1, 13.8]]}
```

### Frontend

Baustellen werden automatisch angezeigt. Toggle-Button in Navbar zum Ein-/Ausblenden.

## Konfiguration

Umgebungsvariablen:
- `OVERPASS_API_URL` - Overpass API URL (Standard: `https://overpass-api.de/api/interpreter`)

## Technische Details

### Baustellen-Typen

- `road_construction` - Standard Straßenbaustelle (10 Min Verzögerung)
- `bridge`/`tunnel` - Brücken/Tunnel-Baustelle (15 Min Verzögerung)
- `access=no` - Komplette Sperrung (20 Min Verzögerung)

### Caching

Baustellen-Daten werden für 1 Stunde gecacht, um Overpass API zu schonen.

### Performance

- Overpass API Queries sind asynchron
- Timeout: 25 Sekunden
- Auto-Update bei Kartenbewegung

## Nächste Schritte

- Erweiterte Geometrie-Intersection für präzise Prüfung
- OSRM Alternative Routes für Umfahrungen
- Integration weiterer Verkehrsdaten (Staus, Unfälle)

