# tools/corrections_cli.py
from __future__ import annotations
import argparse
import sys
from pathlib import Path

# Pfad zum Projekt-Root hinzufügen
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from backend.services.address_corrections import AddressCorrectionStore


def main():
    ap = argparse.ArgumentParser(description="Adress-Korrekturen verwalten")
    ap.add_argument("db", type=Path, help="Pfad zur SQLite-Datei (z. B. data/address_corrections.sqlite3)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list", help="Ausstehende (pending) Korrekturen anzeigen")

    p_res = sub.add_parser("resolve", help="Eintrag korrigieren")
    p_res.add_argument("key", help="Key des zu korrigierenden Eintrags")
    p_res.add_argument("lat", type=float, help="Breitengrad")
    p_res.add_argument("lon", type=float, help="Längengrad")
    p_res.add_argument("--street", default=None, help="Optional korrigierte Straße")
    p_res.add_argument("--source", default="manual", help="Quelle der Korrektur (Standard: manual)")
    p_res.add_argument("--confidence", type=float, default=1.0, help="Konfidenz (Standard: 1.0)")

    p_exp = sub.add_parser("export", help="Korrekturen als CSV exportieren")
    p_exp.add_argument("path", type=Path, help="Pfad zur CSV-Datei")

    p_imp = sub.add_parser("import", help="Korrekturen aus CSV importieren")
    p_imp.add_argument("path", type=Path, help="Pfad zur CSV-Datei")

    args = ap.parse_args()
    store = AddressCorrectionStore(args.db)

    if args.cmd == "list":
        items = store.list_pending()
        if not items:
            print("Keine ausstehenden Korrekturen gefunden.")
            return
        print(f"Gefunden: {len(items)} ausstehende Korrekturen\n")
        for item in items:
            print(f"{item['key']}")
            print(f"  {item['street']}, {item['postal_code']} {item['city']}")
            print(f"  {item['times_seen']}x gesehen, zuletzt: {item['last_seen']}")
            print()
    elif args.cmd == "resolve":
        try:
            store.resolve(args.key, args.lat, args.lon, street_canonical=args.street, source=args.source, confidence=args.confidence)
            print(f"OK: Gespeichert und markiert als resolved")
        except KeyError as e:
            print(f"FEHLER: {e}", file=sys.stderr)
            sys.exit(1)
    elif args.cmd == "export":
        store.export_csv(args.path)
        print(f"Export: {args.path}")
    elif args.cmd == "import":
        n = store.import_csv(args.path)
        print(f"Importiert: {n} Einträge")


if __name__ == "__main__":
    main()

