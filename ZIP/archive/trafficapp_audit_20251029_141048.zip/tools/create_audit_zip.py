#!/usr/bin/env python3
"""
Erstellt eine Zip-Datei mit allen relevanten Programmdateien für Code-Audit.
Keine Dependencies, keine kompilierten Dateien, keine temporären Dateien.
"""
from __future__ import annotations
import os
import zipfile
from pathlib import Path
from datetime import datetime

# Verzeichnis-Struktur für Audit
AUDIT_INCLUDES = {
    # Backend Code
    "backend/": {
        "include": ["**/*.py"],
        "exclude": ["**/__pycache__/**", "**/*.pyc", "**/*.pyo"]
    },
    # Services
    "services/": {
        "include": ["**/*.py"],
        "exclude": ["**/__pycache__/**", "**/*.pyc"]
    },
    # Routes
    "routes/": {
        "include": ["**/*.py"],
        "exclude": ["**/__pycache__/**"]
    },
    # Tools
    "tools/": {
        "include": ["**/*.py"],
        "exclude": ["**/__pycache__/**", "**/test_*.py"]  # Test-Scripts optional
    },
    # Admin
    "admin/": {
        "include": ["**/*.py"],
        "exclude": ["**/__pycache__/**"]
    },
    # Tests
    "tests/": {
        "include": ["test_*.py", "**/test_*.py"],
        "exclude": ["**/__pycache__/**", "**/*.pyc", "**/data/**"]
    },
    # Datenbank-Schema
    "db/": {
        "include": ["**/*.sql"],
        "exclude": []
    },
    # Migrations
    "migrations/": {
        "include": ["**/*.sql"],
        "exclude": []
    },
    # Dokumentation
    "docs/": {
        "include": ["**/*.md"],
        "exclude": []
    },
    # Config
    "": {
        "include": [
            "*.py",  # start_server.py, app_startup.py, etc.
            "*.md",  # README.md, etc.
            "*.txt",  # requirements.txt, etc.
            "*.yml",  # docker-compose, etc.
            "*.yaml", # pre-commit-config, etc.
            ".github/workflows/*.yml",  # CI/CD
            "monitoring/**/*.yml",
            "monitoring/**/*.json",
        ],
        "exclude": [
            "**/__pycache__/**",
            "**/*.pyc",
            "**/node_modules/**",
            "**/.git/**",
            "**/venv/**",
            "**/.venv/**",
            "**/env/**",
            "**/*.egg-info/**",
            "**/dist/**",
            "**/build/**",
            "**/.pytest_cache/**",
        ]
    }
}

# Globale Excludes (immer ausgeschlossen)
GLOBAL_EXCLUDES = {
    "__pycache__",
    "*.pyc",
    "*.pyo",
    "*.pyd",
    ".pytest_cache",
    ".git",
    "node_modules",
    "venv",
    ".venv",
    "env",
    ".env",
    "*.egg-info",
    "dist",
    "build",
    ".DS_Store",
    "*.log",
    "*.tmp",
    ".idea",
    ".vscode",
    "data/*.sqlite3",  # Datenbanken ausgeschlossen
    "data/*.db",
    "logs",
    "temp",
    "tmp",
}


def should_exclude(path: Path) -> bool:
    """Prüft ob Pfad ausgeschlossen werden soll."""
    path_str = str(path).replace("\\", "/")
    
    # Prüfe globale Excludes
    for exclude in GLOBAL_EXCLUDES:
        if exclude in path_str or path.name.startswith(exclude.replace("*", "")):
            return True
    
    # Prüfe auf versteckte Dateien (außer .github)
    if path.name.startswith(".") and ".github" not in path_str:
        return True
    
    return False


def collect_files(base_path: Path) -> list[tuple[Path, str]]:
    """Sammelt alle relevanten Dateien für Audit."""
    files_to_zip = []
    
    for dir_pattern, config in AUDIT_INCLUDES.items():
        if dir_pattern == "":
            # Root-Level Dateien
            search_path = base_path
        else:
            search_path = base_path / dir_pattern.rstrip("/")
        
        if not search_path.exists():
            continue
        
        includes = config.get("include", [])
        excludes = config.get("exclude", [])
        
        # Sammle Dateien
        for pattern in includes:
            for file_path in search_path.glob(pattern):
                if not file_path.is_file():
                    continue
                
                # Prüfe Excludes
                if should_exclude(file_path):
                    continue
                
                # Prüfe pattern-spezifische Excludes
                file_str = str(file_path).replace("\\", "/")
                if any(exc.replace("*", "") in file_str for exc in excludes):
                    continue
                
                # Relative Pfad für Zip
                try:
                    rel_path = file_path.relative_to(base_path)
                    files_to_zip.append((file_path, str(rel_path)))
                except ValueError:
                    continue
    
    # Deduplizieren
    seen = set()
    unique_files = []
    for file_path, rel_path in files_to_zip:
        if rel_path not in seen:
            seen.add(rel_path)
            unique_files.append((file_path, rel_path))
    
    return sorted(unique_files, key=lambda x: x[1])


def create_audit_zip(output_dir: Path = None) -> Path:
    """Erstellt Zip-Datei für Code-Audit."""
    if output_dir is None:
        output_dir = Path("zip")
    
    output_dir.mkdir(parents=True, exist_ok=True)
    
    base_path = Path.cwd()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_filename = output_dir / f"trafficapp_audit_{timestamp}.zip"
    
    print(f"[*] Erstelle Audit-Zip: {zip_filename}")
    print(f"[*] Base-Pfad: {base_path}\n")
    
    # Sammle Dateien
    files = collect_files(base_path)
    
    print(f"[*] Gefunden: {len(files)} Dateien\n")
    
    # Erstelle Zip
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for file_path, rel_path in files:
            try:
                zipf.write(file_path, rel_path)
                if len(files) <= 50:  # Nur bei wenigen Dateien ausgeben
                    print(f"  [+] {rel_path}")
            except Exception as e:
                print(f"  [-] Fehler bei {rel_path}: {e}")
    
    file_size_mb = zip_filename.stat().st_size / (1024 * 1024)
    print(f"\n[+] Zip erstellt: {zip_filename}")
    print(f"[*] Groesse: {file_size_mb:.2f} MB")
    print(f"[*] Dateien: {len(files)}")
    
    return zip_filename


def main():
    """Hauptfunktion."""
    import sys
    
    output_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("zip")
    zip_file = create_audit_zip(output_dir)
    
    print(f"\n[+] Audit-Paket bereit: {zip_file}")
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())

