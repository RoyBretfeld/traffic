# tools/code_health_monitor.py
"""
Code-Gesundheits-Monitor mit KI-Integration
Analysiert Code-Qualität, Modularität und potenzielle Probleme.
"""
from __future__ import annotations
import ast
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Any
import json


class CodeHealthAnalyzer:
    """Analysiert Code-Gesundheit ohne externe Dependencies."""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
    
    def analyze_modularity(self, file_path: Path) -> Dict[str, Any]:
        """Analysiert Modularität einer Datei."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                tree = ast.parse(content, filename=str(file_path))
            
            imports = []
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        imports.append(alias.name)
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        imports.append(node.module)
            
            # Klassifiziere Imports
            external = []
            internal = []
            stdlib = []
            
            stdlib_modules = {
                'os', 'sys', 're', 'json', 'csv', 'pathlib', 'tempfile',
                'typing', 'dataclasses', 'collections', 'datetime', 'sqlite3'
            }
            
            for imp in imports:
                if imp.split('.')[0] in stdlib_modules:
                    stdlib.append(imp)
                elif imp.startswith('backend.') or imp.startswith('services.') or imp.startswith('repositories.'):
                    internal.append(imp)
                else:
                    external.append(imp)
            
            return {
                "file": str(file_path.relative_to(self.project_root)),
                "total_imports": len(imports),
                "stdlib_imports": len(stdlib),
                "internal_imports": len(internal),
                "external_imports": len(external),
                "internal_imports_list": internal,
                "coupling_score": len(internal),  # Niedriger = besser
                "modular": len(internal) <= 1  # Gut modular wenn max 1 interne Dependency
            }
        except Exception as e:
            return {
                "file": str(file_path.relative_to(self.project_root)),
                "error": str(e)
            }
    
    def analyze_address_corrections_system(self) -> Dict[str, Any]:
        """Analysiert Adress-Korrektur-System."""
        files = [
            "backend/services/address_corrections.py",
            "backend/services/geocoder_correction_aware.py",
            "tools/corrections_cli.py"
        ]
        
        results = []
        for file_rel in files:
            file_path = self.project_root / file_rel
            if file_path.exists():
                results.append(self.analyze_modularity(file_path))
        
        return {
            "system": "address_corrections",
            "files": results,
            "summary": {
                "total_files": len(results),
                "all_modular": all(r.get("modular", False) for r in results),
                "avg_coupling": sum(r.get("coupling_score", 0) for r in results) / len(results) if results else 0
            }
        }
    
    def run_pytest_tests(self) -> Dict[str, Any]:
        """Führt Pytest-Tests aus und sammelt Ergebnisse."""
        test_files = [
            "tests/test_address_corrections_unit.py",
            "tests/test_geocoder_correction_aware_unit.py",
            "tests/test_address_corrections_integration.py",
            "tests/test_address_corrections_modularity.py",
            "tests/test_address_corrections_flow.py"
        ]
        
        existing_tests = [f for f in test_files if (self.project_root / f).exists()]
        
        if not existing_tests:
            return {
                "status": "no_tests",
                "message": "Keine Test-Dateien gefunden"
            }
        
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pytest", "-v", "--tb=short", "--json-report", "--json-report-file=-"] + existing_tests,
                capture_output=True,
                text=True,
                cwd=self.project_root,
                timeout=300
            )
            
            # Versuche JSON-Report zu parsen
            try:
                json_output = json.loads(result.stdout)
                return {
                    "status": "success",
                    "tests_found": len(existing_tests),
                    "exit_code": result.returncode,
                    "summary": json_output.get("summary", {})
                }
            except json.JSONDecodeError:
                # Fallback: Parse normale pytest-Ausgabe
                lines = result.stdout.split('\n')
                passed = len([l for l in lines if 'PASSED' in l])
                failed = len([l for l in lines if 'FAILED' in l])
                
                return {
                    "status": "success",
                    "tests_found": len(existing_tests),
                    "exit_code": result.returncode,
                    "passed": passed,
                    "failed": failed,
                    "stdout": result.stdout[-500:]  # Letzte 500 Zeichen
                }
        except subprocess.TimeoutExpired:
            return {
                "status": "timeout",
                "message": "Tests überschritten Timeout von 300 Sekunden"
            }
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def generate_health_report(self) -> Dict[str, Any]:
        """Generiert vollständigen Gesundheits-Report."""
        return {
            "project_root": str(self.project_root),
            "modularity": self.analyze_address_corrections_system(),
            "tests": self.run_pytest_tests()
        }


def main():
    """Hauptfunktion für CLI-Nutzung."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Code-Gesundheits-Monitor")
    parser.add_argument("--project-root", type=Path, default=Path.cwd(), help="Projekt-Root-Verzeichnis")
    parser.add_argument("--json", action="store_true", help="JSON-Output")
    parser.add_argument("--tests-only", action="store_true", help="Nur Tests ausführen")
    
    args = parser.parse_args()
    
    analyzer = CodeHealthAnalyzer(args.project_root)
    
    if args.tests_only:
        report = analyzer.run_pytest_tests()
    else:
        report = analyzer.generate_health_report()
    
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print("\n" + "="*60)
        print("CODE-GESUNDHEITS-REPORT")
        print("="*60)
        
        if "modularity" in report:
            mod = report["modularity"]
            print(f"\n📦 Modularität ({mod['summary']['total_files']} Dateien):")
            for f in mod["files"]:
                status = "✅" if f.get("modular") else "⚠️"
                print(f"  {status} {f['file']}: {f.get('internal_imports', 0)} interne Dependencies")
            print(f"\n  Durchschnittliches Coupling: {mod['summary']['avg_coupling']:.1f}")
            print(f"  Alle modular: {'✅' if mod['summary']['all_modular'] else '⚠️'}")
        
        if "tests" in report:
            tests = report["tests"]
            print(f"\n🧪 Tests:")
            if tests.get("status") == "success":
                print(f"  ✅ {tests.get('tests_found', 0)} Test-Dateien gefunden")
                if "summary" in tests:
                    s = tests["summary"]
                    print(f"  Passed: {s.get('passed', '?')}")
                    print(f"  Failed: {s.get('failed', '?')}")
                elif "passed" in tests:
                    print(f"  Passed: {tests.get('passed', 0)}")
                    print(f"  Failed: {tests.get('failed', 0)}")
            else:
                print(f"  ⚠️ Status: {tests.get('status')}")
                print(f"  {tests.get('message', tests.get('error', ''))}")
        
        print("\n" + "="*60)


if __name__ == "__main__":
    main()

