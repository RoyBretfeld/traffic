# -*- coding: utf-8 -*-
"""
LLM-Code-Guard - KI-gestützte Code-Überwachung

Analysiert Code-Änderungen semantisch und erkennt potenzielle Risiken.
Funktioniert mit oder ohne LLM-API-Key (regelbasiert).
"""
from __future__ import annotations
import os
import subprocess
import json
import sys
import re
from pathlib import Path
from typing import List, Dict, Any, Optional

# Kritische Pfade: Änderungen hier besonders genau prüfen
CRITICAL_PATHS = [
    r"^backend/parsers/",
    r"^routes/tourplan_",
    r"^backend/services/",
    r"^ingest/",
    r"^services/geocode",
    r"^repositories/",
]

PROMPT_SYSTEM = """Du bist ein erfahrener Code-Reviewer für eine Python FastAPI-Anwendung.

Prüfe die folgenden Code-Änderungen auf:
- Breaking Changes (API-Brüche, Signatur-Änderungen)
- Fehlende Fehlerbehandlung
- Potenzielle Performance-Probleme
- Fehlende Tests für neue/changed Funktionen
- Unerwartete Seiteneffekte
- Sicherheitsrisiken

Antworte strukturiert mit:
1. Kritische Probleme (Priority: HIGH)
2. Warnungen (Priority: MEDIUM)
3. Verbesserungsvorschläge (Priority: LOW)

Halte die Antwort kurz und präzise (max. 300 Wörter)."""


def _git(cmd: List[str]) -> str:
    """Führt Git-Befehl aus."""
    # Windows-kompatible Encoding-Behandlung
    r = subprocess.run(
        ["git", *cmd],
        capture_output=True,
        text=True,
        encoding='utf-8',
        errors='replace',  # Ersetze ungültige Zeichen statt Fehler
        cwd=Path.cwd()
    )
    if r.returncode != 0:
        raise RuntimeError(f"Git command failed: {' '.join(cmd)}\n{r.stderr}")
    return r.stdout.strip()


def get_diff(base: str = 'origin/main') -> str:
    """Holt Git-Diff zwischen base und HEAD."""
    try:
        _git(["fetch", "origin", "--depth", "1"])
    except Exception:
        pass  # Best effort
    
    try:
        return _git(["diff", f"{base}...HEAD", "--", "."])
    except RuntimeError:
        # Fallback: Diff gegen aktuellen Branch
        try:
            return _git(["diff", "HEAD^", "HEAD", "--", "."])
        except Exception:
            return ""


def is_critical(path: str) -> bool:
    """Prüft ob Pfad zu kritischem Bereich gehört."""
    return any(re.match(p, path) for p in CRITICAL_PATHS)


def summarize_diff_names(diff_text: str) -> List[str]:
    """Extrahiert geänderte Dateinamen aus Diff."""
    names = set()
    for line in diff_text.splitlines():
        if line.startswith("+++") or line.startswith("---"):
            parts = line.split("\t")
            if len(parts) > 0:
                p = parts[-1].replace("a/", "").replace("b/", "").strip()
                if p and not p.startswith("/dev/null") and not p.startswith("/"):
                    names.add(p)
    return sorted(n for n in names if n.endswith(('.py', '.json', '.yml', '.yaml', '.sql')))


def rule_based_assessment(files: List[str]) -> List[str]:
    """Regelbasierte Risiko-Analyse."""
    risks = []
    
    critical_files = [f for f in files if is_critical(f)]
    if critical_files:
        risks.append(f"⚠️ KRITISCH: {len(critical_files)} Datei(en) in kritischen Bereichen geändert:")
        for f in critical_files[:5]:  # Max 5 auflisten
            risks.append(f"   - {f}")
    
    # Prüfe auf fehlende Tests
    changed_python = [f for f in files if f.endswith('.py') and 'test' not in f.lower()]
    test_files = [f for f in files if 'test' in f.lower()]
    
    if changed_python and not test_files:
        risks.append(f"⚠️ WARNUNG: {len(changed_python)} Python-Datei(en) geändert ohne Tests:")
        for f in changed_python[:3]:
            risks.append(f"   - {f}")
    
    # Prüfe auf Migration-Änderungen
    migrations = [f for f in files if 'migration' in f.lower() or f.endswith('.sql')]
    if migrations:
        risks.append(f"ℹ️ INFO: {len(migrations)} Migration(s) geändert - bitte prüfen")
    
    return risks


def call_llm(prompt: str, content: str, max_chars: int = 30000) -> str:
    """Ruft LLM-API auf (OpenAI oder lokal)."""
    key = os.getenv('OPENAI_API_KEY')
    if not key:
        return "(LLM deaktiviert – kein OPENAI_API_KEY gefunden)"
    
    # OpenAI API
    try:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=key)
            response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": content[:max_chars]}
                ],
                temperature=0.2,
                max_tokens=500
            )
            return response.choices[0].message.content.strip()
        except ImportError:
            # Fallback für alte OpenAI-Version
            import openai
            openai.api_key = key
            response = openai.ChatCompletion.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": content[:max_chars]}
                ],
                temperature=0.2,
                max_tokens=500
            )
            return response.choices[0].message.content.strip()
    except Exception as ex:
        return f"(LLM-Fehler: {ex})"


def analyze_with_llm(diff_text: str, files: List[str]) -> str:
    """Analysiert Diff mit LLM."""
    summary = f"Geänderte Dateien ({len(files)}):\n" + "\n".join(f"  - {f}" for f in files[:20])
    content = f"{summary}\n\n---\n\nDiff:\n\n{diff_text}"
    return call_llm(PROMPT_SYSTEM, content)


def main() -> int:
    """Hauptfunktion - gibt Exit-Code zurück (0=OK, 1=Kritisch)."""
    base = os.getenv('GIT_BASE', 'origin/main')
    
    try:
        diff = get_diff(base)
    except Exception as e:
        try:
            print(f"[!] Warnung: Konnte Diff nicht ermitteln: {e}", file=sys.stderr)
        except UnicodeEncodeError:
            print(f"[!] Warnung: Konnte Diff nicht ermitteln: {e}", file=sys.stderr)
        diff = ""
    
    if not diff:
        try:
            print("[i] Keine Aenderungen gefunden oder nicht in Git-Repository")
        except UnicodeEncodeError:
            print("[i] Keine Aenderungen gefunden oder nicht in Git-Repository")
        return 0
    
    files = summarize_diff_names(diff)
    
    if not files:
        try:
            print("[i] Keine relevanten Dateien geaendert")
        except UnicodeEncodeError:
            print("[i] Keine relevanten Dateien geaendert")
        return 0
    
    try:
        print(f"\n[*] Analysiere {len(files)} geaenderte Datei(en)...\n")
    except UnicodeEncodeError:
        print(f"\n[*] Analysiere {len(files)} geaenderte Datei(en)...\n")
    
    # Regelbasierte Analyse
    rules = rule_based_assessment(files)
    
    # LLM-Analyse
    llm_result = analyze_with_llm(diff, files)
    
    # Report erstellen
    report = {
        "changed_files": files,
        "changed_files_count": len(files),
        "critical_files": [f for f in files if is_critical(f)],
        "rule_based_findings": rules,
        "llm_analysis": llm_result,
        "has_critical_changes": any("KRITISCH" in r for r in rules),
    }
    
    # Report speichern
    report_path = Path("llm_guard_report.json")
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )
    
    # Ausgabe (Windows-kompatibel - ohne Emojis falls Encoding-Probleme)
    try:
        print("=" * 60)
        print("LLM-GUARD REPORT")
        print("=" * 60)
        print(f"\n[*] Geaenderte Dateien: {len(files)}")
        
        if report["critical_files"]:
            print(f"\n[!] Kritische Bereiche: {len(report['critical_files'])}")
            for f in report["critical_files"][:5]:
                print(f"   - {f}")
        
        if rules:
            print("\n[?] Regelbasierte Findings:")
            for r in rules:
                # Ersetze Emojis für Windows-Kompatibilität
                safe_r = r.replace("⚠️", "[!]").replace("ℹ️", "[i]")
                print(f"   {safe_r}")
        
        if llm_result and "(LLM deaktiviert" not in llm_result and "(LLM-Fehler" not in llm_result:
            print("\n[AI] LLM-Analyse:")
            print(f"   {llm_result[:500]}")  # Erste 500 Zeichen
        
        print(f"\n[*] Vollstaendiger Report: {report_path}")
        print("=" * 60)
    except UnicodeEncodeError:
        # Fallback ohne spezielle Zeichen
        print("=" * 60)
        print("LLM-GUARD REPORT")
        print("=" * 60)
        print(f"\nGeaenderte Dateien: {len(files)}")
        if report["critical_files"]:
            print(f"\nKritische Bereiche: {len(report['critical_files'])}")
        if rules:
            print("\nRegelbasierte Findings vorhanden")
        print(f"\nVollstaendiger Report: {report_path}")
        print("=" * 60)
    
    # Exit-Code: 1 bei kritischen Änderungen
    if report["has_critical_changes"]:
        try:
            print("\n[!] KRITISCH: Aenderungen in kritischen Bereichen erkannt!")
        except UnicodeEncodeError:
            print("\n[!] KRITISCH: Aenderungen in kritischen Bereichen erkannt!")
        return 1
    
    return 0


if __name__ == '__main__':
    sys.exit(main())

