#!/usr/bin/env python3
"""
Test-Script: Prüft ob alle wichtigen Endpunkte laufen
"""
import sys
import requests
from typing import List, Tuple

BASE_URL = "http://localhost:8111"

def test_endpoint(method: str, path: str, expected_status: int = 200) -> Tuple[bool, str]:
    """Testet einen Endpunkt."""
    try:
        url = f"{BASE_URL}{path}"
        if method == "GET":
            response = requests.get(url, timeout=5)
        elif method == "POST":
            response = requests.post(url, json={}, timeout=5)
        else:
            return False, f"Unbekannte Methode: {method}"
        
        success = response.status_code == expected_status or response.status_code < 500
        status = "OK" if success else "FAILED"
        return success, f"{status} [{response.status_code}] {path}"
    except requests.exceptions.ConnectionError:
        return False, f"CONNECTION ERROR - Server läuft nicht auf {BASE_URL}"
    except Exception as e:
        return False, f"ERROR: {e}"

def main():
    print("=" * 60)
    print("ENDPOINT-TEST")
    print("=" * 60)
    print(f"Prüfe Server auf: {BASE_URL}\n")
    
    # Core-Endpunkte (müssen funktionieren)
    core_endpoints = [
        ("GET", "/", 200),
        ("GET", "/docs", 200),
        ("GET", "/health", 200),
        ("GET", "/api/status", 200),
        ("GET", "/api/llm/status", 200),
    ]
    
    # Optional-Endpunkte (können fehlen)
    optional_endpoints = [
        ("GET", "/metrics", 200),  # Benötigt prometheus-client
        ("GET", "/admin/address/", 200),  # Benötigt Integration
    ]
    
    print("Core-Endpunkte:")
    print("-" * 60)
    results = []
    for method, path, expected in core_endpoints:
        success, msg = test_endpoint(method, path, expected)
        results.append((success, msg))
        symbol = "✅" if success else "❌"
        print(f"{symbol} {msg}")
    
    print("\nOptionale Endpunkte:")
    print("-" * 60)
    for method, path, expected in optional_endpoints:
        success, msg = test_endpoint(method, path, expected)
        symbol = "✅" if success else "⚠️"
        print(f"{symbol} {msg}")
        if not success and "metrics" in path:
            print("   → Installiere: pip install prometheus-client")
        elif not success and "admin/address" in path:
            print("   → Verfügbar als Standalone auf Port 8000")
            print("   → Oder integriere in backend/app.py")
    
    print("\n" + "=" * 60)
    core_failed = [r for r in results if not r[0]]
    if core_failed:
        print(f"❌ {len(core_failed)} Core-Endpunkt(e) fehlgeschlagen")
        print("\nPrüfe:")
        print("  1. Server läuft? → python start_server.py")
        print("  2. Port 8111 frei?")
        print("  3. Dependencies installiert?")
        return 1
    else:
        print("✅ Alle Core-Endpunkte funktionieren!")
        return 0

if __name__ == "__main__":
    try:
        import requests
    except ImportError:
        print("❌ 'requests' nicht installiert")
        print("   Installiere: pip install requests")
        sys.exit(1)
    
    sys.exit(main())

