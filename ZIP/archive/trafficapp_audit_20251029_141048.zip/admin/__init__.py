# admin/__init__.py
"""Admin-Module für FAMO TrafficApp"""

