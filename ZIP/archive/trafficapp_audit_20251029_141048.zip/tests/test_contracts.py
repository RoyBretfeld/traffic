# -*- coding: utf-8 -*-
"""
Contract Tests für FAMO TrafficApp Module
Prüft grobe "Contracts" - wenn Module fehlen, werden sie xfailed statt rot.
So kann Cursor gezielt fehlende Teile ergänzen.
"""

import importlib
from typing import Any, Dict, List
import pytest

def _try_import(name: str):
    """Versucht ein Modul zu importieren, gibt xfail bei Fehlern"""
    try:
        return importlib.import_module(name)
    except Exception as ex:
        pytest.xfail(f"Modul {name} fehlt oder Importfehler: {ex}")


def test_csv_reader_contract():
    """Testet das CSV-Reader Modul Contract"""
    mod = _try_import("ingest.csv_reader")
    
    # Class-API bevorzugt
    rows = None
    if hasattr(mod, "CSVReader"):
        try:
            reader = mod.CSVReader(encoding="utf-8")
            rows = reader.read("tour_id;order_id\nA;1\n".encode("utf-8"))
        except Exception as e:
            # CSV-Reader kann verschiedene APIs haben
            print(f"CSVReader API-Fehler: {e}")
    else:
        # Fallback auf Funktions-API
        for fname in ("read", "read_csv", "parse_csv"):
            if hasattr(mod, fname):
                try:
                    fn = getattr(mod, fname)
                    rows = fn("tour_id;order_id\nA;1\n")
                    break
                except Exception as e:
                    print(f"{fname} API-Fehler: {e}")
                    continue
    
    # Wenn keine passende API gefunden wurde, ist das OK für Contract-Tests
    if rows is None:
        pytest.xfail("CSV-Reader API nicht kompatibel oder nicht implementiert")
    
    assert rows is not None and len(rows) >= 1, "CSV-Reader sollte Daten zurückgeben"


def test_tour_parser_contract():
    """Testet das Tour-Plan-Parser Modul Contract"""
    mod = _try_import("backend.parsers.tour_plan_parser")
    
    # Testdaten erstellen (als CSV-String, da Parser wahrscheinlich Dateipfad erwartet)
    test_csv_content = "tour_id;order_id;customer;street;postal_code;city;lat;lon\nA;1;X;A-Straße 1;01067;Dresden;51.05;13.74"
    
    # Verschiedene mögliche Entry-Points testen
    for fname in ("parse_tour_plan", "parse", "run", "build_model"):
        if hasattr(mod, fname):
            fn = getattr(mod, fname)
            try:
                # Versuche verschiedene Parameter-Typen
                if fname == "parse_tour_plan":
                    # Dieser Parser erwartet wahrscheinlich einen Dateipfad
                    pytest.xfail("parse_tour_plan erwartet Dateipfad, nicht Daten")
                else:
                    out = fn(test_csv_content)
                    assert out is not None, f"{fname} sollte Ergebnis zurückgeben"
                    break
            except Exception as e:
                print(f"{fname} API-Fehler: {e}")
                continue
    else:
        pytest.xfail("Kein Parser-EntryPoint gefunden (parse_tour_plan/parse/run/build_model)")


def test_match_contract():
    """Testet das Tour-Matching Modul Contract"""
    mod = _try_import("routes.tourplan_match")
    
    # Testdaten erstellen
    dummy = [{"tour_id": "A", "stops": [{"lat": 51.05, "lon": 13.74}]}]
    
    # Verschiedene mögliche Entry-Points testen
    for fname in ("match_tourplan", "match", "assign", "build_routes"):
        if hasattr(mod, fname):
            fn = getattr(mod, fname)
            out = fn(dummy)
            assert out is not None, f"{fname} sollte Ergebnis zurückgeben"
            break
    else:
        pytest.xfail("Kein Matching-EntryPoint gefunden (match_tourplan/match/assign/build_routes)")


def test_geocoding_contract():
    """Testet das Geocoding-Service Modul Contract"""
    mod = _try_import("services.geocode_fill")
    
    # Testdaten erstellen
    test_address = "Hauptstraße 1, 01067 Dresden"
    
    # Verschiedene mögliche Entry-Points testen
    for fname in ("geocode_address", "geocode", "process_address", "fill_coordinates"):
        if hasattr(mod, fname):
            fn = getattr(mod, fname)
            # Sollte nicht crashen, auch wenn kein Ergebnis
            try:
                out = fn(test_address)
                # Ergebnis kann None sein (wenn nicht geocodiert), das ist OK
                assert out is None or isinstance(out, (dict, tuple, list)), f"{fname} sollte dict/tuple/list oder None zurückgeben"
            except Exception as e:
                # Geocoding kann fehlschlagen, das ist normal
                assert "geocod" in str(e).lower() or "address" in str(e).lower(), f"Unerwarteter Fehler in {fname}: {e}"
            break
    else:
        pytest.xfail("Kein Geocoding-EntryPoint gefunden")


def test_database_contract():
    """Testet das Datenbank-Modul Contract"""
    mod = _try_import("db.database")
    
    # Verschiedene mögliche Entry-Points testen
    for fname in ("get_connection", "connect", "init_db", "create_tables"):
        if hasattr(mod, fname):
            fn = getattr(mod, fname)
            # Sollte nicht crashen
            try:
                out = fn()
                # Kann None sein (wenn DB nicht verfügbar)
                assert out is None or hasattr(out, "execute"), f"{fname} sollte DB-Connection oder None zurückgeben"
            except Exception as e:
                # DB kann nicht verfügbar sein, das ist OK für Tests
                assert "database" in str(e).lower() or "connection" in str(e).lower(), f"Unerwarteter DB-Fehler in {fname}: {e}"
            break
    else:
        pytest.xfail("Kein Datenbank-EntryPoint gefunden")


def test_api_contract():
    """Testet das API-Modul Contract"""
    mod = _try_import("backend.app")
    
    # Sollte FastAPI-App haben
    assert hasattr(mod, "app"), "API-Modul sollte 'app' Attribut haben"
    
    app = mod.app
    assert hasattr(app, "routes"), "FastAPI-App sollte 'routes' Attribut haben"
    
    # Sollte mindestens einen Route haben
    routes = getattr(app, "routes", [])
    assert len(routes) > 0, "API sollte mindestens eine Route haben"


def test_frontend_contract():
    """Testet das Frontend-Modul Contract"""
    # Prüfe ob Frontend-Dateien existieren
    from pathlib import Path
    
    root = Path(__file__).resolve().parents[1]
    frontend_dir = root / "frontend"
    
    if not frontend_dir.exists():
        pytest.xfail("Frontend-Verzeichnis fehlt")
    
    # Prüfe wichtige Frontend-Dateien
    important_files = ["index.html", "tourplan-management.html"]
    existing_files = [f for f in important_files if (frontend_dir / f).exists()]
    
    assert len(existing_files) > 0, f"Keine wichtigen Frontend-Dateien gefunden: {important_files}"
    
    # Prüfe ob HTML-Dateien gültig sind
    for file in existing_files:
        html_file = frontend_dir / file
        content = html_file.read_text(encoding="utf-8")
        assert "<html" in content.lower() or "<!doctype" in content.lower(), f"{file} sollte gültiges HTML sein"


def test_config_contract():
    """Testet das Config-Modul Contract"""
    mod = _try_import("config.settings")
    
    # Sollte Konfigurationswerte haben
    config_attrs = ["DATABASE_URL", "API_HOST", "API_PORT", "DEBUG"]
    found_attrs = [attr for attr in config_attrs if hasattr(mod, attr)]
    
    assert len(found_attrs) > 0, f"Config sollte mindestens einen dieser Werte haben: {config_attrs}"


def test_logging_contract():
    """Testet das Logging-Modul Contract"""
    mod = _try_import("logging_setup")
    
    # Sollte Logger-Funktionen haben
    logging_funcs = ["setup_logging", "get_logger", "configure_logging"]
    found_funcs = [func for func in logging_funcs if hasattr(mod, func)]
    
    assert len(found_funcs) > 0, f"Logging-Modul sollte mindestens eine dieser Funktionen haben: {logging_funcs}"
