# tests/test_address_corrections_flow.py
from __future__ import annotations
import tempfile
from pathlib import Path
import sys

# Projekt-Root zum Pfad hinzufügen
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from backend.services.address_corrections import AddressCorrectionStore, make_key, Correction
from backend.services.geocoder_correction_aware import CorrectionAwareGeocoder, parse_address_components


STREET_BAD = "Mügelnitzer Str. 10"  # bewusst diakritische Variante mit möglichem Geocoding-Problem

CSV1_ADDRESSES = [
    ("Hauptstraße 1", "01067", "Dresden"),
    (STREET_BAD, "01814", "Bad Schandau"),
]

CSV2_ADDRESSES = [
    (STREET_BAD, "01814", "Bad Schandau"),  # wieder "rot" in Import 2
]


def test_flow_persists_fix():
    """Test: Zeigt Flow von fehlgeschlagener Geocodierung über manuelle Korrektur bis automatischer Erkennung."""
    # Temporäre Datenbank erstellen
    db = Path(tempfile.gettempdir()) / "test_address_corrections.sqlite3"
    if db.exists():
        db.unlink()
    
    store = AddressCorrectionStore(db)
    
    # BaseGeocoder gibt immer None zurück (simuliert fehlgeschlagenes Geocoding)
    from backend.services.geocoder_correction_aware import BaseGeocoder
    geo = CorrectionAwareGeocoder(store, delegate=BaseGeocoder())

    # Import 1: Unresolved → landet in Queue
    print("=== Import 1: Fehlgeschlagene Geocodierungen ===")
    for street, pc, city in CSV1_ADDRESSES:
        lat, lon, msg = geo.geocode(street, pc, city)
        print(f"  {street}, {pc} {city}: lat={lat}, lon={lon}, msg={msg}")
        assert lat is None and lon is None
    
    # Prüfe Queue
    pend = store.list_pending()
    print(f"\nQueue-Status: {len(pend)} ausstehende Korrekturen")
    assert any(p['city'].lower() == 'bad schandau' for p in pend)
    
    # Manuell korrigieren (über resolve)
    print("\n=== Manuelle Korrektur ===")
    k = make_key(STREET_BAD, "01814", "Bad Schandau")
    store.resolve(k, 50.9197, 14.1533)  # Beispiel-Koordinaten
    print(f"  Key {k} korrigiert mit Koordinaten (50.9197, 14.1533)")
    
    # Prüfe dass Eintrag aus Queue entfernt wurde (status='resolved')
    pend_after = store.list_pending()
    pending_keys = [p['key'] for p in pend_after]
    assert k not in pending_keys, "Korrigierter Eintrag sollte nicht mehr in pending-Queue sein"
    
    # Import 2: Korrektur greift → direkt Koordinaten
    print("\n=== Import 2: Korrektur wird automatisch erkannt ===")
    lat, lon, msg = geo.geocode(STREET_BAD, "01814", "Bad Schandau")
    print(f"  {STREET_BAD}, 01814 Bad Schandau: lat={lat}, lon={lon}, msg={msg}")
    assert lat is not None and lon is not None
    assert abs(lat - 50.9197) < 0.0001
    assert abs(lon - 14.1533) < 0.0001
    
    print("\n=== Test erfolgreich! ===")


def test_parse_address_components():
    """Test: Adress-Parsing funktioniert korrekt."""
    test_cases = [
        ("Hauptstraße 1, 01067 Dresden", "Hauptstraße 1", "01067", "Dresden"),
        ("Mügelnitzer Str. 10, 01814 Bad Schandau", "Mügelnitzer Str. 10", "01814", "Bad Schandau"),
        ("Straße 42, 01234 Stadt", "Straße 42", "01234", "Stadt"),
    ]
    
    for full_addr, expected_street, expected_pc, expected_city in test_cases:
        street, pc, city = parse_address_components(full_addr)
        assert street == expected_street, f"Street mismatch: {street} != {expected_street}"
        assert pc == expected_pc, f"PLZ mismatch: {pc} != {expected_pc}"
        assert city == expected_city, f"City mismatch: {city} != {expected_city}"


def test_csv_export_import():
    """Test: CSV-Export und -Import funktionieren."""
    db = Path(tempfile.gettempdir()) / "test_export_import.sqlite3"
    if db.exists():
        db.unlink()
    
    store = AddressCorrectionStore(db)
    
    # Einige Korrekturen hinzufügen
    c1 = Correction(
        key=make_key("Teststraße 1", "01067", "Dresden"),
        street_canonical="Teststraße 1",
        postal_code="01067",
        city="Dresden",
        lat=51.05,
        lon=13.74,
        source="test",
        confidence=1.0
    )
    store.upsert(c1)
    
    # Exportieren
    csv_path = Path(tempfile.gettempdir()) / "test_export.csv"
    store.export_csv(csv_path)
    assert csv_path.exists()
    
    # Neue Datenbank und importieren
    db2 = Path(tempfile.gettempdir()) / "test_import.sqlite3"
    if db2.exists():
        db2.unlink()
    
    store2 = AddressCorrectionStore(db2)
    count = store2.import_csv(csv_path)
    
    assert count == 1
    c2 = store2.get(c1.key)
    assert c2 is not None
    assert c2.lat == c1.lat
    assert c2.lon == c1.lon


if __name__ == "__main__":
    print("Running address corrections flow tests...\n")
    test_flow_persists_fix()
    print("\n")
    test_parse_address_components()
    print("✓ parse_address_components test passed\n")
    test_csv_export_import()
    print("✓ CSV export/import test passed\n")
    print("\n=== Alle Tests erfolgreich! ===")

