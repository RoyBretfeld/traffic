# tests/test_geocoder_correction_aware_unit.py
"""
Unit-Tests für CorrectionAwareGeocoder
Testet Geocoder-Adapter isoliert.
"""
from __future__ import annotations
import tempfile
import pytest
from pathlib import Path
from backend.services.geocoder_correction_aware import (
    CorrectionAwareGeocoder,
    BaseGeocoder,
    parse_address_components,
    make_geocoder
)
from backend.services.address_corrections import AddressCorrectionStore, Correction, make_key


class MockGeocoder(BaseGeocoder):
    """Mock-Geocoder für Tests."""
    
    def __init__(self, results: dict = None):
        self.results = results or {}
        self.calls = []
    
    def geocode(self, street: str, postal_code: str, city: str, country: str = "DE"):
        self.calls.append((street, postal_code, city, country))
        key = f"{street}|{postal_code}|{city}|{country}"
        return self.results.get(key, (None, None, "not_found"))


@pytest.fixture
def temp_store():
    """Erstellt temporären AddressCorrectionStore."""
    db_path = Path(tempfile.gettempdir()) / f"test_geocoder_{id(pytest)}.sqlite3"
    if db_path.exists():
        db_path.unlink()
    store = AddressCorrectionStore(db_path)
    yield store
    if db_path.exists():
        db_path.unlink()


class TestParseAddressComponents:
    """Tests für parse_address_components Funktion."""
    
    def test_parses_full_address(self):
        street, pc, city = parse_address_components("Hauptstraße 1, 01067 Dresden")
        assert street == "Hauptstraße 1"
        assert pc == "01067"
        assert city == "Dresden"
    
    def test_handles_without_comma(self):
        street, pc, city = parse_address_components("Hauptstraße 1 01067 Dresden")
        assert street == "Hauptstraße 1"
        assert pc == "01067"
        assert city == "Dresden"
    
    def test_handles_empty(self):
        street, pc, city = parse_address_components("")
        assert street == ""
        assert pc == ""
        assert city == ""
    
    def test_handles_no_plz(self):
        street, pc, city = parse_address_components("Hauptstraße 1, Dresden")
        assert street == "Hauptstraße 1"
        assert pc == ""
        assert city == "Dresden"
    
    @pytest.mark.parametrize("address,expected", [
        ("Hauptstraße 1, 01067 Dresden", ("Hauptstraße 1", "01067", "Dresden")),
        ("Mügelnitzer Str. 10, 01814 Bad Schandau", ("Mügelnitzer Str. 10", "01814", "Bad Schandau")),
        ("Straße 42, 01234 Stadt", ("Straße 42", "01234", "Stadt")),
    ])
    def test_parse_various_formats(self, address, expected):
        result = parse_address_components(address)
        assert result == expected


class TestCorrectionAwareGeocoder:
    """Tests für CorrectionAwareGeocoder Klasse."""
    
    def test_checks_correction_table_first(self, temp_store):
        """Test: Korrekturtabelle wird vor Geocoder geprüft."""
        # Korrektur hinzufügen
        key = make_key("Teststraße", "01067", "Dresden")
        c = Correction(
            key=key,
            street_canonical="Teststraße",
            postal_code="01067",
            city="Dresden",
            lat=51.05,
            lon=13.74
        )
        temp_store.upsert(c)
        
        # Geocoder sollte nicht aufgerufen werden
        mock_geo = MockGeocoder()
        corr_geo = CorrectionAwareGeocoder(temp_store, delegate=mock_geo)
        
        lat, lon, msg = corr_geo.geocode("Teststraße", "01067", "Dresden")
        
        assert lat == 51.05
        assert lon == 13.74
        assert msg is None
        assert len(mock_geo.calls) == 0  # Sollte nicht aufgerufen werden
    
    def test_fallback_to_geocoder(self, temp_store):
        """Test: Bei Misserfolg wird Geocoder verwendet."""
        mock_geo = MockGeocoder({
            "Teststraße|01067|Dresden|DE": (51.1, 13.8, None)
        })
        corr_geo = CorrectionAwareGeocoder(temp_store, delegate=mock_geo)
        
        lat, lon, msg = corr_geo.geocode("Teststraße", "01067", "Dresden")
        
        assert lat == 51.1
        assert lon == 13.8
        assert len(mock_geo.calls) == 1
    
    def test_enqueues_on_failure(self, temp_store):
        """Test: Bei Misserfolg wird Eintrag in Queue geschrieben."""
        mock_geo = MockGeocoder()  # Gibt immer None zurück
        corr_geo = CorrectionAwareGeocoder(temp_store, delegate=mock_geo)
        
        lat, lon, msg = corr_geo.geocode("Teststraße", "01067", "Dresden")
        
        assert lat is None
        assert lon is None
        assert msg == "not_found"
        
        # Sollte in Queue sein
        pending = temp_store.list_pending()
        assert len(pending) == 1
        assert pending[0]['street'] == "Teststraße"
    
    def test_parses_full_address_string(self, temp_store):
        """Test: Vollständiger Adress-String wird geparst."""
        key = make_key("Teststraße", "01067", "Dresden")
        c = Correction(
            key=key,
            street_canonical="Teststraße",
            postal_code="01067",
            city="Dresden",
            lat=51.05,
            lon=13.74
        )
        temp_store.upsert(c)
        
        corr_geo = CorrectionAwareGeocoder(temp_store)
        
        # Als vollständiger String
        lat, lon, msg = corr_geo.geocode("Teststraße, 01067 Dresden")
        assert lat == 51.05
        assert lon == 13.74
    
    def test_saves_successful_geocode(self, temp_store):
        """Test: Erfolgreiche Geocodierungen werden in Korrekturtabelle gespeichert."""
        mock_geo = MockGeocoder({
            "Teststraße|01067|Dresden|DE": (51.1, 13.8, None)
        })
        corr_geo = CorrectionAwareGeocoder(temp_store, delegate=mock_geo)
        
        corr_geo.geocode("Teststraße", "01067", "Dresden")
        
        # Sollte in Korrekturtabelle sein
        key = make_key("Teststraße", "01067", "Dresden")
        correction = temp_store.get(key)
        assert correction is not None
        assert correction.lat == 51.1
        assert correction.source == "geocode"
    
    def test_geocode_from_full_address(self, temp_store):
        """Test: Convenience-Methode geocode_from_full_address."""
        key = make_key("Teststraße", "01067", "Dresden")
        c = Correction(
            key=key,
            street_canonical="Teststraße",
            postal_code="01067",
            city="Dresden",
            lat=51.05,
            lon=13.74
        )
        temp_store.upsert(c)
        
        corr_geo = CorrectionAwareGeocoder(temp_store)
        lat, lon, msg = corr_geo.geocode_from_full_address("Teststraße, 01067 Dresden")
        
        assert lat == 51.05
        assert lon == 13.74


class TestMakeGeocoder:
    """Tests für make_geocoder Factory-Funktion."""
    
    def test_creates_geocoder(self):
        """Test: make_geocoder erstellt CorrectionAwareGeocoder."""
        db_path = Path(tempfile.gettempdir()) / f"test_factory_{id(pytest)}.sqlite3"
        if db_path.exists():
            db_path.unlink()
        
        try:
            geo = make_geocoder(db_path)
            assert isinstance(geo, CorrectionAwareGeocoder)
            assert geo.store.db_path == db_path
        finally:
            if db_path.exists():
                db_path.unlink()

