# -*- coding: utf-8 -*-
"""
Smoke Tests für die FAMO TrafficApp Datenpipeline
Testet die grundlegende Funktionalität der CSV→Parser→Bulk→Match Pipeline
"""

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "tests" / "data"
CSV = DATA / "sample_tours.csv"
RUNNER = ROOT / "tests" / "debug_pipeline_runner.py"

@pytest.fixture(scope="session", autouse=True)
def _write_sample_csv():
    """Erstellt die Sample-CSV-Datei für Tests"""
    DATA.mkdir(parents=True, exist_ok=True)
    content = os.environ.get("SAMPLE_TOURS_CSV")
    if content:
        CSV.write_text(content, encoding="utf-8")
    else:
        # Fallback: wenn Canvas nicht injiziert ist, minimaler Inhalt
        CSV.write_text(
            "tour_id;order_id;customer;street;postal_code;city;lat;lon\n"
            "A;1001;A;A-Straße 1;01067;Dresden;51.05;13.74\n",
            encoding="utf-8",
        )

@pytest.mark.integration
def test_debug_runner_smoke(tmp_path):
    """Testet den Debug Runner mit Sample-Daten"""
    assert RUNNER.exists(), "tests/debug_pipeline_runner.py fehlt"
    out_json = tmp_path / "debug_report.json"
    
    cmd = [
        sys.executable, 
        str(RUNNER), 
        str(CSV), 
        "--encoding", "utf-8", 
        "--delimiter", ";", 
        "--json-out", str(out_json)
    ]
    
    res = subprocess.run(cmd, capture_output=True, text=True)
    print("STDOUT:\n", res.stdout)
    print("STDERR:\n", res.stderr)
    
    # Runner sollte nicht mit kritischem Fehler abbrechen
    assert res.returncode in (0, 1), "Runner meldet kritischen Fehler (Exit!=0/1)"
    assert out_json.exists(), "debug_report.json wurde nicht erzeugt"
    
    # Report validieren
    report = json.loads(out_json.read_text(encoding="utf-8"))
    
    # Grundsatzprüfungen
    assert "steps" in report and isinstance(report["steps"], list)
    assert any(s["name"].startswith("csv_reader") for s in report["steps"]), "CSV-Reader Schritt fehlt"
    assert any(s["name"].startswith("tour_plan_parser") for s in report["steps"]), "Parser Schritt fehlt"
    
    # Pipeline-Summary prüfen
    assert "pipeline_summary" in report
    summary = report["pipeline_summary"]
    assert "total_steps" in summary
    assert "successful_steps" in summary
    assert "success_rate" in summary
    assert "overall_status" in summary

@pytest.mark.integration
def test_csv_reader_step():
    """Testet den CSV-Reader Schritt isoliert"""
    assert CSV.exists(), "Sample CSV fehlt"
    
    # CSV-Inhalt prüfen
    content = CSV.read_text(encoding="utf-8")
    lines = content.strip().split('\n')
    
    assert len(lines) >= 2, "CSV sollte mindestens Header + 1 Datenzeile haben"
    
    # Header prüfen
    header = lines[0].split(';')
    expected_columns = ['tour_id', 'order_id', 'customer', 'street', 'postal_code', 'city', 'lat', 'lon']
    
    for col in expected_columns:
        assert col in header, f"Spalte '{col}' fehlt im Header"

@pytest.mark.integration 
def test_pipeline_with_real_csv():
    """Testet die Pipeline mit einer echten CSV-Datei aus dem Projekt"""
    # Suche nach vorhandenen CSV-Dateien
    csv_files = list(ROOT.glob("tourplaene/*.csv"))
    if not csv_files:
        pytest.skip("Keine CSV-Dateien in tourplaene/ gefunden")
    
    # Verwende die erste gefundene CSV-Datei
    real_csv = csv_files[0]
    print(f"Teste mit echter CSV: {real_csv}")
    
    # Runner mit echter CSV ausführen
    cmd = [
        sys.executable, 
        str(RUNNER), 
        str(real_csv), 
        "--encoding", "utf-8", 
        "--delimiter", ";"
    ]
    
    res = subprocess.run(cmd, capture_output=True, text=True)
    
    # Auch bei Encoding-Problemen sollte der Runner nicht crashen
    assert res.returncode in (0, 1), f"Runner crashed mit echter CSV: {res.stderr}"
    
    # Prüfe, ob mindestens ein Schritt erfolgreich war
    if res.returncode == 0:
        print("✅ Pipeline mit echter CSV erfolgreich")
    else:
        print("⚠️ Pipeline hatte Probleme, aber crashed nicht")

def test_sample_csv_format():
    """Testet das Format der Sample-CSV"""
    assert CSV.exists(), "Sample CSV fehlt"
    
    content = CSV.read_text(encoding="utf-8")
    lines = content.strip().split('\n')
    
    # Mindestens Header + 1 Datenzeile
    assert len(lines) >= 2, "Sample CSV zu kurz"
    
    # Alle Zeilen sollten die gleiche Anzahl Spalten haben
    header_cols = len(lines[0].split(';'))
    for i, line in enumerate(lines[1:], 1):
        if line.strip():  # Leere Zeilen ignorieren
            cols = len(line.split(';'))
            assert cols == header_cols, f"Zeile {i} hat {cols} Spalten, erwartet {header_cols}"

@pytest.mark.integration
def test_pipeline_error_handling():
    """Testet die Fehlerbehandlung der Pipeline"""
    # Test mit nicht-existierender Datei
    fake_csv = DATA / "nonexistent.csv"
    
    cmd = [
        sys.executable, 
        str(RUNNER), 
        str(fake_csv), 
        "--encoding", "utf-8"
    ]
    
    res = subprocess.run(cmd, capture_output=True, text=True)
    
    # Sollte mit Fehler-Code abbrechen
    assert res.returncode != 0, "Runner sollte bei nicht-existierender Datei fehlschlagen"
    # Prüfe ob Fehlermeldung in stdout oder stderr steht
    error_msg = res.stdout + res.stderr
    assert "existiert nicht" in error_msg or "not found" in error_msg.lower(), f"Fehlermeldung unklar: {error_msg}"
