# tests/test_address_corrections_unit.py
"""
Unit-Tests für AddressCorrectionStore Service
Testet alle Methoden isoliert mit temporären Datenbanken.
"""
from __future__ import annotations
import tempfile
import pytest
from pathlib import Path
from backend.services.address_corrections import (
    AddressCorrectionStore,
    Correction,
    make_key,
    normalize_street
)


@pytest.fixture
def temp_db():
    """Erstellt eine temporäre Datenbank für Tests."""
    db_path = Path(tempfile.gettempdir()) / f"test_corrections_{id(pytest)}.sqlite3"
    if db_path.exists():
        db_path.unlink()
    store = AddressCorrectionStore(db_path)
    yield store
    if db_path.exists():
        db_path.unlink()


class TestNormalizeStreet:
    """Tests für normalize_street Funktion."""
    
    def test_normalizes_strasse(self):
        assert normalize_street("Hauptstr.") == "Hauptstraße"
        assert normalize_street("Test Str") == "Test Straße"
        assert normalize_street("Hauptstrasse") == "Hauptstraße"
    
    def test_preserves_already_normalized(self):
        assert normalize_street("Hauptstraße") == "Hauptstraße"
        assert normalize_street("Test Straße") == "Test Straße"
    
    def test_handles_empty(self):
        assert normalize_street("") == ""
        assert normalize_street(None) == ""
    
    def test_normalizes_whitespace(self):
        assert normalize_street("  Hauptstr.  ") == "Hauptstraße"
        assert normalize_street("Hauptstr.\n\t") == "Hauptstraße"


class TestMakeKey:
    """Tests für make_key Funktion."""
    
    def test_creates_consistent_key(self):
        key1 = make_key("Hauptstr.", "01067", "Dresden")
        key2 = make_key("Hauptstraße", "01067", "Dresden")
        assert key1 == key2  # Sollte gleich sein durch Normalisierung
    
    def test_case_insensitive(self):
        key1 = make_key("Hauptstr.", "01067", "DRESDEN")
        key2 = make_key("Hauptstr.", "01067", "dresden")
        assert key1 == key2
    
    def test_includes_country(self):
        key_de = make_key("Hauptstr.", "01067", "Dresden", "DE")
        key_at = make_key("Hauptstr.", "01067", "Dresden", "AT")
        assert key_de != key_at
    
    def test_key_format(self):
        key = make_key("Hauptstr.", "01067", "Dresden")
        parts = key.split("|")
        assert len(parts) == 4
        assert parts[1] == "01067"
        assert parts[2] == "dresden"  # lowercase
        assert parts[3] == "DE"  # uppercase


class TestAddressCorrectionStore:
    """Tests für AddressCorrectionStore Klasse."""
    
    def test_init_creates_db(self, temp_db):
        """Test: Datenbank wird bei Initialisierung erstellt."""
        assert temp_db.db_path.exists()
    
    def test_get_nonexistent(self, temp_db):
        """Test: get() gibt None zurück für nicht existierende Korrekturen."""
        result = temp_db.get("nonexistent|key|test|DE")
        assert result is None
    
    def test_upsert_and_get(self, temp_db):
        """Test: upsert() speichert und get() ruft korrekt ab."""
        c = Correction(
            key=make_key("Teststraße", "01067", "Dresden"),
            street_canonical="Teststraße",
            postal_code="01067",
            city="Dresden",
            lat=51.05,
            lon=13.74
        )
        temp_db.upsert(c)
        
        retrieved = temp_db.get(c.key)
        assert retrieved is not None
        assert retrieved.key == c.key
        assert retrieved.lat == c.lat
        assert retrieved.lon == c.lon
        assert retrieved.street_canonical == c.street_canonical
    
    def test_upsert_updates_existing(self, temp_db):
        """Test: upsert() aktualisiert existierende Einträge."""
        key = make_key("Teststraße", "01067", "Dresden")
        c1 = Correction(
            key=key,
            street_canonical="Teststraße",
            postal_code="01067",
            city="Dresden",
            lat=51.05,
            lon=13.74
        )
        temp_db.upsert(c1)
        
        c2 = Correction(
            key=key,
            street_canonical="Teststraße",
            postal_code="01067",
            city="Dresden",
            lat=52.0,  # Geändert
            lon=14.0,  # Geändert
            source="updated"
        )
        temp_db.upsert(c2)
        
        retrieved = temp_db.get(key)
        assert retrieved.lat == 52.0
        assert retrieved.lon == 14.0
    
    def test_enqueue_unresolved(self, temp_db):
        """Test: enqueue_unresolved() fügt Adresse zur Queue hinzu."""
        key = temp_db.enqueue_unresolved("Teststraße", "01067", "Dresden", note="test")
        assert key == make_key("Teststraße", "01067", "Dresden")
        
        pending = temp_db.list_pending()
        assert len(pending) == 1
        assert pending[0]['key'] == key
        assert pending[0]['times_seen'] == 1
    
    def test_enqueue_increments_counter(self, temp_db):
        """Test: Mehrfaches Eintragen erhöht times_seen."""
        key = temp_db.enqueue_unresolved("Teststraße", "01067", "Dresden")
        temp_db.enqueue_unresolved("Teststraße", "01067", "Dresden")
        temp_db.enqueue_unresolved("Teststraße", "01067", "Dresden")
        
        pending = temp_db.list_pending()
        assert len(pending) == 1
        assert pending[0]['times_seen'] == 3
    
    def test_list_pending(self, temp_db):
        """Test: list_pending() listet nur pending Einträge."""
        temp_db.enqueue_unresolved("Straße 1", "01067", "Dresden")
        temp_db.enqueue_unresolved("Straße 2", "01068", "Dresden")
        
        pending = temp_db.list_pending()
        assert len(pending) == 2
        
        # Mit Limit
        pending_limited = temp_db.list_pending(limit=1)
        assert len(pending_limited) == 1
    
    def test_resolve_moves_to_corrections(self, temp_db):
        """Test: resolve() verschiebt Eintrag von Queue zu Corrections."""
        key = temp_db.enqueue_unresolved("Teststraße", "01067", "Dresden")
        temp_db.resolve(key, 51.05, 13.74)
        
        # Sollte in Corrections sein
        correction = temp_db.get(key)
        assert correction is not None
        assert correction.lat == 51.05
        
        # Sollte nicht mehr in pending sein
        pending = temp_db.list_pending()
        pending_keys = [p['key'] for p in pending]
        assert key not in pending_keys
    
    def test_resolve_nonexistent_key(self, temp_db):
        """Test: resolve() wirft KeyError für nicht existierende Keys."""
        with pytest.raises(KeyError):
            temp_db.resolve("nonexistent|key|test|DE", 51.05, 13.74)
    
    def test_export_csv(self, temp_db, tmp_path):
        """Test: export_csv() erstellt CSV-Datei."""
        c = Correction(
            key=make_key("Teststraße", "01067", "Dresden"),
            street_canonical="Teststraße",
            postal_code="01067",
            city="Dresden",
            lat=51.05,
            lon=13.74
        )
        temp_db.upsert(c)
        
        csv_path = tmp_path / "export.csv"
        temp_db.export_csv(csv_path)
        
        assert csv_path.exists()
        content = csv_path.read_text(encoding="utf-8")
        assert "Teststraße" in content
        assert "01067" in content
    
    def test_import_csv(self, temp_db, tmp_path):
        """Test: import_csv() importiert CSV korrekt."""
        # Export erstellen
        c = Correction(
            key=make_key("Teststraße", "01067", "Dresden"),
            street_canonical="Teststraße",
            postal_code="01067",
            city="Dresden",
            lat=51.05,
            lon=13.74
        )
        temp_db.upsert(c)
        
        csv_path = tmp_path / "export.csv"
        temp_db.export_csv(csv_path)
        
        # Neue DB und importieren
        db2_path = tmp_path / "test_import.sqlite3"
        store2 = AddressCorrectionStore(db2_path)
        count = store2.import_csv(csv_path)
        
        assert count == 1
        retrieved = store2.get(c.key)
        assert retrieved is not None
        assert retrieved.lat == c.lat


@pytest.mark.parametrize("street,expected", [
    ("Hauptstr.", "Hauptstraße"),
    ("Test Str", "Test Straße"),
    ("Hauptstraße", "Hauptstraße"),
    ("", ""),
])
def test_normalize_street_parametrized(street, expected):
    """Parametrisierter Test für normalize_street."""
    assert normalize_street(street) == expected

