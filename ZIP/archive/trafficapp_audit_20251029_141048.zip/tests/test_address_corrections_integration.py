# tests/test_address_corrections_integration.py
"""
Integration-Tests für Adress-Korrektur-System
Testet vollständigen Workflow mit mehreren Komponenten.
"""
from __future__ import annotations
import tempfile
import pytest
from pathlib import Path
from backend.services.address_corrections import AddressCorrectionStore, make_key
from backend.services.geocoder_correction_aware import CorrectionAwareGeocoder, BaseGeocoder
from backend.services.geocode_fill import _get_correction_geocoder


class TestFullWorkflow:
    """Test: Vollständiger Workflow von fehlgeschlagener Geocodierung bis automatischer Erkennung."""
    
    def test_end_to_end_workflow(self):
        """Test: Kompletter Flow mit allen Komponenten."""
        db_path = Path(tempfile.gettempdir()) / f"test_e2e_{id(pytest)}.sqlite3"
        if db_path.exists():
            db_path.unlink()
        
        try:
            store = AddressCorrectionStore(db_path)
            
            # Schritt 1: Fehlgeschlagene Geocodierung
            mock_geo = BaseGeocoder()  # Gibt immer None zurück
            corr_geo = CorrectionAwareGeocoder(store, delegate=mock_geo)
            
            lat, lon, msg = corr_geo.geocode("Problemstraße", "01067", "Dresden")
            assert lat is None
            assert lon is None
            
            # Schritt 2: Prüfe Queue
            pending = store.list_pending()
            assert len(pending) == 1
            assert pending[0]['street'] == "Problemstraße"
            
            # Schritt 3: Manuelle Korrektur
            key = make_key("Problemstraße", "01067", "Dresden")
            store.resolve(key, 51.05, 13.74)
            
            # Schritt 4: Korrektur wird automatisch erkannt
            lat, lon, msg = corr_geo.geocode("Problemstraße", "01067", "Dresden")
            assert lat == 51.05
            assert lon == 13.74
            
            # Schritt 5: Queue sollte leer sein
            pending_after = store.list_pending()
            assert len(pending_after) == 0
        finally:
            if db_path.exists():
                db_path.unlink()


class TestGeocodeFillIntegration:
    """Test: Integration mit geocode_fill.py."""
    
    @pytest.mark.asyncio
    async def test_correction_table_checked_in_geocode_fill(self, monkeypatch):
        """Test: Korrekturtabelle wird in geocode_fill.py geprüft."""
        import os
        import tempfile
        from pathlib import Path
        
        # Temporäre DB für Test
        db_path = Path(tempfile.gettempdir()) / f"test_geocode_fill_{id(pytest)}.sqlite3"
        if db_path.exists():
            db_path.unlink()
        
        try:
            # Setze Umgebungsvariable
            monkeypatch.setenv("ADDRESS_CORRECTIONS_DB", str(db_path))
            
            # Erstelle Korrektur
            from backend.services.address_corrections import AddressCorrectionStore, Correction, make_key
            store = AddressCorrectionStore(db_path)
            key = make_key("Teststraße", "01067", "Dresden")
            c = Correction(
                key=key,
                street_canonical="Teststraße",
                postal_code="01067",
                city="Dresden",
                lat=51.05,
                lon=13.74
            )
            store.upsert(c)
            
            # Prüfe dass _geocode_one die Korrektur findet
            from services.geocode_fill import _geocode_one
            import httpx
            
            async with httpx.AsyncClient() as client:
                result = await _geocode_one("Teststraße, 01067 Dresden", client)
                
                assert result is not None
                assert result.get("lat") == 51.05
                assert result.get("lon") == 13.74
                assert result.get("_note") == "correction"
        finally:
            if db_path.exists():
                db_path.unlink()


class TestCLIIntegration:
    """Test: CLI-Tool Integration."""
    
    def test_cli_list_works(self, tmp_path):
        """Test: CLI list Command funktioniert."""
        import subprocess
        import sys
        
        db_path = tmp_path / "test_cli.db"
        
        # Erstelle Store und füge Eintrag hinzu
        store = AddressCorrectionStore(db_path)
        store.enqueue_unresolved("Teststraße", "01067", "Dresden")
        
        # Rufe CLI auf
        result = subprocess.run(
            [sys.executable, "tools/corrections_cli.py", str(db_path), "list"],
            capture_output=True,
            text=True,
            cwd=Path(__file__).parents[1]
        )
        
        assert result.returncode == 0
        assert "Teststraße" in result.stdout
    
    def test_cli_resolve_works(self, tmp_path):
        """Test: CLI resolve Command funktioniert."""
        import subprocess
        import sys
        
        db_path = tmp_path / "test_cli.db"
        
        # Erstelle Store und füge Eintrag hinzu
        store = AddressCorrectionStore(db_path)
        key = store.enqueue_unresolved("Teststraße", "01067", "Dresden")
        
        # Rufe CLI auf
        result = subprocess.run(
            [sys.executable, "tools/corrections_cli.py", str(db_path), "resolve", key, "51.05", "13.74"],
            capture_output=True,
            text=True,
            cwd=Path(__file__).parents[1]
        )
        
        assert result.returncode == 0
        
        # Prüfe dass Korrektur gespeichert wurde
        correction = store.get(key)
        assert correction is not None
        assert correction.lat == 51.05

