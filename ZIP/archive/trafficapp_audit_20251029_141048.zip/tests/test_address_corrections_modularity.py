# tests/test_address_corrections_modularity.py
"""
Modularitäts-Tests für Adress-Korrektur-System
Prüft dass Komponenten sauber getrennt und austauschbar sind.
"""
from __future__ import annotations
import pytest
from backend.services.address_corrections import AddressCorrectionStore
from backend.services.geocoder_correction_aware import CorrectionAwareGeocoder, BaseGeocoder


class TestModularity:
    """Tests für Modularität der Komponenten."""
    
    def test_address_corrections_no_external_dependencies(self):
        """Test: address_corrections.py hat keine internen Dependencies."""
        import inspect
        import backend.services.address_corrections as module
        
        # Prüfe alle Imports
        source = inspect.getsource(module)
        
        # Sollte keine Imports von anderen backend-Modulen haben (außer Standard-Library)
        lines = source.split('\n')
        import_lines = [l for l in lines if l.strip().startswith(('import ', 'from '))]
        
        # Erlaubt sind nur Standard-Library und externe Pakete
        for line in import_lines:
            if 'from backend' in line or 'import backend' in line:
                pytest.fail(f"address_corrections.py sollte keine internen Dependencies haben: {line}")
    
    def test_geocoder_aware_minimal_dependency(self):
        """Test: geocoder_correction_aware.py hat nur eine lokale Dependency."""
        import inspect
        import backend.services.geocoder_correction_aware as module
        
        source = inspect.getsource(module)
        lines = source.split('\n')
        import_lines = [l for l in lines if l.strip().startswith(('import ', 'from '))]
        
        # Sollte nur address_corrections importieren (lokale Dependency)
        backend_imports = [l for l in import_lines if 'backend' in l]
        assert len(backend_imports) <= 1  # Nur address_corrections
        assert any('address_corrections' in l for l in backend_imports)
    
    def test_store_standalone(self):
        """Test: AddressCorrectionStore kann standalone verwendet werden."""
        import tempfile
        from pathlib import Path
        from backend.services.address_corrections import AddressCorrectionStore, Correction, make_key
        
        db_path = Path(tempfile.gettempdir()) / f"test_standalone_{id(pytest)}.sqlite3"
        if db_path.exists():
            db_path.unlink()
        
        try:
            store = AddressCorrectionStore(db_path)
            
            # Kann unabhängig verwendet werden
            c = Correction(
                key=make_key("Test", "01067", "Dresden"),
                street_canonical="Test",
                postal_code="01067",
                city="Dresden",
                lat=51.05,
                lon=13.74
            )
            store.upsert(c)
            
            retrieved = store.get(c.key)
            assert retrieved is not None
        finally:
            if db_path.exists():
                db_path.unlink()
    
    def test_geocoder_delegate_pattern(self):
        """Test: CorrectionAwareGeocoder nutzt Delegate-Pattern korrekt."""
        import tempfile
        from pathlib import Path
        from backend.services.address_corrections import AddressCorrectionStore
        
        db_path = Path(tempfile.gettempdir()) / f"test_delegate_{id(pytest)}.sqlite3"
        if db_path.exists():
            db_path.unlink()
        
        try:
            store = AddressCorrectionStore(db_path)
            
            # Custom Delegate
            class CustomGeocoder(BaseGeocoder):
                def geocode(self, street, postal_code, city, country="DE"):
                    return 99.0, 88.0, None
            
            geo = CorrectionAwareGeocoder(store, delegate=CustomGeocoder())
            
            # Delegate sollte verwendet werden
            lat, lon, msg = geo.geocode("Test", "01067", "Dresden")
            assert lat == 99.0
            assert lon == 88.0
        finally:
            if db_path.exists():
                db_path.unlink()
    
    def test_factory_function(self):
        """Test: make_geocoder Factory-Funktion erstellt vollständiges System."""
        import tempfile
        from pathlib import Path
        from backend.services.geocoder_correction_aware import make_geocoder
        
        db_path = Path(tempfile.gettempdir()) / f"test_factory_{id(pytest)}.sqlite3"
        if db_path.exists():
            db_path.unlink()
        
        try:
            geo = make_geocoder(db_path)
            
            # Sollte vollständiges System sein
            assert isinstance(geo, CorrectionAwareGeocoder)
            assert geo.store is not None
            assert geo.delegate is not None
        finally:
            if db_path.exists():
                db_path.unlink()

