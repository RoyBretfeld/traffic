# backend/services/address_corrections.py
# Zweck: Persistente Speicherung manueller Korrekturen + Queue für „rote" Adressen
from __future__ import annotations
import csv
import os
import re
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, List, Tuple, Dict

_SPACE = re.compile(r"\s+")
_SUFFIX = {"strasse": "straße", "str": "straße"}


def normalize_street(s: str) -> str:
    """Normalisiert Straßennamen für konsistente Keys."""
    s = (s or "").strip()
    s = _SPACE.sub(" ", s)
    low = s.lower()
    for k, v in _SUFFIX.items():
        if low.endswith(k):
            s = s[: -len(k)] + v
            break
    return s


def make_key(street: str, postal_code: str, city: str, country: str = "DE") -> str:
    """Erstellt einen eindeutigen Key für eine Adresse."""
    return f"{normalize_street(street).lower()}|{(postal_code or '').strip()}|{(city or '').strip().lower()}|{(country or 'DE').strip().upper()}"


@dataclass
class Correction:
    key: str
    street_canonical: str
    postal_code: str
    city: str
    country: str = "DE"
    lat: Optional[float] = None
    lon: Optional[float] = None
    source: str = "manual"
    confidence: float = 1.0


class AddressCorrectionStore:
    """Speichert Korrekturen in SQLite; CSV-Export/Import optional."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _conn(self):
        return sqlite3.connect(self.db_path)

    def _init_db(self):
        """Initialisiert die Datenbank mit dem Schema aus der Migration."""
        migration_path = Path(__file__).parents[2] / "db" / "migrations" / "020_address_corrections.sql"
        if migration_path.exists():
            with self._conn() as con:
                con.executescript(migration_path.read_text(encoding="utf-8"))
        else:
            # Fallback: Direktes Schema (falls Migration nicht gefunden)
            with self._conn() as con:
                con.executescript("""
                    PRAGMA foreign_keys = ON;
                    CREATE TABLE IF NOT EXISTS address_corrections (
                      key TEXT PRIMARY KEY,
                      street_canonical TEXT NOT NULL,
                      postal_code TEXT NOT NULL,
                      city TEXT NOT NULL,
                      country TEXT NOT NULL DEFAULT 'DE',
                      lat REAL,
                      lon REAL,
                      source TEXT NOT NULL DEFAULT 'manual',
                      confidence REAL NOT NULL DEFAULT 1.0,
                      created_at TEXT NOT NULL DEFAULT (datetime('now')),
                      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
                    );
                    CREATE TABLE IF NOT EXISTS address_exception_queue (
                      key TEXT PRIMARY KEY,
                      street TEXT NOT NULL,
                      postal_code TEXT NOT NULL,
                      city TEXT NOT NULL,
                      country TEXT NOT NULL DEFAULT 'DE',
                      last_seen TEXT NOT NULL DEFAULT (datetime('now')),
                      times_seen INTEGER NOT NULL DEFAULT 1,
                      note TEXT,
                      status TEXT NOT NULL DEFAULT 'pending',
                      created_at TEXT NOT NULL DEFAULT (datetime('now')),
                      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
                    );
                    CREATE TRIGGER IF NOT EXISTS trg_address_corrections_updated
                    AFTER UPDATE ON address_corrections
                    FOR EACH ROW BEGIN
                      UPDATE address_corrections SET updated_at = datetime('now') WHERE key = OLD.key;
                    END;
                    CREATE TRIGGER IF NOT EXISTS trg_address_exception_queue_updated
                    AFTER UPDATE ON address_exception_queue
                    FOR EACH ROW BEGIN
                      UPDATE address_exception_queue SET updated_at = datetime('now') WHERE key = OLD.key;
                    END;
                """)

    # --- Corrections ---
    def get(self, key: str) -> Optional[Correction]:
        """Ruft eine Korrektur ab, falls vorhanden."""
        with self._conn() as con:
            cur = con.execute(
                "SELECT key, street_canonical, postal_code, city, country, lat, lon, source, confidence FROM address_corrections WHERE key=?",
                (key,)
            )
            row = cur.fetchone()
            if not row:
                return None
            return Correction(*row)

    def upsert(self, c: Correction) -> None:
        """Speichert oder aktualisiert eine Korrektur."""
        with self._conn() as con:
            con.execute(
                """
                INSERT INTO address_corrections (key, street_canonical, postal_code, city, country, lat, lon, source, confidence)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET
                  street_canonical=excluded.street_canonical,
                  postal_code=excluded.postal_code,
                  city=excluded.city,
                  country=excluded.country,
                  lat=excluded.lat,
                  lon=excluded.lon,
                  source=excluded.source,
                  confidence=excluded.confidence
                """,
                (c.key, c.street_canonical, c.postal_code, c.city, c.country, c.lat, c.lon, c.source, c.confidence),
            )

    def export_csv(self, path: Path) -> None:
        """Exportiert alle Korrekturen als CSV."""
        with self._conn() as con, open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f, delimiter=';')
            w.writerow(["key", "street_canonical", "postal_code", "city", "country", "lat", "lon", "source", "confidence"])
            for row in con.execute(
                "SELECT key, street_canonical, postal_code, city, country, lat, lon, source, confidence FROM address_corrections"
            ):
                w.writerow(row)

    def import_csv(self, path: Path) -> int:
        """Importiert Korrekturen aus CSV."""
        count = 0

        def _to_float(x) -> Optional[float]:
            if x is None or x == "":
                return None
            try:
                return float(str(x).replace(",", "."))
            except ValueError:
                return None

        with self._conn() as con, open(path, newline="", encoding="utf-8") as f:
            r = csv.DictReader(f, delimiter=';')
            for row in r:
                c = Correction(
                    key=row["key"],
                    street_canonical=row["street_canonical"],
                    postal_code=row["postal_code"],
                    city=row["city"],
                    country=row.get("country", "DE"),
                    lat=_to_float(row.get("lat")),
                    lon=_to_float(row.get("lon")),
                    source=row.get("source", "manual"),
                    confidence=float(row.get("confidence", 1.0)),
                )
                self.upsert(c)
                count += 1
        return count

    # --- Queue ---
    def enqueue_unresolved(self, street: str, postal_code: str, city: str, country: str = "DE", note: str = None) -> str:
        """Fügt eine fehlgeschlagene Adresse zur Warteschlange hinzu."""
        key = make_key(street, postal_code, city, country)
        with self._conn() as con:
            cur = con.execute("SELECT times_seen FROM address_exception_queue WHERE key=?", (key,))
            row = cur.fetchone()
            if row:
                con.execute(
                    "UPDATE address_exception_queue SET times_seen=times_seen+1, last_seen=datetime('now'), note=COALESCE(?, note) WHERE key=?",
                    (note, key)
                )
            else:
                con.execute(
                    "INSERT INTO address_exception_queue (key, street, postal_code, city, country, note) VALUES (?,?,?,?,?,?)",
                    (key, normalize_street(street), postal_code, city, country, note),
                )
        return key

    def list_pending(self, limit: int = 100) -> List[Dict[str, str]]:
        """Listet ausstehende Korrekturen (pending Status)."""
        with self._conn() as con:
            cur = con.execute(
                "SELECT key, street, postal_code, city, country, times_seen, last_seen FROM address_exception_queue WHERE status='pending' ORDER BY times_seen DESC, last_seen DESC LIMIT ?",
                (limit,)
            )
            cols = [c[0] for c in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]

    def resolve(self, key: str, lat: float, lon: float, street_canonical: Optional[str] = None, source: str = "manual", confidence: float = 1.0) -> None:
        """Löst einen Queue-Eintrag auf und speichert die Korrektur."""
        # Validierung: lat/lon Bereichsgrenzen
        if lat < -90 or lat > 90:
            raise ValueError(f"Latitude muss zwischen -90 und 90 liegen (aktuell: {lat})")
        if lon < -180 or lon > 180:
            raise ValueError(f"Longitude muss zwischen -180 und 180 liegen (aktuell: {lon})")
        with self._conn() as con:
            row = con.execute(
                "SELECT street, postal_code, city, country FROM address_exception_queue WHERE key=?",
                (key,)
            ).fetchone()
            if not row:
                raise KeyError(f"Key {key} nicht in Queue")
            street, postal_code, city, country = row
            c = Correction(
                key=key,
                street_canonical=street_canonical or street,
                postal_code=postal_code,
                city=city,
                country=country,
                lat=lat,
                lon=lon,
                source=source,
                confidence=confidence,
            )
            self.upsert(c)
            con.execute("UPDATE address_exception_queue SET status='resolved' WHERE key=?", (key,))

