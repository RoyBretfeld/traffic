# backend/services/geocoder_correction_aware.py
from __future__ import annotations
import re
from typing import Optional, Tuple, Union
from pathlib import Path
from .address_corrections import AddressCorrectionStore, make_key, normalize_street


def parse_address_components(address: str) -> Tuple[str, str, str]:
    """
    Extrahiert street, postal_code, city aus einem vollständigen Adress-String.
    
    Format: "Straße, PLZ Stadt" oder "Straße, PLZ, Stadt"
    """
    if not address:
        return "", "", ""
    
    # PLZ finden (5-stellige Zahl)
    plz_match = re.search(r'\b(\d{5})\b', address)
    postal_code = plz_match.group(1) if plz_match else ""
    
    # Stadt nach PLZ extrahieren (alles nach PLZ, außer Kommas/Leerzeichen)
    if plz_match:
        after_plz = address[plz_match.end():].strip()
        # Entferne führende Kommas/Leerzeichen
        after_plz = re.sub(r'^[,\s]+', '', after_plz)
        # Stadt ist normalerweise das nächste Wort
        city_match = re.match(r'^([A-Za-zäöüßÄÖÜ\s\-]+)', after_plz)
        city = city_match.group(1).strip() if city_match else ""
    else:
        city = ""
    
    # Straße ist alles vor der PLZ
    if plz_match:
        street = address[:plz_match.start()].strip().rstrip(',')
    else:
        # Fallback: Alles außer Stadt (wenn Stadt am Ende erkannt werden kann)
        street = address
        # Versuche Stadt am Ende zu finden (z.B. "Straße, Dresden")
        city_match = re.search(r',\s*([A-Za-zäöüßÄÖÜ\s\-]+)$', address)
        if city_match:
            city = city_match.group(1).strip()
            street = address[:city_match.start()].strip().rstrip(',')
    street = street.strip()
    
    return street, postal_code, city


class BaseGeocoder:
    """Basis-Geocoder Interface (Platzhalter für echten Geocoder)."""

    def geocode(self, street: str, postal_code: str, city: str, country: str = "DE") -> Tuple[Optional[float], Optional[float], Optional[str]]:
        # Platzhalter: echter Geocoder (Nominatim/Google) kann hier integriert werden
        return None, None, "no_lookup"


class CorrectionAwareGeocoder(BaseGeocoder):
    """Geocoder der zuerst die Korrekturtabelle prüft, dann optional einen echten Geocoder nutzt."""

    def __init__(self, store: AddressCorrectionStore, delegate: Optional[BaseGeocoder] = None) -> None:
        self.store = store
        self.delegate = delegate or BaseGeocoder()

    def geocode(self, street: Union[str, Tuple[str, str, str]], postal_code: str = "", city: str = "", country: str = "DE") -> Tuple[Optional[float], Optional[float], Optional[str]]:
        """
        Geokodiert eine Adresse:
        1. Prüft zuerst die Korrekturtabelle
        2. Bei Misserfolg: Verwendet Fallback-Geocoder (falls vorhanden)
        3. Bei fehlgeschlagenem Geocoding: Schreibt automatisch in die Queue
        
        Args:
            street: Entweder vollständiger Adress-String ODER Straßenname
            postal_code: Postleitzahl (falls street nur Straßenname ist)
            city: Stadt (falls street nur Straßenname ist)
            country: Land (Standard: "DE")
        
        Returns:
            (lat, lon, error_message) - lat/lon sind None bei Misserfolg
        """
        # Wenn street ein vollständiger Adress-String ist (enthält Kommas und möglicherweise PLZ)
        if isinstance(street, str) and (',' in street or (not postal_code and not city)):
            # Parse Adress-String in Komponenten
            parsed_street, parsed_postal_code, parsed_city = parse_address_components(street)
            if parsed_postal_code:
                postal_code = parsed_postal_code
            if parsed_city:
                city = parsed_city
            if parsed_street:
                street = parsed_street
        
        key = make_key(street, postal_code, city, country)

        # 1) Korrekturtabelle prüfen
        corr = self.store.get(key)
        if corr and corr.lat is not None and corr.lon is not None:
            return corr.lat, corr.lon, None

        # 2) Fallback: echter Geocoder (optional)
        lat, lon, msg = self.delegate.geocode(street, postal_code, city, country)
        if lat is not None and lon is not None:
            # Opportunistisch in Korrekturtabelle übernehmen (Quelle: geocode)
            from .address_corrections import Correction
            correction = Correction(
                key=key,
                street_canonical=normalize_street(street),
                postal_code=postal_code,
                city=city,
                country=country,
                lat=lat,
                lon=lon,
                source='geocode',
                confidence=0.8,
            )
            self.store.upsert(correction)
            return lat, lon, None

        # 3) Unresolved → Queue
        self.store.enqueue_unresolved(street, postal_code, city, country, note=msg or "unresolved")
        return None, None, msg or "unresolved"

    def geocode_from_full_address(self, full_address: str, country: str = "DE") -> Tuple[Optional[float], Optional[float], Optional[str]]:
        """Convenience-Methode: Geocodiert einen vollständigen Adress-String."""
        return self.geocode(full_address, country=country)


def make_geocoder(db_path: Path) -> CorrectionAwareGeocoder:
    """Factory-Funktion zur Erstellung eines CorrectionAwareGeocoders."""
    store = AddressCorrectionStore(db_path)
    return CorrectionAwareGeocoder(store)

