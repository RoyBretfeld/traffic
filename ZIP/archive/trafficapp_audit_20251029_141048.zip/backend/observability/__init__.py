# backend/observability/__init__.py
"""Observability-Module für Metriken und Monitoring"""

