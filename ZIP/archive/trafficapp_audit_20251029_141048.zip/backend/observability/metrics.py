# -*- coding: utf-8 -*-
"""Prometheus-Metriken für TrafficApp."""
from __future__ import annotations
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
from starlette.responses import Response
from fastapi import APIRouter
import time
from pathlib import Path
import os

router = APIRouter()

# Zähler (Counter)
PARSE_OK = Counter('famo_parse_ok_total', 'Erfolgreich geparste Datensätze')
PARSE_WARN = Counter('famo_parse_warn_total', 'Warnungen beim Parsing')
PARSE_BAD = Counter('famo_parse_bad_total', 'Fehler beim Parsing')

GEOCODE_OK = Counter('famo_geocode_ok_total', 'Erfolgreich geokodierte Adressen')
GEOCODE_FAILED = Counter('famo_geocode_failed_total', 'Fehlgeschlagene Geocodierungen')
GEOCODE_CORRECTION_HIT = Counter('famo_geocode_correction_hit_total', 'Geocodierungen über Korrekturtabelle')

# Queue-Größe (Gauge)
GEOCODE_QUEUE = Gauge('famo_geocode_queue_pending', 'Ausstehende Adress-Korrekturen (Queue)')
CORRECTIONS = Gauge('famo_address_corrections_total', 'Gespeicherte Adress-Korrekturen')
MANUAL_QUEUE = Gauge('famo_manual_queue_total', 'Einträge in Manual-Queue')

# Dauer (Histogramm) – Routenoptimierung
ROUTE_OPT_DURATION = Histogram(
    'famo_route_opt_duration_seconds',
    'Dauer der Routenoptimierung in Sekunden',
    buckets=(0.01, 0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10)
)

# CSV-Verarbeitung Dauer
CSV_PROCESS_DURATION = Histogram(
    'famo_csv_process_duration_seconds',
    'Dauer der CSV-Verarbeitung in Sekunden',
    buckets=(0.1, 0.5, 1, 2, 5, 10, 30, 60)
)

# Geocoding Dauer
GEOCODE_DURATION = Histogram(
    'famo_geocode_duration_seconds',
    'Dauer der Geocodierung pro Adresse in Sekunden',
    buckets=(0.1, 0.5, 1, 2, 5, 10)
)


@router.get('/metrics')
async def metrics():
    """Prometheus Metrics Endpunkt."""
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


def update_queue_metrics():
    """Aktualisiert Queue- und Korrekturen-Metriken aus der Datenbank."""
    try:
        from backend.services.address_corrections import AddressCorrectionStore
        
        db_path = Path(os.getenv("ADDRESS_CORRECTIONS_DB", "data/address_corrections.sqlite3"))
        if db_path.exists():
            store = AddressCorrectionStore(db_path)
            queue_count = len(store.list_pending(limit=10_000))
            GEOCODE_QUEUE.set(queue_count)
            
            # Korrekturen zählen
            import sqlite3
            con = sqlite3.connect(db_path)
            corrections_count = con.execute('SELECT COUNT(*) FROM address_corrections').fetchone()[0]
            con.close()
            CORRECTIONS.set(corrections_count)
    except Exception:
        # Bei Fehler Metriken auf 0 setzen
        GEOCODE_QUEUE.set(0)
        CORRECTIONS.set(0)


def update_manual_queue_metric():
    """Aktualisiert Manual-Queue Metrik."""
    try:
        from repositories.manual_repo import list_open
        manual_count = len(list_open(limit=10_000))
        MANUAL_QUEUE.set(manual_count)
    except Exception:
        MANUAL_QUEUE.set(0)


# Hilfs-Dekorator zum Messen der Dauer
class measure_route_opt:
    """Context Manager zum Messen der Routenoptimierungs-Dauer."""
    
    def __enter__(self):
        self.t0 = time.perf_counter()
        return self
    
    def __exit__(self, *exc):
        dt = time.perf_counter() - self.t0
        ROUTE_OPT_DURATION.observe(dt)


class measure_csv_process:
    """Context Manager zum Messen der CSV-Verarbeitungs-Dauer."""
    
    def __enter__(self):
        self.t0 = time.perf_counter()
        return self
    
    def __exit__(self, *exc):
        dt = time.perf_counter() - self.t0
        CSV_PROCESS_DURATION.observe(dt)


class measure_geocode:
    """Context Manager zum Messen der Geocoding-Dauer."""
    
    def __enter__(self):
        self.t0 = time.perf_counter()
        return self
    
    def __exit__(self, *exc):
        dt = time.perf_counter() - self.t0
        GEOCODE_DURATION.observe(dt)

