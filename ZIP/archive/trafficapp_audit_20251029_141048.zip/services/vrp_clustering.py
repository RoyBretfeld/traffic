# -*- coding: utf-8 -*-
"""
VRP Clustering Service für FAMO TrafficApp

Implementiert eine Cluster-First-Route-Second-Heuristik für Vehicle Routing Problem (VRP)
mit strengen Zeitrestriktionen:
- Servicezeit: 2 Min pro Kunde
- Tourdauer: 50-70 Min (60 Min ± 10 Min)
- Max. Gesamteinsatzzeit: 80 Min
"""

import math
import logging
from typing import List, Dict, Any, Tuple, Optional
from dataclasses import dataclass
import random
from collections import defaultdict

@dataclass
class TourResult:
    """Ergebnis einer optimierten Tour"""
    stops: List[Dict]
    total_duration: float
    driving_time: float
    service_time: float
    is_valid: bool
    violations: List[str]

class VRPClusteringService:
    """VRP Clustering Service mit Cluster-First-Route-Second-Heuristik"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Zeitrestriktionen (Hard Constraints) - Ursprüngliche Werte
        self.SERVICE_TIME_PER_CUSTOMER = 2.0  # Minuten
        self.MIN_TOUR_DURATION = 50.0  # Minuten
        self.MAX_TOUR_DURATION = 70.0  # Minuten
        self.MAX_TOTAL_WORK_TIME = 80.0  # Minuten
        
        # Heuristik-Parameter
        self.MAX_CLUSTER_SIZE = 8  # Max. Kunden pro Tour
        self.CLUSTERING_ITERATIONS = 100
        
    def calculate_travel_time(self, coord1: Dict, coord2: Dict) -> float:
        """
        Berechnet die Fahrzeit zwischen zwei Koordinaten
        Verwendet Haversine-Formel für Distanz und vereinfachte Geschwindigkeit
        
        Args:
            coord1: {'lat': float, 'lon': float}
            coord2: {'lat': float, 'lon': float}
            
        Returns:
            Fahrzeit in Minuten
        """
        try:
            lat1, lon1 = float(coord1['lat']), float(coord1['lon'])
            lat2, lon2 = float(coord2['lat']), float(coord2['lon'])
            
            # Haversine-Formel für Distanz
            R = 6371000.0  # Erdradius in Metern
            
            lat1_rad = math.radians(lat1)
            lat2_rad = math.radians(lat2)
            delta_lat = math.radians(lat2 - lat1)
            delta_lon = math.radians(lon2 - lon1)
            
            a = (math.sin(delta_lat / 2) ** 2 + 
                 math.cos(lat1_rad) * math.cos(lat2_rad) * 
                 math.sin(delta_lon / 2) ** 2)
            c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
            
            distance_meters = R * c
            
            # Realistische Geschwindigkeit für Dresden: 40 km/h Durchschnitt
            # Berücksichtigt Stadtverkehr, Ampeln, aber auch freie Straßen
            speed_kmh = 40.0
            speed_ms = speed_kmh * 1000 / 3600  # m/s
            
            travel_time_minutes = (distance_meters / speed_ms) / 60.0
            
            # Minimal 1 Minute, maximal 30 Minuten pro Fahrt
            travel_time_minutes = max(1.0, min(30.0, travel_time_minutes))
            
            return round(travel_time_minutes, 2)
            
        except Exception as e:
            self.logger.error(f"Fehler bei Zeitberechnung: {e}")
            return 5.0  # Fallback: 5 Minuten
    
    def calculate_tour_duration(self, stops: List[Dict], depot: Dict) -> Tuple[float, float, float]:
        """
        Berechnet die Gesamtdauer einer Tour
        
        Args:
            stops: Liste der Kundenstopps
            depot: Depot-Koordinaten
            
        Returns:
            (total_duration, driving_time, service_time)
        """
        if not stops:
            return 0.0, 0.0, 0.0
        
        # Servicezeit für alle Kunden
        service_time = len(stops) * self.SERVICE_TIME_PER_CUSTOMER
        
        # Fahrzeit berechnen
        driving_time = 0.0
        
        # Depot → Erster Kunde
        driving_time += self.calculate_travel_time(depot, stops[0])
        
        # Zwischen Kunden
        for i in range(len(stops) - 1):
            driving_time += self.calculate_travel_time(stops[i], stops[i + 1])
        
        # Letzter Kunde → Depot
        driving_time += self.calculate_travel_time(stops[-1], depot)
        
        total_duration = driving_time + service_time
        
        return round(total_duration, 2), round(driving_time, 2), round(service_time, 2)
    
    def validate_tour(self, stops: List[Dict], depot: Dict) -> TourResult:
        """
        Validiert eine Tour gegen die Zeitrestriktionen
        
        Args:
            stops: Liste der Kundenstopps
            depot: Depot-Koordinaten
            
        Returns:
            TourResult mit Validierungsergebnissen
        """
        violations = []
        
        if not stops:
            violations.append("Leere Tour")
            return TourResult(stops, 0.0, 0.0, 0.0, False, violations)
        
        total_duration, driving_time, service_time = self.calculate_tour_duration(stops, depot)
        
        # Prüfe Tourdauer-Restriktion
        if total_duration < self.MIN_TOUR_DURATION:
            violations.append(f"Tour zu kurz: {total_duration:.1f} Min < {self.MIN_TOUR_DURATION} Min")
        
        if total_duration > self.MAX_TOUR_DURATION:
            violations.append(f"Tour zu lang: {total_duration:.1f} Min > {self.MAX_TOUR_DURATION} Min")
        
        # Prüfe Cluster-Größe
        if len(stops) > self.MAX_CLUSTER_SIZE:
            violations.append(f"Zu viele Kunden: {len(stops)} > {self.MAX_CLUSTER_SIZE}")
        
        is_valid = len(violations) == 0
        
        return TourResult(stops, total_duration, driving_time, service_time, is_valid, violations)
    
    def nearest_neighbor_route(self, stops: List[Dict], depot: Dict) -> List[Dict]:
        """
        Nearest-Neighbor-Heuristik für Routing innerhalb eines Clusters
        
        Args:
            stops: Liste der Kundenstopps
            depot: Depot-Koordinaten
            
        Returns:
            Optimierte Reihenfolge der Stopps
        """
        if not stops:
            return []
        
        if len(stops) == 1:
            return stops
        
        # Starte mit dem nächsten Kunden zum Depot
        unvisited = stops.copy()
        route = []
        
        # Finde nächsten Kunden zum Depot
        current_pos = depot
        while unvisited:
            nearest_stop = min(unvisited, 
                             key=lambda s: self.calculate_travel_time(current_pos, s))
            route.append(nearest_stop)
            unvisited.remove(nearest_stop)
            current_pos = nearest_stop
        
        return route
    
    def k_means_clustering(self, stops: List[Dict], depot: Dict, k: int) -> List[List[Dict]]:
        """
        K-Means-Clustering für Kundenstopps
        
        Args:
            stops: Liste der Kundenstopps
            depot: Depot-Koordinaten
            k: Anzahl der Cluster
            
        Returns:
            Liste von Clustern (Touren)
        """
        if not stops or k <= 0:
            return []
        
        if len(stops) <= k:
            return [[stop] for stop in stops]
        
        # Initialisiere Cluster-Zentren zufällig
        centroids = random.sample(stops, k)
        
        for iteration in range(self.CLUSTERING_ITERATIONS):
            # Weise jeden Stopp dem nächsten Zentrum zu
            clusters = [[] for _ in range(k)]
            
            for stop in stops:
                distances = [self.calculate_travel_time(stop, centroid) for centroid in centroids]
                closest_centroid = distances.index(min(distances))
                clusters[closest_centroid].append(stop)
            
            # Aktualisiere Zentren
            new_centroids = []
            for cluster in clusters:
                if cluster:
                    avg_lat = sum(s['lat'] for s in cluster) / len(cluster)
                    avg_lon = sum(s['lon'] for s in cluster) / len(cluster)
                    new_centroids.append({'lat': avg_lat, 'lon': avg_lon})
                else:
                    # Leere Cluster: zufälliges Zentrum
                    new_centroids.append(random.choice(stops))
            
            # Prüfe Konvergenz
            if all(self.calculate_travel_time(old, new) < 0.1 
                   for old, new in zip(centroids, new_centroids)):
                break
            
            centroids = new_centroids
        
        return clusters
    
    def optimize_cluster_size(self, stops: List[Dict], depot: Dict) -> List[List[Dict]]:
        """
        Optimiert die Cluster-Größe basierend auf Zeitrestriktionen
        
        Args:
            stops: Liste der Kundenstopps
            depot: Depot-Koordinaten
            
        Returns:
            Liste von optimierten Clustern
        """
        if not stops:
            return []
        
        # Fallback: Einfache Aufteilung wenn K-Means fehlschlägt
        if len(stops) <= 6:
            # Wenige Kunden: Eine Tour
            route = self.nearest_neighbor_route(stops, depot)
            result = self.validate_tour(route, depot)
            if result.is_valid:
                return [route]
            else:
                # Aufteilen in kleinere Gruppen
                return self._split_into_valid_tours(stops, depot)
        
        # Spezialfall: Nur ein Kunde oder wenige Kunden
        if len(stops) <= 2:
            return [stops]
        
        # Versuche verschiedene Cluster-Größen
        best_clusters = []
        best_score = float('inf')
        
        # Optimale Cluster-Anzahl berechnen: Ziel 4-6 Kunden pro Tour
        target_customers_per_tour = 5
        optimal_k = max(1, len(stops) // target_customers_per_tour)
        
        # Starte mit optimaler Cluster-Anzahl, aber teste auch weniger Cluster
        max_k = min(optimal_k + 1, self.MAX_CLUSTER_SIZE)
        
        for k in range(max(1, optimal_k - 1), max_k + 1):
            clusters = self.k_means_clustering(stops, depot, k)
            
            # Validiere alle Cluster
            valid_clusters = []
            total_violations = 0
            
            for cluster in clusters:
                if cluster:
                    route = self.nearest_neighbor_route(cluster, depot)
                    result = self.validate_tour(route, depot)
                    
                    if result.is_valid:
                        valid_clusters.append(route)
                    else:
                        total_violations += len(result.violations)
            
            # Bewerte Lösung: Bevorzuge Cluster mit 4-6 Kunden
            if valid_clusters:
                # Berechne durchschnittliche Cluster-Größe
                avg_cluster_size = sum(len(cluster) for cluster in valid_clusters) / len(valid_clusters)
                
                # Score basierend auf Cluster-Größe und Verletzungen
                size_penalty = abs(avg_cluster_size - target_customers_per_tour) * 2
                violation_penalty = total_violations * 10
                empty_cluster_penalty = (len(clusters) - len(valid_clusters)) * 5
                
                score = size_penalty + violation_penalty + empty_cluster_penalty
                
                if score < best_score:
                    best_score = score
                    best_clusters = valid_clusters
                    self.logger.info(f"Neue beste Lösung: k={k}, Score={score:.1f}, "
                                   f"Cluster={len(valid_clusters)}, Avg-Größe={avg_cluster_size:.1f}")
        
        # Fallback: Aufteilen in gültige Touren
        if not best_clusters:
            self.logger.warning("K-Means-Clustering fehlgeschlagen, verwende Fallback")
            return self._split_into_valid_tours(stops, depot)
        
        return best_clusters
    
    def _split_into_valid_tours(self, stops: List[Dict], depot: Dict) -> List[List[Dict]]:
        """
        Fallback: Teilt Stopps in gültige Touren auf
        
        Args:
            stops: Liste der Kundenstopps
            depot: Depot-Koordinaten
            
        Returns:
            Liste von gültigen Touren
        """
        if not stops:
            return []
        
        tours = []
        current_tour = []
        
        for stop in stops:
            # Teste ob Stop zur aktuellen Tour hinzugefügt werden kann
            test_tour = current_tour + [stop]
            route = self.nearest_neighbor_route(test_tour, depot)
            result = self.validate_tour(route, depot)
            
            if result.is_valid and len(test_tour) <= self.MAX_CLUSTER_SIZE:
                current_tour = test_tour
            else:
                # Aktuelle Tour abschließen
                if current_tour:
                    route = self.nearest_neighbor_route(current_tour, depot)
                    tours.append(route)
                current_tour = [stop]
        
        # Letzte Tour hinzufügen
        if current_tour:
            route = self.nearest_neighbor_route(current_tour, depot)
            tours.append(route)
        
        return tours
    
    def deduplicate_customers(self, stops: List[Dict]) -> List[Dict]:
        """
        Entfernt Duplikate basierend auf Kunden-ID oder Adresse
        
        Args:
            stops: Liste der Kundenstopps
            
        Returns:
            Deduplizierte Liste der Stopps
        """
        if not stops:
            return []
        
        seen_customers = set()
        deduplicated_stops = []
        
        for stop in stops:
            # Erstelle einen eindeutigen Schlüssel für den Kunden
            customer_key = None
            
            # Priorität 1: Kunden-ID
            if 'id' in stop and stop['id']:
                customer_key = f"id_{stop['id']}"
            
            # Priorität 2: Kunden-Nummer
            elif 'customer_number' in stop and stop['customer_number']:
                customer_key = f"kdnr_{stop['customer_number']}"
            
            # Priorität 3: Adresse (Straße + PLZ + Stadt)
            elif all(key in stop for key in ['street', 'postal_code', 'city']):
                street = str(stop.get('street', '')).strip().lower()
                postal_code = str(stop.get('postal_code', '')).strip()
                city = str(stop.get('city', '')).strip().lower()
                customer_key = f"addr_{street}_{postal_code}_{city}"
            
            # Priorität 4: Name + Adresse
            elif 'name' in stop and all(key in stop for key in ['street', 'postal_code']):
                name = str(stop.get('name', '')).strip().lower()
                street = str(stop.get('street', '')).strip().lower()
                postal_code = str(stop.get('postal_code', '')).strip()
                customer_key = f"name_{name}_{street}_{postal_code}"
            
            # Fallback: Koordinaten (falls sehr nah beieinander)
            elif all(key in stop for key in ['lat', 'lon']):
                try:
                    lat = round(float(stop['lat']), 4)  # ~11m Genauigkeit
                    lon = round(float(stop['lon']), 4)
                    customer_key = f"coord_{lat}_{lon}"
                except (ValueError, TypeError):
                    customer_key = f"unknown_{len(deduplicated_stops)}"
            else:
                customer_key = f"unknown_{len(deduplicated_stops)}"
            
            # Prüfe ob Kunde bereits gesehen wurde
            if customer_key not in seen_customers:
                seen_customers.add(customer_key)
                deduplicated_stops.append(stop)
            else:
                self.logger.info(f"Duplikat entfernt: {customer_key}")
        
        removed_count = len(stops) - len(deduplicated_stops)
        if removed_count > 0:
            self.logger.info(f"Duplikat-Deduplizierung: {removed_count} Duplikate entfernt "
                           f"({len(stops)} -> {len(deduplicated_stops)} Stopps)")
        
        return deduplicated_stops
    
    def cluster_and_route_tours(self, stops: List[Dict], depot_location: Dict) -> List[List[Dict]]:
        """
        Hauptfunktion: Cluster-First-Route-Second-Heuristik
        
        Args:
            stops: Liste von Kundenstopps mit Koordinaten
            depot_location: Depot-Koordinaten {'lat': float, 'lon': float}
            
        Returns:
            Liste von validierten Touren (jede Tour ist eine Liste von Stopps)
        """
        self.logger.info(f"Starte VRP-Clustering für {len(stops)} Kunden")
        
        if not stops:
            self.logger.warning("Keine Stopps zum Clustern")
            return []
        
        if not depot_location or 'lat' not in depot_location or 'lon' not in depot_location:
            self.logger.error("Ungültige Depot-Koordinaten")
            return []
        
        # Validiere Eingabedaten
        valid_stops = []
        for i, stop in enumerate(stops):
            if not isinstance(stop, dict):
                self.logger.warning(f"Stopp {i} ist kein Dictionary: {stop}")
                continue
            
            if 'lat' not in stop or 'lon' not in stop:
                self.logger.warning(f"Stopp {i} hat keine Koordinaten: {stop}")
                continue
            
            try:
                float(stop['lat'])
                float(stop['lon'])
                valid_stops.append(stop)
            except (ValueError, TypeError):
                self.logger.warning(f"Stopp {i} hat ungültige Koordinaten: {stop}")
                continue
        
        if not valid_stops:
            self.logger.error("Keine gültigen Stopps gefunden")
            return []
        
        self.logger.info(f"Verarbeite {len(valid_stops)} gültige Stopps")
        
        # Duplikat-Deduplizierung (temporär deaktiviert - zu aggressiv)
        logging.info(f"Skippe Deduplizierung - verwende alle {len(valid_stops)} Stopps")
        deduplicated_stops = valid_stops
        
        if not deduplicated_stops:
            self.logger.error("Keine Stopps nach Deduplizierung")
            return []
        
        # Cluster-First-Route-Second-Heuristik
        try:
            # 1. Clustering: Optimale Cluster-Größe finden
            clusters = self.optimize_cluster_size(deduplicated_stops, depot_location)
            
            if not clusters:
                self.logger.warning("Keine gültigen Cluster gefunden")
                return []
            
            # 2. Routing: Nearest-Neighbor für jeden Cluster
            optimized_tours = []
            total_work_time = 0.0
            
            for i, cluster in enumerate(clusters):
                if cluster:
                    # Route optimieren
                    route = self.nearest_neighbor_route(cluster, depot_location)
                    
                    # Tour validieren
                    result = self.validate_tour(route, depot_location)
                    
                    if result.is_valid:
                        optimized_tours.append(route)
                        total_work_time += result.total_duration
                        
                        self.logger.info(f"Tour {i+1}: {len(route)} Kunden, "
                                       f"{result.total_duration:.1f} Min "
                                       f"(Fahrt: {result.driving_time:.1f}, "
                                       f"Service: {result.service_time:.1f})")
                    else:
                        # Akzeptiere Touren mit kleinen Überschreitungen (bis 5 Min)
                        small_violation = False
                        for violation in result.violations:
                            if 'zu lang' in str(violation) and result.total_duration <= self.MAX_TOUR_DURATION + 5:
                                small_violation = True
                                break
                        
                        if small_violation:
                            optimized_tours.append(route)
                            total_work_time += result.total_duration
                            self.logger.info(f"Tour {i+1}: {len(route)} Kunden (kleine Überschreitung akzeptiert)")
                        elif len(route) <= 3 and any('zu kurz' in str(v) for v in result.violations):
                            optimized_tours.append(route)
                            total_work_time += result.total_duration
                            self.logger.info(f"Tour {i+1}: {len(route)} Kunden (zu kurz, aber akzeptiert)")
                        else:
                            self.logger.warning(f"Tour {i+1} ungültig: {result.violations}")
            
            # Prüfe Gesamteinsatzzeit
            if total_work_time > self.MAX_TOTAL_WORK_TIME:
                self.logger.warning(f"Gesamteinsatzzeit überschritten: "
                                  f"{total_work_time:.1f} Min > {self.MAX_TOTAL_WORK_TIME} Min")
            
            self.logger.info(f"VRP-Clustering abgeschlossen: {len(optimized_tours)} Touren, "
                           f"{total_work_time:.1f} Min Gesamtzeit")
            
            return optimized_tours
            
        except Exception as e:
            self.logger.error(f"Fehler beim VRP-Clustering: {e}")
            return []
    
    def get_clustering_stats(self, tours: List[List[Dict]], depot: Dict) -> Dict[str, Any]:
        """
        Gibt Statistiken über die Clustering-Ergebnisse zurück
        
        Args:
            tours: Liste von Touren
            depot: Depot-Koordinaten
            
        Returns:
            Dictionary mit Statistiken
        """
        if not tours:
            return {"error": "Keine Touren"}
        
        stats = {
            "total_tours": len(tours),
            "total_customers": sum(len(tour) for tour in tours),
            "avg_customers_per_tour": sum(len(tour) for tour in tours) / len(tours),
            "tour_details": []
        }
        
        total_work_time = 0.0
        
        for i, tour in enumerate(tours):
            if tour:
                duration, driving_time, service_time = self.calculate_tour_duration(tour, depot)
                total_work_time += duration
                
                stats["tour_details"].append({
                    "tour_id": i + 1,
                    "customers": len(tour),
                    "total_duration": duration,
                    "driving_time": driving_time,
                    "service_time": service_time,
                    "is_valid": duration >= self.MIN_TOUR_DURATION and duration <= self.MAX_TOUR_DURATION
                })
        
        stats["total_work_time"] = total_work_time
        stats["work_time_violation"] = total_work_time > self.MAX_TOTAL_WORK_TIME
        
        return stats


# Globale Instanz für einfache Nutzung
vrp_service = VRPClusteringService()

def cluster_and_route_tours(stops: List[Dict], depot_location: Dict) -> List[List[Dict]]:
    """
    Hauptfunktion für VRP-Clustering (externer API)
    
    Args:
        stops: Liste von Kundenstopps mit Koordinaten
        depot_location: Depot-Koordinaten {'lat': float, 'lon': float}
        
    Returns:
        Liste von validierten Touren
    """
    return vrp_service.cluster_and_route_tours(stops, depot_location)
