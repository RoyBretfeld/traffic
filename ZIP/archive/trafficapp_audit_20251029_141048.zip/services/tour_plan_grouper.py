from __future__ import annotations
from collections import OrderedDict
from typing import Dict, List, Tuple

# Importiere Datenstrukturen aus dem Haupt-Parser
from common.tour_data_models import TourInfo, TourStop # Importiere Datenstrukturen

def group_and_consolidate_tours(raw_tour_data: List[Tuple[str, TourStop]]) -> List[Dict]: # Rückgabe ist eine Liste von Dictionaries, nicht TourInfo
    """
    Führt das modulare Gruppieren und die BAR-Konsolidierung durch.
    
    Diese Funktion ersetzt die komplexe Schleifenlogik in _extract_tours
    durch drei stabile Phasen: Mapping, BAR-Vorbereitung und Konsolidierung.
    
    Args:
        raw_tour_data: Liste von (Header-String, TourStop-Objekt) Tupeln 
                       aus der Rohextraktion (tour_plan_raw_reader).
                       
    Returns:
        Liste der finalen TourInfo-Objekte (fertige Touren).
    """
    
    # Phase 1: Eindeutige Tour-Header mappen
    # map: header_string -> Liste[TourStop]
    tours: Dict[str, List[TourStop]] = OrderedDict()
    
    # Phase 2: BAR-Kunden (noch nicht zugeordnet)
    # map: vollständiger_header -> Liste[TourStop]
    pending_bar: Dict[str, List[TourStop]] = {}
    
    # map: base_name -> vollständiger header_string der ERSTEN Haupttour
    full_name_map: Dict[str, str] = {}
    
    # Liste der Header in Reihenfolge des Auftretens
    header_order: List[str] = []

    for header, stop in raw_tour_data:
        base = TourInfo.get_base_name(header) # Annahme: get_base_name existiert in TourInfo oder ist eine separate Utility
        
        if stop.is_bar_stop:
            # BAR-Stop: Wird nur im pending_bar Puffer gesammelt
            # Verwende den VOLLSTÄNDIGEN Header, nicht den base_name
            pending_bar.setdefault(header, []).append(stop)
            
        else:
            # Normale (Haupt-) Tour
            
            # A. Eindeutige Tourenzuweisung (inkl. Zeit)
            if header not in tours:
                tours[header] = []
                header_order.append(header)
                
            # B. Speicherung des Headers für BAR-Zuordnung (nur die ERSTE Version zählt)
            if base not in full_name_map:
                full_name_map[base] = header
            
            # C. Kunden zur Haupttour hinzufügen
            tours[header].append(stop)

    # Phase 3: BAR-Konsolidierung
    # Durchlaufe die gesammelten BAR-Kunden
    consolidated_bars = set()  # Merke welche BAR-Touren konsolidiert wurden
    
    for bar_header, customers in pending_bar.items():
        if not customers:
            continue

        # FIX: Finde die ZEITLICH KORREKTE Haupttour für diese BAR-Kunden
        # Verwende den VOLLSTÄNDIGEN Header für die Zuordnung
        
        # Extrahiere Zeit aus BAR-Header (z.B. "W-07.00 Uhr BAR" -> "07.00")
        bar_time = None
        if "BAR" in bar_header.upper():
            import re
            time_match = re.search(r'(\d{1,2}\.\d{2})', bar_header)
            if time_match:
                bar_time = time_match.group(1)
        
        target_header = None
        
        # Suche nach einer Tour mit der GLEICHEN ZEIT UND ÄHNLICHEM NAMEN
        for header in tours.keys():
            if "BAR" not in header.upper():  # Nur normale Touren
                # Prüfe ob die Zeit übereinstimmt
                if bar_time and bar_time in header:
                    # Zusätzlich: Prüfe ob die Tour-Namen ähnlich sind
                    # (z.B. "W-07.00 Uhr BAR" sollte zu "W-07.00 Uhr Tour")
                    bar_prefix = bar_header.replace("BAR", "").replace(bar_time, "").strip()
                    header_prefix = header.replace("TOUR", "").replace(bar_time, "").strip()
                    
                    # Entferne gemeinsame Wörter wie "Uhr", "Anlief", etc.
                    bar_prefix = re.sub(r'\b(UHR|ANLIEF|TOUR|BAR)\b', '', bar_prefix, flags=re.IGNORECASE).strip()
                    header_prefix = re.sub(r'\b(UHR|ANLIEF|TOUR|BAR)\b', '', header_prefix, flags=re.IGNORECASE).strip()
                    
                    # Wenn die Präfixe ähnlich sind, ist das die richtige Tour
                    if bar_prefix and header_prefix and bar_prefix in header_prefix or header_prefix in bar_prefix:
                        target_header = header
                        break
                    elif not bar_prefix or not header_prefix:
                        # Fallback: erste Tour mit gleicher Zeit
                        target_header = header
                        break
                elif not bar_time:
                    # Fallback: erste normale Tour
                    target_header = header
                    break
        
        # BAR-Kunden sollen in die entsprechende normale Tour integriert werden!
        # Suche nach der passenden normalen Tour mit gleicher Zeit
        
        target_header = None
        
        # Suche nach einer Tour mit der GLEICHEN ZEIT UND ÄHNLICHEM NAMEN
        for header in tours.keys():
            if "BAR" not in header.upper():  # Nur normale Touren
                # Prüfe ob die Zeit übereinstimmt
                if bar_time and bar_time in header:
                    # Zusätzlich: Prüfe ob die Tour-Namen ähnlich sind
                    # (z.B. "W-07.00 Uhr BAR" sollte zu "W-07.00 Uhr Tour")
                    bar_prefix = bar_header.replace("BAR", "").replace(bar_time, "").strip()
                    header_prefix = header.replace("TOUR", "").replace(bar_time, "").strip()
                    
                    # Entferne gemeinsame Wörter wie "Uhr", "Anlief", etc.
                    bar_prefix = re.sub(r'\b(UHR|ANLIEF|TOUR|BAR)\b', '', bar_prefix, flags=re.IGNORECASE).strip()
                    header_prefix = re.sub(r'\b(UHR|ANLIEF|TOUR|BAR)\b', '', header_prefix, flags=re.IGNORECASE).strip()
                    
                    # Wenn die Präfixe ähnlich sind, ist das die richtige Tour
                    if bar_prefix and header_prefix and (bar_prefix in header_prefix or header_prefix in bar_prefix):
                        target_header = header
                        break
                    elif not bar_prefix or not header_prefix:
                        # Fallback: erste Tour mit gleicher Zeit
                        target_header = header
                        break
                elif not bar_time:
                    # Fallback: erste normale Tour
                    target_header = header
                    break
        
        if target_header and target_header in tours:
            # Füge BAR-Kunden am ANFANG der Haupttour ein
            tours[target_header] = customers + tours[target_header]
            consolidated_bars.add(bar_header)  # Markiere als konsolidiert
            print(f"[BAR-INTEGRATION] {bar_header} -> {target_header} ({len(customers)} Kunden)")
            
        else:
            # Wenn keine passende Haupttour gefunden, füge sie als separate
            # BAR-Tour am Ende an (z.B. für "BAR-TOUR UNBEKANNT")
            
            # Verwende den BAR-Header als Fallback
            # WICHTIG: Erzeuge einen eindeutigen Header, falls der base_name generisch ist
            fallback_header = f"BAR-TOUR ({base})" 
            if fallback_header not in tours:
                tours[fallback_header] = []
                header_order.append(fallback_header)
            tours[fallback_header].extend(customers)
            print(f"[BAR-FALLBACK] {bar_header} -> {fallback_header} ({len(customers)} Kunden)")

    # Phase 4: TourInfo-Objekte erstellen
    final_tours = []
    for header in header_order:
        # Überspringe BAR-Tours die bereits konsolidiert wurden
        base = TourInfo.get_base_name(header)
        if base in consolidated_bars and "BAR" in header.upper():
            continue  # Diese BAR-Tour wurde bereits in eine Haupttour konsolidiert
        
        stops = tours.get(header, [])
        if not stops:
            continue
            
        # Hier müssten die parsing-Hilfsfunktionen aus tour_plan_parser.py
        # aufgerufen werden, um die TourInfo-Objekte zu erstellen.
        # Da diese in diesem Modul nicht verfügbar sind, geben wir nur die Maps zurück,
        # damit der Haupt-Parser die TourInfo-Objekte bauen kann.
        
        final_tours.append({
            "header": header,
            "customers": stops
        })

    return final_tours, consolidated_bars # Rückgabe der Liste der Touren-Maps und konsolidierte BAR-Touren
