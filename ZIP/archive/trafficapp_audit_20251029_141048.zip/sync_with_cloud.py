# -*- coding: utf-8 -*-
"""
Cloud-Synchronisation für FAMO TrafficApp KI-Routenberechnung
Synchronisiert lokale Implementierung mit Cloud-Version
"""

import os
import shutil
import json
from pathlib import Path
from datetime import datetime

def sync_with_cloud():
    """Synchronisiert lokale KI-Implementierung mit Cloud-Version"""
    
    print("=" * 60)
    print("FAMO TrafficApp - Cloud-Synchronisation")
    print("=" * 60)
    
    # Cloud-Pfad
    cloud_path = Path("C:/Users/Bretfeld/Meine Ablage/______Famo TrafficApp 3.0")
    
    if not cloud_path.exists():
        print(f"Cloud-Pfad nicht gefunden: {cloud_path}")
        return False
    
    print(f"Cloud-Pfad gefunden: {cloud_path}")
    
    # Lokale Dateien für Synchronisation
    local_files = {
        "services/vrp_clustering.py": "services/vrp_clustering.py",
        "routes/ki_routes.py": "routes/ki_routes.py", 
        "frontend/index.html": "frontend/index.html",
        "backend/app.py": "backend/app.py",
        "docs/KI_ROUTENBERECHNUNG_DOKUMENTATION.md": "docs/KI_ROUTENBERECHNUNG_DOKUMENTATION.md",
        "docs/FAMO_TrafficApp_MasterDoku.md": "docs/FAMO_TrafficApp_MasterDoku.md",
        "STATUS_REPORT.md": "STATUS_REPORT.md"
    }
    
    # Synchronisations-Log
    sync_log = {
        "timestamp": datetime.now().isoformat(),
        "files_synced": [],
        "files_skipped": [],
        "errors": []
    }
    
    # Kopiere Dateien zur Cloud
    for local_file, cloud_file in local_files.items():
        try:
            local_path = Path(local_file)
            cloud_file_path = cloud_path / cloud_file
            
            if local_path.exists():
                # Erstelle Verzeichnis falls nötig
                cloud_file_path.parent.mkdir(parents=True, exist_ok=True)
                
                # Kopiere Datei
                shutil.copy2(local_path, cloud_file_path)
                sync_log["files_synced"].append(str(local_file))
                print(f"✅ Synchronisiert: {local_file} -> {cloud_file}")
            else:
                sync_log["files_skipped"].append(f"{local_file} (nicht gefunden)")
                print(f"⚠️ Übersprungen: {local_file} (nicht gefunden)")
                
        except Exception as e:
            sync_log["errors"].append(f"{local_file}: {str(e)}")
            print(f"❌ Fehler bei {local_file}: {e}")
    
    # Kopiere Cloud-Dateien zur lokalen Version (falls vorhanden)
    cloud_files_to_sync = {
        "services/llm_optimizer.py": "services/llm_optimizer.py",
        "services/secure_key_manager.py": "services/secure_key_manager.py",
        "config.env": "config.env"
    }
    
    print("\n" + "=" * 40)
    print("Cloud -> Lokal Synchronisation")
    print("=" * 40)
    
    for cloud_file, local_file in cloud_files_to_sync.items():
        try:
            cloud_file_path = cloud_path / cloud_file
            local_path = Path(local_file)
            
            if cloud_file_path.exists():
                # Erstelle Verzeichnis falls nötig
                local_path.parent.mkdir(parents=True, exist_ok=True)
                
                # Kopiere Datei
                shutil.copy2(cloud_file_path, local_path)
                sync_log["files_synced"].append(f"{cloud_file} -> {local_file}")
                print(f"✅ Synchronisiert: {cloud_file} -> {local_file}")
            else:
                sync_log["files_skipped"].append(f"{cloud_file} (nicht in Cloud)")
                print(f"⚠️ Übersprungen: {cloud_file} (nicht in Cloud)")
                
        except Exception as e:
            sync_log["errors"].append(f"{cloud_file}: {str(e)}")
            print(f"❌ Fehler bei {cloud_file}: {e}")
    
    # Speichere Synchronisations-Log
    log_file = Path("sync_log.json")
    with open(log_file, 'w', encoding='utf-8') as f:
        json.dump(sync_log, f, indent=2, ensure_ascii=False)
    
    # Zusammenfassung
    print("\n" + "=" * 60)
    print("Synchronisation abgeschlossen!")
    print("=" * 60)
    print(f"✅ Dateien synchronisiert: {len(sync_log['files_synced'])}")
    print(f"⚠️ Dateien übersprungen: {len(sync_log['files_skipped'])}")
    print(f"❌ Fehler: {len(sync_log['errors'])}")
    
    if sync_log["errors"]:
        print("\nFehler:")
        for error in sync_log["errors"]:
            print(f"  - {error}")
    
    print(f"\n📝 Log gespeichert: {log_file}")
    
    return len(sync_log["errors"]) == 0

def create_cloud_readme():
    """Erstellt README für Cloud-Version"""
    
    readme_content = """# FAMO TrafficApp 3.0 - Cloud Version

## KI-Routenberechnung Synchronisation

**Letzte Synchronisation:** {timestamp}

### Lokale Implementierung
- **VRP-Clustering:** Cluster-First-Route-Second-Heuristik
- **API-Endpunkte:** `/api/ki/calculate-routes`, `/api/ki/status`
- **Frontend:** Himmelblauer Multi Tour Generator Button
- **Duplikat-Deduplizierung:** Automatische Entfernung mehrfacher Kundenanrufe

### Cloud-Features
- **OpenAI GPT-4o-mini Integration**
- **Verschlüsselte API-Key-Verwaltung**
- **Erweiterte LLM-Optimierung**
- **Monitoring und Metriken**

### Synchronisierte Dateien
- `services/vrp_clustering.py` - VRP-Clustering Algorithmus
- `routes/ki_routes.py` - KI-Routenberechnung API
- `frontend/index.html` - Frontend-Integration
- `backend/app.py` - Backend-Integration
- `docs/KI_ROUTENBERECHNUNG_DOKUMENTATION.md` - Vollständige Dokumentation

### Nächste Schritte
1. Duplikat-Deduplizierung reaktivieren
2. Cloud-LLM-Integration testen
3. Performance-Optimierung
4. Benutzer-Tests durchführen

---
**Status:** Synchronisiert ✅
""".format(timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    
    cloud_path = Path("C:/Users/Bretfeld/Meine Ablage/______Famo TrafficApp 3.0")
    readme_file = cloud_path / "KI_SYNC_README.md"
    
    try:
        with open(readme_file, 'w', encoding='utf-8') as f:
            f.write(readme_content)
        print(f"✅ Cloud-README erstellt: {readme_file}")
        return True
    except Exception as e:
        print(f"❌ Fehler beim Erstellen der Cloud-README: {e}")
        return False

if __name__ == "__main__":
    success = sync_with_cloud()
    create_cloud_readme()
    
    if success:
        print("\n🎉 Cloud-Synchronisation erfolgreich!")
    else:
        print("\n⚠️ Cloud-Synchronisation mit Fehlern abgeschlossen")
    
    print("\nNächste Schritte:")
    print("1. Cloud-Version testen")
    print("2. LLM-Integration aktivieren")
    print("3. Performance-Optimierung")
    print("4. Dokumentation aktualisieren")
