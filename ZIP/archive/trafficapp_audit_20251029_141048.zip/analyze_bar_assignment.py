#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BAR-Kunden Zuordnungs-Analyse
"""
import sys
sys.path.append('.')

def analyze_bar_assignment():
    """Analysiere wie BAR-Kunden zugeordnet werden"""
    try:
        from backend.parsers.tour_plan_parser import parse_tour_plan_to_dict
        
        # Analysiere die aktuelle CSV-Datei
        csv_file = 'tourplaene/Tourenplan 30.09.2025.csv'
        tour_data = parse_tour_plan_to_dict(csv_file)
        
        print('BAR-KUNDEN ZUORDNUNGS-ANALYSE:')
        print('=' * 60)
        
        # Finde alle Touren mit BAR-Kunden
        tours_with_bar = []
        all_bar_customers = []
        
        for tour in tour_data.get('tours', []):
            bar_customers = [c for c in tour.get('customers', []) if c.get('bar_flag', False)]
            if bar_customers:
                tours_with_bar.append({
                    'name': tour.get('name', ''),
                    'bar_customers': bar_customers,
                    'total_customers': len(tour.get('customers', []))
                })
                all_bar_customers.extend(bar_customers)
        
        print(f'Touren mit BAR-Kunden: {len(tours_with_bar)}')
        print(f'Gesamt BAR-Kunden: {len(all_bar_customers)}')
        print()
        
        for i, tour in enumerate(tours_with_bar, 1):
            print(f'{i}. TOUR: {tour["name"]}')
            print(f'   Gesamt Kunden: {tour["total_customers"]}')
            print(f'   BAR-Kunden: {len(tour["bar_customers"])}')
            
            for j, bar_customer in enumerate(tour["bar_customers"], 1):
                print(f'     {j}. {bar_customer["name"]} (KdNr: {bar_customer["customer_number"]})')
                print(f'        Adresse: {bar_customer["street"]}, {bar_customer["postal_code"]} {bar_customer["city"]}')
            print()
        
        # Prüfe auf falsche Zuordnungen
        print('PROBLEM-ANALYSE:')
        print('=' * 30)
        
        for tour in tours_with_bar:
            tour_name = tour["name"]
            bar_count = len(tour["bar_customers"])
            total_count = tour["total_customers"]
            
            if "BAR" in tour_name.upper():
                print(f'OK: {tour_name} - {bar_count} BAR-Kunden (erwartet)')
            else:
                print(f'PROBLEM: {tour_name} - {bar_count} BAR-Kunden in normaler Tour!')
                print(f'         Das sind {bar_count} von {total_count} Kunden ({bar_count/total_count*100:.1f}%)')
                
    except Exception as e:
        print(f'Fehler: {e}')
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    analyze_bar_assignment()
