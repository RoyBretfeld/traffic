# -*- coding: utf-8 -*-
"""
Test für VRP Clustering Service
"""

import sys
from pathlib import Path
import logging

# Projekt-Root zum Python-Pfad hinzufügen
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from services.vrp_clustering import cluster_and_route_tours, vrp_service

def test_vrp_clustering():
    """Test der VRP-Clustering-Funktion"""
    
    # Logging konfigurieren
    logging.basicConfig(level=logging.INFO)
    
    print("=" * 60)
    print("VRP CLUSTERING TEST")
    print("=" * 60)
    
    # Test-Daten: Kundenstopps in Dresden mit größeren Entfernungen
    test_stops = [
        {"id": "K001", "lat": 51.050407, "lon": 13.737262, "name": "Kunde 1"},  # Dresden Zentrum
        {"id": "K002", "lat": 51.060407, "lon": 13.747262, "name": "Kunde 2"},  # Dresden Nord-Ost
        {"id": "K003", "lat": 51.040407, "lon": 13.727262, "name": "Kunde 3"},  # Dresden Süd-West
        {"id": "K004", "lat": 51.070407, "lon": 13.757262, "name": "Kunde 4"},  # Dresden Nord-Ost
        {"id": "K005", "lat": 51.030407, "lon": 13.717262, "name": "Kunde 5"},  # Dresden Süd-West
        {"id": "K006", "lat": 51.080407, "lon": 13.767262, "name": "Kunde 6"},  # Dresden Nord-Ost
        {"id": "K007", "lat": 51.020407, "lon": 13.707262, "name": "Kunde 7"},  # Dresden Süd-West
        {"id": "K008", "lat": 51.090407, "lon": 13.777262, "name": "Kunde 8"},  # Dresden Nord-Ost
        {"id": "K009", "lat": 51.010407, "lon": 13.697262, "name": "Kunde 9"},  # Dresden Süd-West
        {"id": "K010", "lat": 51.100407, "lon": 13.787262, "name": "Kunde 10"}, # Dresden Nord-Ost
    ]
    
    # Depot-Koordinaten
    depot = {"lat": 51.050407, "lon": 13.737262}  # Dresden Zentrum
    
    print(f"Test-Daten:")
    print(f"- {len(test_stops)} Kundenstopps")
    print(f"- Depot: {depot['lat']}, {depot['lon']}")
    print(f"- Servicezeit pro Kunde: {vrp_service.SERVICE_TIME_PER_CUSTOMER} Min")
    print(f"- Tourdauer-Restriktion: {vrp_service.MIN_TOUR_DURATION}-{vrp_service.MAX_TOUR_DURATION} Min")
    print(f"- Max. Gesamteinsatzzeit: {vrp_service.MAX_TOTAL_WORK_TIME} Min")
    print()
    
    # VRP-Clustering ausführen
    print("Führe VRP-Clustering aus...")
    tours = cluster_and_route_tours(test_stops, depot)
    
    print(f"\nErgebnis: {len(tours)} Touren erstellt")
    print()
    
    # Detaillierte Ergebnisse
    for i, tour in enumerate(tours):
        print(f"Tour {i+1}:")
        print(f"  Kunden: {len(tour)}")
        
        # Tour-Dauer berechnen
        duration, driving_time, service_time = vrp_service.calculate_tour_duration(tour, depot)
        print(f"  Gesamtdauer: {duration:.1f} Min")
        print(f"  Fahrzeit: {driving_time:.1f} Min")
        print(f"  Servicezeit: {service_time:.1f} Min")
        
        # Validierung
        result = vrp_service.validate_tour(tour, depot)
        if result.is_valid:
            print(f"  Status: VALID")
        else:
            print(f"  Status: INVALID - {result.violations}")
        
        print(f"  Route: ", end="")
        for j, stop in enumerate(tour):
            if j > 0:
                print(" -> ", end="")
            print(f"{stop['name']}", end="")
        print()
        print()
    
    # Statistiken
    if tours:
        stats = vrp_service.get_clustering_stats(tours, depot)
        print("STATISTIKEN:")
        print(f"- Gesamte Touren: {stats['total_tours']}")
        print(f"- Gesamte Kunden: {stats['total_customers']}")
        print(f"- Durchschnitt Kunden/Tour: {stats['avg_customers_per_tour']:.1f}")
        print(f"- Gesamteinsatzzeit: {stats['total_work_time']:.1f} Min")
        
        if stats['work_time_violation']:
            print(f"- WARNUNG: Gesamteinsatzzeit überschritten!")
        else:
            print(f"- OK: Gesamteinsatzzeit OK")
    else:
        print("STATISTIKEN:")
        print("- Keine Touren erstellt")
    
    print()
    
    # Test mit verschiedenen Szenarien
    print("WEITERE TESTS:")
    print()
    
    # Test 1: Wenige Kunden (<=6)
    print("Test 1: Wenige Kunden (<=6)")
    few_stops = test_stops[:4]
    tours_few = cluster_and_route_tours(few_stops, depot)
    print(f"  {len(few_stops)} Kunden -> {len(tours_few)} Touren")
    print()
    
    # Test 2: Viele Kunden (>6)
    print("Test 2: Viele Kunden (>6)")
    many_stops = test_stops[:8]
    tours_many = cluster_and_route_tours(many_stops, depot)
    print(f"  {len(many_stops)} Kunden -> {len(tours_many)} Touren")
    print()
    
    # Test 3: Leere Eingabe
    print("Test 3: Leere Eingabe")
    tours_empty = cluster_and_route_tours([], depot)
    print(f"  0 Kunden -> {len(tours_empty)} Touren")
    print()
    
    print("=" * 60)
    print("VRP CLUSTERING TEST ABGESCHLOSSEN")
    print("=" * 60)

if __name__ == "__main__":
    test_vrp_clustering()
