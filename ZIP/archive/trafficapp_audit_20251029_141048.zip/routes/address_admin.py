# routes/address_admin.py
"""
Router für Adress-Admin (kann in bestehende App integriert werden)
"""
from __future__ import annotations
from fastapi import APIRouter
from admin.address_admin_app_compat import (
    app as admin_app,
    store,
    DB_PATH,
    MIGR_PATH,
    _IS_PYDANTIC_V2,
    ResolveIn
)
from fastapi import HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse
import tempfile
import sqlite3
from pathlib import Path

router = APIRouter(prefix="/admin/address", tags=["admin"])

# Router für Integration in bestehende FastAPI-App
# Alle Endpunkte sind unter /admin/address/ verfügbar

@router.get("/", response_class=HTMLResponse)
async def admin_page():
    """Hauptseite der Admin-Oberfläche."""
    # Hole HTML von der Admin-App
    import admin.address_admin_app_compat
    html = admin.address_admin_app_compat.INDEX_HTML
    return HTMLResponse(html)

@router.get("/ping")
async def ping():
    """Health-Check Endpunkt."""
    return {
        "status": "ok",
        "pydantic_v2": _IS_PYDANTIC_V2,
        "db": str(DB_PATH),
        "migrations": str(MIGR_PATH) if MIGR_PATH else "not_found"
    }

@router.get("/pending")
async def get_pending(limit: int = 100):
    """Listet ausstehende Korrekturen."""
    return store.list_pending(limit=limit)

@router.get("/stats")
async def get_stats():
    """Gibt Statistiken zurück."""
    try:
        con = sqlite3.connect(DB_PATH)
        cur = con.execute("SELECT COUNT(*) FROM address_exception_queue WHERE status='pending'")
        pending = cur.fetchone()[0]
        cur = con.execute("SELECT COUNT(*) FROM address_corrections")
        corr = cur.fetchone()[0]
        con.close()
    except Exception:
        pending, corr = 0, 0
    return {"pending": pending, "corrections": corr}

@router.post("/resolve")
async def resolve_correction(payload: ResolveIn):
    """Löst einen Queue-Eintrag auf."""
    # Serverseitige Validierung: lat/lon Bereichsgrenzen
    if payload.lat < -90 or payload.lat > 90:
        raise HTTPException(
            status_code=400,
            detail=f"Latitude muss zwischen -90 und 90 liegen (aktuell: {payload.lat})"
        )
    if payload.lon < -180 or payload.lon > 180:
        raise HTTPException(
            status_code=400,
            detail=f"Longitude muss zwischen -180 und 180 liegen (aktuell: {payload.lon})"
        )
    
    try:
        store.resolve(
            payload.key,
            payload.lat,
            payload.lon,
            street_canonical=payload.street,
            source=payload.source,
            confidence=payload.confidence
        )
        return {"ok": True}
    except KeyError as ex:
        raise HTTPException(status_code=404, detail=str(ex))
    except Exception as ex:
        raise HTTPException(status_code=400, detail=str(ex))

@router.get("/export")
async def export_csv():
    """Exportiert Korrekturen als CSV."""
    tmp_dir = Path(tempfile.gettempdir())
    tmp = tmp_dir / "address_corrections_export.csv"
    try:
        store.export_csv(tmp)
        data = tmp.read_bytes()
    finally:
        try:
            tmp.unlink()
        except Exception:
            pass
    return StreamingResponse(
        iter([data]),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=address_corrections.csv"}
    )

# API-kompatible Aliase für Frontend (Frontend ruft /api/... auf)
@router.get("/api/pending")
async def api_pending(limit: int = 100):
    """Listet ausstehende Korrekturen (API-kompatibler Pfad für Frontend)."""
    return await get_pending(limit=limit)

@router.get("/api/stats")
async def api_stats():
    """Gibt Statistiken zurück (API-kompatibler Pfad für Frontend)."""
    return await get_stats()

@router.post("/api/resolve")
async def api_resolve(payload: ResolveIn):
    """Löst einen Queue-Eintrag auf (API-kompatibler Pfad für Frontend)."""
    return await resolve_correction(payload)

@router.get("/api/export")
async def api_export():
    """Exportiert Korrekturen als CSV (API-kompatibler Pfad für Frontend)."""
    return await export_csv()

