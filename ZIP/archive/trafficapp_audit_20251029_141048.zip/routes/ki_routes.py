# -*- coding: utf-8 -*-
"""
KI-Routenberechnung API für Multi Tour Generator
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import logging
from services.vrp_clustering import cluster_and_route_tours, VRPClusteringService

router = APIRouter(prefix="/api/ki", tags=["KI-Routenberechnung"])

class CustomerStop(BaseModel):
    """Kundenstopp-Modell"""
    id: Optional[str] = None
    customer_number: Optional[str] = None
    name: str
    street: str
    postal_code: str
    city: str
    lat: float
    lon: float
    bar_flag: Optional[bool] = False

class DepotLocation(BaseModel):
    """Depot-Koordinaten"""
    lat: float
    lon: float

class KIRequest(BaseModel):
    """KI-Routenberechnung Request"""
    customers: List[CustomerStop]
    depot: DepotLocation
    tour_time: Optional[str] = None  # z.B. "07:00 Uhr"

class KIResponse(BaseModel):
    """KI-Routenberechnung Response"""
    success: bool
    message: str
    tours: List[List[Dict[str, Any]]]
    stats: Dict[str, Any]
    duplicates_removed: int
    processing_time: float

@router.post("/calculate-routes", response_model=KIResponse)
async def calculate_ki_routes(request: KIRequest):
    """
    Berechnet KI-optimierte Routen mit VRP-Clustering
    
    Args:
        request: KIRequest mit Kundenstopps und Depot
        
    Returns:
        KIResponse mit optimierten Touren
    """
    import time
    start_time = time.time()
    
    try:
        logging.info(f"KI-Routenberechnung gestartet für {len(request.customers)} Kunden")
        
        # Debug: Validiere Request-Daten
        logging.info(f"Request-Depot: {request.depot}")
        logging.info(f"Erste 3 Kunden: {[c.name for c in request.customers[:3]]}")
        
        # Konvertiere Pydantic-Modelle zu Dictionaries
        customer_dicts = []
        for customer in request.customers:
            customer_dict = {
                "id": customer.id,
                "customer_number": customer.customer_number,
                "name": customer.name,
                "street": customer.street,
                "postal_code": customer.postal_code,
                "city": customer.city,
                "lat": float(customer.lat),  # Explizite Konvertierung zu float
                "lon": float(customer.lon),  # Explizite Konvertierung zu float
                "bar_flag": customer.bar_flag
            }
            customer_dicts.append(customer_dict)
        
        depot_dict = {
            "lat": float(request.depot.lat),  # Explizite Konvertierung zu float
            "lon": float(request.depot.lon)  # Explizite Konvertierung zu float
        }
        
        # Zähle Duplikate vor Deduplizierung
        original_count = len(customer_dicts)
        
        # Führe VRP-Clustering durch
        logging.info(f"Starte VRP-Clustering mit {len(customer_dicts)} Kunden")
        try:
            # Debug: Zeige erste 3 Kunden
            logging.info(f"Erste 3 Kunden: {[c['name'] for c in customer_dicts[:3]]}")
            
            tours = cluster_and_route_tours(customer_dicts, depot_dict)
            logging.info(f"VRP-Clustering abgeschlossen: {len(tours)} Touren")
            
            # Debug: Zeige Tour-Größen
            for i, tour in enumerate(tours):
                logging.info(f"Tour {i+1}: {len(tour)} Kunden")
                
        except Exception as e:
            logging.error(f"VRP-Clustering Fehler: {e}")
            import traceback
            logging.error(f"Traceback: {traceback.format_exc()}")
            tours = []
        
        # Zähle Duplikate nach Deduplizierung (temporär deaktiviert)
        # deduplicated_count = sum(len(tour) for tour in tours)
        # duplicates_removed = original_count - deduplicated_count
        duplicates_removed = 0  # Temporär deaktiviert
        
        # Berechne Statistiken
        vrp_service = VRPClusteringService()
        stats = vrp_service.get_clustering_stats(tours, depot_dict)
        
        processing_time = time.time() - start_time
        
        logging.info(f"KI-Routenberechnung abgeschlossen: {len(tours)} Touren, "
                   f"{duplicates_removed} Duplikate entfernt, "
                   f"{processing_time:.2f}s")
        
        return KIResponse(
            success=True,
            message=f"KI-Routenberechnung erfolgreich! {len(tours)} Touren erstellt.",
            tours=tours,
            stats=stats,
            duplicates_removed=duplicates_removed,
            processing_time=processing_time
        )
        
    except Exception as e:
        processing_time = time.time() - start_time
        logging.error(f"Fehler bei KI-Routenberechnung: {e}")
        import traceback
        logging.error(f"Traceback: {traceback.format_exc()}")
        
        return KIResponse(
            success=False,
            message=f"Fehler bei KI-Routenberechnung: {str(e)}",
            tours=[],
            stats={},
            duplicates_removed=0,
            processing_time=processing_time
        )

@router.get("/status")
async def get_ki_status():
    """Gibt den Status der KI-Routenberechnung zurück"""
    try:
        # Teste ob VRP-Service verfügbar ist
        test_stops = [{"lat": 51.05, "lon": 13.74, "name": "Test"}]
        test_depot = {"lat": 51.05, "lon": 13.74}
        
        # Schneller Test
        deduplicated = vrp_service.deduplicate_customers(test_stops)
        
        return {
            "available": True,
            "service": "VRP-Clustering",
            "features": [
                "Duplikat-Deduplizierung",
                "K-Means-Clustering", 
                "Nearest-Neighbor-Routing",
                "Zeitrestriktionen (50-70 Min)",
                "Servicezeit-Berechnung (2 Min/Kunde)"
            ],
            "status": "online"
        }
        
    except Exception as e:
        return {
            "available": False,
            "service": "VRP-Clustering",
            "error": str(e),
            "status": "offline"
        }
