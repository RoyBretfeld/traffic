#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BAR-Kunden Analyse ohne Emojis
"""
import sys
sys.path.append('.')

def analyze_bar_customers():
    """Analysiere BAR-Kunden in der aktuellen CSV-Datei"""
    try:
        from backend.parsers.tour_plan_parser import parse_tour_plan_to_dict
        
        # Analysiere die aktuelle CSV-Datei
        csv_file = 'tourplaene/Tourenplan 30.09.2025.csv'
        tour_data = parse_tour_plan_to_dict(csv_file)
        
        # Finde BAR-Kunden
        bar_customers = []
        for customer in tour_data.get('customers', []):
            if customer.get('bar_flag', False):
                bar_customers.append({
                    'name': customer.get('name', ''),
                    'street': customer.get('street', ''),
                    'postal_code': customer.get('postal_code', ''),
                    'city': customer.get('city', ''),
                    'customer_number': customer.get('customer_number', '')
                })
        
        print(f'BAR-Kunden gefunden: {len(bar_customers)}')
        print('=' * 50)
        
        for i, customer in enumerate(bar_customers, 1):
            print(f'{i}. {customer["name"]} (KdNr: {customer["customer_number"]})')
            print(f'   Adresse: "{customer["street"]}"')
            print(f'   PLZ: "{customer["postal_code"]}"')
            print(f'   Stadt: "{customer["city"]}"')
            print()
            
        # Prüfe auf unvollständige Adressen
        incomplete = []
        for customer in bar_customers:
            if (not customer['street'] or customer['street'].lower() in ['nan', ''] or 
                not customer['postal_code'] or customer['postal_code'].lower() in ['nan', ''] or
                not customer['city'] or customer['city'].lower() in ['nan', '']):
                incomplete.append(customer)
        
        if incomplete:
            print(f'WARNUNG: {len(incomplete)} BAR-Kunden mit unvollständigen Adressen!')
            for customer in incomplete:
                print(f'  - {customer["name"]}: Adresse unvollständig')
        else:
            print('OK: Alle BAR-Kunden haben vollständige Adressen')
            
    except Exception as e:
        print(f'Fehler: {e}')
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    analyze_bar_customers()
