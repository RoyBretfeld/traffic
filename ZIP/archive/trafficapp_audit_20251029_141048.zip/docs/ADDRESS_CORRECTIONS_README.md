# Adress-Korrektur-Workflow

## Übersicht

Das Adress-Korrektur-System ermöglicht die persistente Speicherung manueller Adress-Korrekturen, die automatisch bei zukünftigen CSV-Imports verwendet werden. Fehlgeschlagene Geocodierungen landen automatisch in einer Warteschlange zur manuellen Bearbeitung.

## Features

- **Automatische Erkennung**: Korrekturen werden bei zukünftigen Imports automatisch verwendet
- **Queue-Management**: Fehlgeschlagene Adressen werden in `address_exception_queue` gespeichert
- **CSV-Import/Export**: Einfache Wartung über CSV-Dateien
- **CLI-Tool**: Manuelle Korrekturen über Kommandozeile

## Datenbank

Die Datenbank wird automatisch unter `data/address_corrections.sqlite3` erstellt. Der Pfad kann über die Umgebungsvariable `ADDRESS_CORRECTIONS_DB` konfiguriert werden.

### Tabellen

- **`address_corrections`**: Enthält dauerhaft gespeicherte Korrekturen mit Koordinaten
- **`address_exception_queue`**: Warteschlange für fehlgeschlagene Adressen (Status: `pending`, `resolved`, `ignored`)

## Verwendung

### CLI-Tool

#### Ausstehende Korrekturen auflisten

```bash
python tools/corrections_cli.py data/address_corrections.sqlite3 list
```

#### Eintrag korrigieren

```bash
python tools/corrections_cli.py data/address_corrections.sqlite3 resolve <key> <lat> <lon> [--street "Korrigierte Straße"]
```

Der `key` kann aus der `list`-Ausgabe kopiert werden.

Beispiel:
```bash
python tools/corrections_cli.py data/address_corrections.sqlite3 resolve "mügelnitzer str. 10|01814|bad schandau|DE" 50.9197 14.1533
```

#### CSV exportieren

```bash
python tools/corrections_cli.py data/address_corrections.sqlite3 export corrections.csv
```

#### CSV importieren

```bash
python tools/corrections_cli.py data/address_corrections.sqlite3 import corrections.csv
```

## Integration

Das System ist bereits in folgende Komponenten integriert:

1. **`services/geocode_fill.py`**: Prüft Korrekturtabelle vor jedem Geocoding-Versuch
2. **`backend/services/csv_bulk_processor.py`**: Nutzt Korrekturtabelle im Bulk-Processing

Die Integration erfolgt automatisch - keine manuelle Konfiguration erforderlich.

## Workflow

1. **Automatisch bei CSV-Import**:
   - Adresse wird geocodiert
   - Bei Misserfolg: Eintrag in `address_exception_queue` (Status: `pending`)

2. **Manuelle Korrektur**:
   - Liste ausstehende Korrekturen: `python tools/corrections_cli.py ... list`
   - Korrigiere Eintrag: `python tools/corrections_cli.py ... resolve <key> <lat> <lon>`
   - Eintrag wird automatisch aus Queue entfernt und in Korrekturtabelle gespeichert

3. **Automatische Erkennung bei nächstem Import**:
   - Korrektur wird automatisch erkannt und verwendet
   - Kein erneuter Geocoding-Versuch nötig

## Key-Format

Adress-Keys haben das Format: `norm(street)|postal_code|city|country`

Beispiele:
- `hauptstraße 1|01067|dresden|DE`
- `mügelnitzer str. 10|01814|bad schandau|DE`

Die Straße wird automatisch normalisiert (z.B. "Str." → "straße").

## Tests

Führe den Integrationstest aus:

```bash
python tests/test_address_corrections_flow.py
```

Der Test zeigt den kompletten Flow von fehlgeschlagener Geocodierung über manuelle Korrektur bis zur automatischen Erkennung.

## Technische Details

### Adress-Komponenten-Extraktion

Der Geocoder kann sowohl mit vollständigen Adress-Strings (`"Straße, PLZ Stadt"`) als auch mit einzelnen Komponenten (`street`, `postal_code`, `city`) arbeiten.

### Fallback-Verhalten

- Falls Korrekturtabelle keinen Treffer liefert → Normaler Geocoder wird verwendet
- Falls auch Geocoder fehlschlägt → Eintrag in Queue
- Bei Fehler in Korrekturtabelle-Logik → Normales Geocoding wird fortgesetzt (graceful degradation)

### Datenbank-Initialisierung

Die Datenbank wird automatisch beim ersten Zugriff initialisiert (Schema aus `db/migrations/020_address_corrections.sql`).

