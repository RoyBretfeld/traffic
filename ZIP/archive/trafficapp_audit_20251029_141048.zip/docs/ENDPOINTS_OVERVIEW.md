# Endpunkte-Übersicht - Was läuft wo?

## 🚀 Haupt-Server

### Start
```bash
python start_server.py
# Oder:
uvicorn backend.app:app --reload --port 8111
```

### Base URL
```
http://localhost:8111
```

---

## 📍 Verfügbare Endpunkte

### Frontend & Basis

| Endpunkt | Beschreibung | Status |
|----------|--------------|--------|
| `GET /` | Frontend-Hauptseite | ✅ Aktiv |
| `GET /ui/tourplan-management` | Tourplan Management UI | ✅ Aktiv |
| `GET /docs` | FastAPI Swagger UI | ✅ Aktiv |
| `GET /redoc` | FastAPI ReDoc | ✅ Aktiv |

### API - Tourplan

| Endpunkt | Route Prefix | Status |
|----------|--------------|--------|
| `POST /tourplan/match` | Tourplan-Parsing & Matching | ✅ Aktiv |
| `POST /tourplan/geofill` | Geocoding für fehlende Adressen | ✅ Aktiv |
| `GET /tourplan/list` | Liste aller Tourenpläne | ✅ Aktiv |
| `GET /tourplan/status` | Status eines Tourenplans | ✅ Aktiv |
| `POST /tourplan/suggest` | Vorschläge für Tourenzuordnung | ✅ Aktiv |
| `POST /tourplan/accept` | Tour zuweisen | ✅ Aktiv |

### API - Bulk Processing

| Endpunkt | Beschreibung | Status |
|----------|--------------|--------|
| `POST /tourplan/bulk/analysis` | Bulk-Analyse | ✅ Aktiv |
| `POST /tourplan/bulk/process` | Bulk-Verarbeitung | ✅ Aktiv |
| `POST /upload/csv` | CSV-Upload | ✅ Aktiv |

### API - Geocoding & Manual

| Endpunkt | Beschreibung | Status |
|----------|--------------|--------|
| `POST /tourplan/manual-geo` | Manuelle Geocoding-Zuweisung | ✅ Aktiv |
| `GET /manual/list` | Manual-Queue Liste | ✅ Aktiv |
| `POST /manual/resolve` | Manual-Queue auflösen | ✅ Aktiv |

### API - Auditing & Debug

| Endpunkt | Beschreibung | Status |
|----------|--------------|--------|
| `GET /audit/geo` | Geocoding-Audit | ✅ Aktiv |
| `GET /audit/geocoding` | Geocoding-Status | ✅ Aktiv |
| `GET /audit/status` | System-Status | ✅ Aktiv |
| `GET /debug/geo` | Geocoding-Debug | ✅ Aktiv |

### API - Health & Status

| Endpunkt | Beschreibung | Status |
|----------|--------------|--------|
| `GET /health` | Health Check | ✅ Aktiv |
| `GET /api/status` | Allgemeiner System-Status | ✅ Aktiv |
| `GET /api/llm/status` | LLM-Status | ✅ Aktiv |

### API - KI-Routen

| Endpunkt | Beschreibung | Status |
|----------|--------------|--------|
| `POST /calculate-routes` | KI-Routenberechnung | ✅ Aktiv |

### API - Monitoring (Optional)

| Endpunkt | Beschreibung | Status | Voraussetzung |
|----------|--------------|--------|---------------|
| `GET /metrics` | Prometheus Metriken | ⚠️ Optional | `prometheus-client` installiert |

**Prüfen ob aktiv:**
```bash
curl http://localhost:8111/metrics
```

Falls `prometheus-client` nicht installiert ist, läuft die App normal, nur `/metrics` ist nicht verfügbar.

### API - Address Admin (Optional)

| Endpunkt | Beschreibung | Status | Integration |
|----------|--------------|--------|-------------|
| `GET /admin/address/` | Admin-Web-Interface | ⚠️ Optional | Noch nicht in `app.py` |
| `GET /admin/address/pending` | Liste ausstehender Korrekturen | ⚠️ Optional | Noch nicht in `app.py` |
| `GET /admin/address/stats` | Statistiken | ⚠️ Optional | Noch nicht in `app.py` |
| `POST /admin/address/resolve` | Korrektur speichern | ⚠️ Optional | Noch nicht in `app.py` |
| `GET /admin/address/export` | CSV-Export | ⚠️ Optional | Noch nicht in `app.py` |

**Standalone verfügbar:**
```bash
uvicorn admin.address_admin_app_compat:app --reload --port 8000
# → http://localhost:8000
```

**Integration in Haupt-App:**
In `backend/app.py` hinzufügen:
```python
from routes.address_admin import router as address_admin_router
app.include_router(address_admin_router)
```

---

## ✅ Checkliste: Was funktioniert?

### Core-Funktionalität
- ✅ Frontend-UI (`/` und `/ui/tourplan-management`)
- ✅ Tourplan-Parsing (`/tourplan/match`)
- ✅ Geocoding (`/tourplan/geofill`)
- ✅ Tour-Verwaltung (list, status, suggest, accept)
- ✅ CSV-Upload (`/upload/csv`)
- ✅ Bulk-Processing
- ✅ Manual-Queue
- ✅ Health Checks
- ✅ KI-Routenberechnung

### Optional (benötigt Installation)
- ⚠️ Monitoring-Metriken (`/metrics`) - benötigt `prometheus-client`
  ```bash
  pip install prometheus-client
  ```

- ⚠️ Address-Admin Interface (`/admin/address/`) - optional integriert
  - **Standalone:** Funktioniert sofort auf Port 8000
  - **Integriert:** Benötigt zusätzlichen Import in `app.py`

---

## 🔧 Probleme beheben

### Metriken-Endpoint funktioniert nicht

**Problem:** `GET /metrics` gibt 404 oder Fehler

**Lösung:**
```bash
pip install prometheus-client
# Server neu starten
```

### Address-Admin nicht sichtbar

**Problem:** `/admin/address/` gibt 404

**Lösung 1 - Standalone:**
```bash
uvicorn admin.address_admin_app_compat:app --reload --port 8000
```

**Lösung 2 - Integrieren:**
```python
# In backend/app.py bei den anderen Imports (Zeile ~37)
from routes.address_admin import router as address_admin_router

# In create_app() bei den anderen app.include_router() (nach Zeile 146)
app.include_router(address_admin_router)
```

### Import-Fehler bei Start

**Problem:** Fehler beim Starten des Servers

**Lösung:**
```bash
# Prüfe ob alle Dependencies installiert sind
pip install fastapi uvicorn pydantic

# Optional (für Monitoring)
pip install prometheus-client
```

---

## 📊 Zusammenfassung

**Garantiert aktiv:**
- ✅ Alle Core-API-Endpunkte
- ✅ Frontend
- ✅ Tourplan-Verwaltung
- ✅ Geocoding
- ✅ Health Checks

**Optional (installierbar):**
- ⚠️ Monitoring (`/metrics`) - `pip install prometheus-client`
- ⚠️ Address-Admin (Standalone oder integriert)

**App läuft auch ohne optionale Features!** 🎉

