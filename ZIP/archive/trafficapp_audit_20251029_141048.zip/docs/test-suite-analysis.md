# Testsuite-Struktur Analyse

**Datum:** 2025-01-XX  
**Status:** In Bearbeitung

## Übersicht

- **Anzahl Test-Dateien:** ~97 Python-Dateien im `tests/` Verzeichnis
- **Test-Funktionen:** ~277 Test-Funktionen/Methoden gefunden
- **Framework:** pytest (konfiguriert in `pyproject.toml`)
- **Aktueller Test-Runner:** `run_tests.ps1` (PowerShell)

## Test-Kategorien

### 1. Unit Tests

#### Normalisierung & Adress-Erkennung
- `test_normalize_address.py` - Zentrale Adress-Normalisierung
- `test_encoding_fixes.py` - Encoding-Korrekturen
- `test_encoding_unification.py` - Encoding-Vereinheitlichung
- `test_mojibake_direct.py` - Mojibake-Fixes

#### Geocoding
- `test_geocode_fill.py` - Geocoding-Service
- `test_geocode_fill_simple.py` - Vereinfachte Geocoding-Tests
- `test_geocode_fill_sync.py` - Synchrone Geocoding-Tests
- `test_geocoding_quick.py` - Schnelle Geocoding-Tests
- `test_geocoding_rate.py` - Rate-Limiting
- `test_geocoder_retry_after.py` - Retry-Logik

#### Repositories
- `test_geo_repo.py` - Geo-Repository
- `test_geo_repo_bulk_in_clause.py` - Bulk-Operationen
- `test_geo_bulk_get_chunking.py` - Chunking-Logik
- `test_geo_unique_index.py` - Unique-Index-Tests
- `test_geocache_get.py` - Cache-Zugriff

#### Synonym-System
- `test_synonym_shortcircuit.py` - Synonym-Kurzschluss-Logik

### 2. Integration Tests

#### Pipeline & Workflow
- `test_pipeline_smoke.py` - Smoke-Tests für Pipeline
- `test_tourplan_match.py` - Tourplan-Matching
- `test_tourplan_match_simple.py` - Vereinfachte Tourplan-Tests
- `test_csv_bulk.py` - CSV-Bulk-Verarbeitung

#### API-Tests
- `test_api_health.py` - Health-Check
- `test_api_summary.py` - API-Zusammenfassung
- `test_status_api.py` - Status-API
- `test_status_api_simple.py` - Vereinfachte Status-API
- `test_status_api_debug.py` - Debug-Status-API
- `test_failcache_api.py` - Fail-Cache-API
- `test_audit_geo_api.py` - Geo-Audit-API

### 3. E2E Tests

- `test_upload_csv.py` - CSV-Upload-Integration
- `test_match_enforce_and_manual.py` - Match-Enforcement
- `test_manual_queue_and_export.py` - Manual-Queue
- `test_persist_and_flags.py` - Persist-Logik

## Aktuelle Test-Organisation

### Probleme

1. **Keine zentrale Struktur:** Tests sind flach im `tests/` Verzeichnis
2. **Keine Kategorisierung:** Unit/Integration/E2E nicht getrennt
3. **Fehlende Fixtures:** Keine `conftest.py` für gemeinsame Fixtures
4. **Duplikate:** Ähnliche Tests in verschiedenen Dateien (z.B. `test_geocode_fill.py`, `test_geocode_fill_simple.py`, `test_geocode_fill_sync.py`)
5. **Standalone-Scripts:** Viele Tests sind eigenständige Scripts statt pytest-Tests

### Bestehende Struktur-Highlights

- ✅ pytest in `pyproject.toml` konfiguriert
- ✅ Marker-System vorhanden (`integration` Marker)
- ✅ Python-Path konfiguriert
- ✅ Einige Tests nutzen pytest bereits korrekt

## Module ohne Tests (Vermutung)

- ❓ `backend/services/address_corrections.py` (neues Modul, noch nicht implementiert)
- ❓ `backend/services/geocoder_correction_aware.py` (neues Modul, noch nicht implementiert)
- ❓ `services/ai_code_monitor.py` (neues Modul, noch nicht implementiert)
- ❓ `tools/corrections_cli.py` (neues Modul, noch nicht implementiert)

## Nächste Schritte

1. Coverage-Analyse durchführen (Phase 1.2)
2. Fehlende Tests identifizieren (Phase 1.3)
3. Test-Suites organisieren (Phase 2.1)

