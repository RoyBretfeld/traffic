# Integration des Address-Admin Routers

## Option 1: Automatische Integration

Füge diese Zeile in `backend/app.py` zu den Imports hinzu (nach Zeile 37):

```python
from routes.address_admin import router as address_admin_router
```

Und dann in der `create_app()` Funktion zu den `app.include_router()` Aufrufen hinzufügen (nach Zeile 146):

```python
app.include_router(address_admin_router)  # Adress-Admin Interface
```

## Option 2: Standalone starten

Die Admin-App kann auch standalone gestartet werden:

```bash
uvicorn admin.address_admin_app_compat:app --reload --port 8000
```

Dann unter http://localhost:8000 verfügbar.

## Option 3: Router manuell einbinden

Falls du nur bestimmte Endpunkte brauchst, kannst du einzelne Routen importieren:

```python
from routes.address_admin import router

# Optional: Prefix ändern
router.prefix = "/custom/path"

app.include_router(router)
```

## Verfügbare Endpunkte (nach Integration)

Nach Integration in `backend/app.py`:

- **Web-Interface**: http://localhost:8111/admin/address/
- **API Pending**: http://localhost:8111/admin/address/pending
- **API Stats**: http://localhost:8111/admin/address/stats
- **API Resolve**: POST http://localhost:8111/admin/address/resolve
- **API Export**: http://localhost:8111/admin/address/export

## Testen der Integration

```bash
# Server starten
python start_server.py --port 8111

# In Browser öffnen
http://localhost:8111/admin/address/

# API testen
curl http://localhost:8111/admin/address/api/stats
```

