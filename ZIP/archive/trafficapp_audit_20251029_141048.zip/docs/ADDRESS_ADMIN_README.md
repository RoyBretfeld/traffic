# Adress-Admin Web-Interface

## Übersicht

Web-basiertes Admin-Interface zur manuellen Pflege von Adress-Korrekturen. Bietet eine benutzerfreundliche Oberfläche für die Bearbeitung fehlgeschlagener Geocodierungen.

## Verfügbare Varianten

### 1. Standalone App (empfohlen für Entwicklung)

**Start:**
```bash
uvicorn admin.address_admin_app_compat:app --reload --port 8000
```

**Zugriff:**
- Web-Interface: http://localhost:8000
- API: http://localhost:8000/api/...

### 2. Integriert in bestehende App

Die Routen können in die bestehende FastAPI-App integriert werden:

```python
# In backend/app.py
from routes.address_admin import router as address_admin_router
app.include_router(address_admin_router)
```

**Zugriff:**
- Web-Interface: http://localhost:8111/admin/address/
- API: http://localhost:8111/admin/address/api/...

## Features

### Web-Interface

- **Liste ausstehender Korrekturen**: Zeigt alle "roten" Adressen aus der Queue
- **Filter**: Nach Stadt oder PLZ filtern
- **Koordinaten eingeben**: Direkt im Browser Lat/Lon eingeben
- **Straßenname korrigieren**: Optional bereinigten Straßennamen angeben
- **Speichern**: Ein Klick speichert die Korrektur und entfernt sie aus der Queue
- **CSV-Export**: Alle Korrekturen als CSV exportieren

### API-Endpunkte

#### GET `/api/ping`
Health-Check Endpunkt

#### GET `/api/pending?limit=100`
Listet ausstehende Korrekturen

#### GET `/api/stats`
Gibt Statistiken zurück:
```json
{
  "pending": 5,
  "corrections": 42
}
```

#### POST `/api/resolve`
Löst einen Queue-Eintrag auf:
```json
{
  "key": "hauptstraße 1|01067|dresden|DE",
  "lat": 51.05,
  "lon": 13.74,
  "street": "Hauptstraße 1",  // optional
  "source": "manual",
  "confidence": 1.0
}
```

#### GET `/api/export`
Exportiert alle Korrekturen als CSV-Datei

## Konfiguration

### Umgebungsvariablen

```bash
# Pfad zur SQLite-Datenbank
ADDR_DB_PATH=data/address_corrections.sqlite3
```

### Standard-Pfade

- **Datenbank**: `data/address_corrections.sqlite3`
- **Migration**: `db/migrations/020_address_corrections.sql`

## Verwendung

### 1. Ausstehende Korrekturen anzeigen

1. Öffne http://localhost:8000
2. Tabelle zeigt alle ausstehenden Korrekturen
3. Filter nach Stadt oder PLZ möglich

### 2. Korrektur erstellen

1. In der Tabelle bei einem Eintrag:
   - Lat (Breitengrad) eingeben (z.B. `51.05`)
   - Lon (Längengrad) eingeben (z.B. `13.74`)
   - Optional: Straßenname korrigieren
2. Auf "Speichern" klicken
3. Eintrag wird aus Queue entfernt und in Korrekturtabelle gespeichert

### 3. CSV exportieren

1. Auf "Korrekturen exportieren (CSV)" klicken
2. Datei wird heruntergeladen
3. Kann später über CLI wieder importiert werden

## Kompatibilität

- **Pydantic v1 oder v2**: Automatische Erkennung
- **FastAPI alt/neu**: Funktioniert mit beiden Versionen
- **Windows/Linux/Mac**: Alle Plattformen unterstützt

## Fehlerbehebung

### Store nicht gefunden

Wenn `AddressCorrectionStore` nicht importiert werden kann:

1. Prüfe dass `backend/services/address_corrections.py` existiert
2. Oder passe den Import-Pfad in der App an

### Migration nicht gefunden

Die App erstellt automatisch die Migration, falls sie fehlt:
- `db/migrations/020_address_corrections.sql`

### Datenbank-Pfad

Standard: `data/address_corrections.sqlite3`

Über Umgebungsvariable anpassbar:
```bash
export ADDR_DB_PATH=/path/to/custom.db
```

## Integration in bestehende App

Um die Admin-Routen in die bestehende App zu integrieren:

```python
# backend/app.py
from routes.address_admin import router as address_admin_router

def create_app():
    app = FastAPI(...)
    # ... andere Routen ...
    app.include_router(address_admin_router)
    return app
```

Dann unter `/admin/address/` erreichbar.

## Beispiel-Workflow

1. **CSV-Import**: Einige Adressen schlagen fehl → landen in Queue
2. **Admin-Interface öffnen**: http://localhost:8000
3. **Korrekturen prüfen**: Tabelle zeigt alle fehlgeschlagenen Adressen
4. **Koordinaten recherchieren**: z.B. über Google Maps
5. **Eingabe**: Lat/Lon im Interface eingeben
6. **Speichern**: Klick auf "Speichern"
7. **Resultat**: Beim nächsten Import wird Korrektur automatisch verwendet

## Technische Details

### Abhängigkeiten

- `fastapi`: Web-Framework
- `uvicorn`: ASGI-Server
- `pydantic`: Data Validation (v1 oder v2)

### Dateien

- `admin/address_admin_app_compat.py`: Standalone App
- `routes/address_admin.py`: Router für Integration
- Frontend: Eingebettetes HTML/JavaScript (keine externe Dependency)

