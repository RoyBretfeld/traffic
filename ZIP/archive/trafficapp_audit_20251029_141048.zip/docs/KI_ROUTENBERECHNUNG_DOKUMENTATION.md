# KI-Routenberechnung Dokumentation

## Übersicht

Die FAMO TrafficApp integriert eine fortschrittliche KI-basierte Routenberechnung mit VRP-Clustering (Vehicle Routing Problem) für optimale Tourenplanung.

## 🎯 Features

### ✅ Implementierte Funktionen

- **VRP-Clustering:** Cluster-First-Route-Second-Heuristik
- **Duplikat-Deduplizierung:** Automatische Entfernung mehrfacher Kundenanrufe
- **Zeitrestriktionen:** 50-70 Min Tourdauer, 2 Min Servicezeit pro Kunde
- **Himmelblauer Multi Tour Generator:** Benutzerfreundliche UI
- **Real-time Status:** Live-Updates während Berechnung
- **Detaillierte Statistiken:** Umfassende Tour-Analyse

### 🔧 Technische Details

- **Algorithmus:** K-Means + Nearest-Neighbor-Routing
- **Backend:** FastAPI mit Pydantic-Validierung
- **Frontend:** Bootstrap + JavaScript mit Loading-Animation
- **Datenformat:** JSON mit Koordinaten-Validierung

## 🚀 Verwendung

### 1. CSV-Upload
```bash
# CSV-Datei mit Touren hochladen
POST /api/upload/csv
```

### 2. KI-Routenberechnung starten
```javascript
// Frontend: Multi Tour Generator (KI) Button klicken
startKIRouteCalculation()
```

### 3. API-Aufruf
```bash
# Direkter API-Aufruf
POST /api/ki/calculate-routes
Content-Type: application/json

{
  "customers": [
    {
      "id": "K001",
      "customer_number": "12345",
      "name": "Kunde 1",
      "street": "Hauptstraße 1",
      "postal_code": "01067",
      "city": "Dresden",
      "lat": 51.05,
      "lon": 13.74,
      "bar_flag": false
    }
  ],
  "depot": {
    "lat": 51.050407,
    "lon": 13.737262
  },
  "tour_time": "KI-optimiert"
}
```

## 📊 API-Endpunkte

### `/api/ki/calculate-routes`
**POST** - Hauptendpunkt für KI-Routenberechnung

**Request Body:**
```json
{
  "customers": CustomerStop[],
  "depot": DepotLocation,
  "tour_time": string
}
```

**Response:**
```json
{
  "success": true,
  "message": "KI-Routenberechnung erfolgreich! 2 Touren erstellt.",
  "tours": [
    [
      {
        "id": "K001",
        "name": "Kunde 1",
        "lat": 51.05,
        "lon": 13.74,
        "street": "Hauptstraße 1",
        "postal_code": "01067",
        "city": "Dresden"
      }
    ]
  ],
  "stats": {
    "total_tours": 2,
    "total_customers": 10,
    "avg_customers_per_tour": 5.0,
    "total_work_time": 120.5,
    "tour_details": [
      {
        "total_duration": 65.2,
        "driving_time": 45.2,
        "service_time": 20.0,
        "is_valid": true,
        "violations": []
      }
    ]
  },
  "duplicates_removed": 3,
  "processing_time": 0.45
}
```

### `/api/ki/status`
**GET** - Status der KI-Routenberechnung

**Response:**
```json
{
  "available": true,
  "service": "VRP-Clustering",
  "features": [
    "Duplikat-Deduplizierung",
    "K-Means-Clustering",
    "Nearest-Neighbor-Routing",
    "Zeitrestriktionen (50-70 Min)",
    "Servicezeit-Berechnung (2 Min/Kunde)"
  ],
  "status": "online"
}
```

## 🧠 VRP-Clustering Algorithmus

### Cluster-First-Route-Second-Heuristik

1. **Duplikat-Deduplizierung**
   - Entfernt mehrfache Kundenanrufe
   - Priorität: ID → Kunden-Nummer → Adresse → Koordinaten

2. **K-Means-Clustering**
   - Gruppiert Kunden nach geografischer Nähe
   - Optimiert Cluster-Größe basierend auf Zeitrestriktionen

3. **Nearest-Neighbor-Routing**
   - Optimiert Route innerhalb jedes Clusters
   - Minimiert Gesamtfahrzeit

4. **Tour-Validierung**
   - Prüft Zeitrestriktionen (50-70 Min)
   - Berechnet Servicezeit (2 Min/Kunde)
   - Validiert Gesamteinsatzzeit (80 Min)

### Zeitrestriktionen

- **Minimale Tourdauer:** 50 Minuten
- **Maximale Tourdauer:** 70 Minuten
- **Servicezeit pro Kunde:** 2 Minuten
- **Maximale Gesamteinsatzzeit:** 80 Minuten

## 🎨 Frontend-Integration

### Himmelblauer Multi Tour Generator Button

```html
<button class="btn btn-primary w-100 mb-3" 
        onclick="startKIRouteCalculation()" 
        id="kiRouteButton" 
        style="background: linear-gradient(135deg, #87CEEB 0%, #4682B4 100%); 
                border: none; 
                box-shadow: 0 4px 15px rgba(135, 206, 235, 0.3);">
    <i class="fas fa-robot"></i> Multi Tour Generator (KI)
</button>
```

### Loading-Animation

```javascript
// Button deaktivieren und Status anzeigen
button.disabled = true;
button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> KI berechnet...';
status.style.display = 'block';
status.innerHTML = '<i class="fas fa-spinner fa-spin"></i> KI analysiert Kunden und berechnet optimale Routen...';
```

### Ergebnis-Display

```javascript
function displayKIResults(result) {
    const kiResults = document.createElement('div');
    kiResults.innerHTML = `
        <div class="card-header" style="background: linear-gradient(135deg, #87CEEB 0%, #4682B4 100%); color: white;">
            <h4><i class="fas fa-robot"></i> KI-Routenberechnung Ergebnisse</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h6><i class="fas fa-chart-bar"></i> Statistiken</h6>
                    <ul class="list-unstyled">
                        <li><strong>Touren:</strong> ${result.stats.total_tours || 0}</li>
                        <li><strong>Kunden:</strong> ${result.stats.total_customers || 0}</li>
                        <li><strong>Durchschnitt/Tour:</strong> ${(result.stats.avg_customers_per_tour || 0).toFixed(1)}</li>
                        <li><strong>Gesamtzeit:</strong> ${(result.stats.total_work_time || 0).toFixed(1)} Min</li>
                        <li><strong>Duplikate entfernt:</strong> ${result.duplicates_removed}</li>
                        <li><strong>Berechnungszeit:</strong> ${result.processing_time.toFixed(2)}s</li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <h6><i class="fas fa-route"></i> KI-Touren</h6>
                    <div id="kiToursList" class="list-group">
                        ${result.tours.map((tour, index) => `
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>Tour ${index + 1}</strong>
                                        <span class="badge bg-primary rounded-pill ms-2">${tour.length} Kunden</span>
                                    </div>
                                    <button class="btn btn-sm btn-outline-primary" onclick="showKITourDetails(${index})">
                                        <i class="fas fa-eye"></i> Details
                                    </button>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        </div>
    `;
}
```

## 🔧 Konfiguration

### Umgebungsvariablen

```bash
# KI-Konfiguration
LLM_MODEL=gpt-4o-mini
LLM_MAX_TOKENS=1000
LLM_TEMPERATURE=0.3

# VRP-Parameter
MAX_TOUR_DURATION=70
MIN_TOUR_DURATION=50
SERVICE_TIME_PER_CUSTOMER=2
MAX_TOTAL_WORK_TIME=80
```

### Depot-Koordinaten

```python
# Standard-Depot (Dresden Zentrum)
depot = {
    "lat": 51.050407,
    "lon": 13.737262
}
```

## 📈 Statistiken und Monitoring

### Tour-Statistiken

- **Gesamttouren:** Anzahl erstellter Touren
- **Gesamtkunden:** Anzahl verarbeiteter Kunden
- **Durchschnitt pro Tour:** Kunden pro Tour
- **Gesamtarbeitszeit:** Summe aller Tourzeiten
- **Duplikate entfernt:** Anzahl deduplizierter Kunden
- **Berechnungszeit:** API-Verarbeitungszeit

### Tour-Details

```json
{
  "total_duration": 65.2,
  "driving_time": 45.2,
  "service_time": 20.0,
  "is_valid": true,
  "violations": []
}
```

## 🐛 Fehlerbehandlung

### Häufige Probleme

1. **"Unprocessable Content" Fehler**
   - **Ursache:** Ungültige Koordinaten oder Datenstruktur
   - **Lösung:** Frontend-Validierung aktiviert

2. **Keine Touren erstellt**
   - **Ursache:** Zu strenge Zeitrestriktionen
   - **Lösung:** Spezialfall für wenige Kunden implementiert

3. **Duplikate entfernt alle Kunden**
   - **Ursache:** Zu aggressive Deduplizierung
   - **Lösung:** Temporär deaktiviert für Debugging

### Debug-Logging

```python
# Backend-Logging aktiviert
logging.info(f"Starte VRP-Clustering mit {len(customer_dicts)} Kunden")
logging.info(f"VRP-Clustering abgeschlossen: {len(tours)} Touren")
```

## 🔄 Synchronisation mit Cloud

### Cloud-Version Features

- **OpenAI GPT-4o-mini Integration**
- **Verschlüsselte API-Key-Verwaltung**
- **Erweiterte LLM-Optimierung**
- **Monitoring und Metriken**

### Lokale Implementierung

- **VRP-Clustering als Alternative**
- **Heuristische Optimierung**
- **Zeitrestriktionen-basierte Validierung**
- **Duplikat-Deduplizierung**

## 📚 Weiterführende Dokumentation

- [Clustering-KI.md](Clustering-KI.md) - Detaillierte Algorithmus-Beschreibung
- [FAMO_TrafficApp_MasterDoku.md](FAMO_TrafficApp_MasterDoku.md) - Gesamtarchitektur
- [STATUS_REPORT.md](../STATUS_REPORT.md) - Aktueller Projektstatus

## 🚀 Nächste Schritte

1. **Duplikat-Deduplizierung reaktivieren** (nach Debugging)
2. **Erweiterte Zeitrestriktionen** implementieren
3. **Cloud-Synchronisation** vervollständigen
4. **Performance-Optimierung** durchführen
5. **Benutzer-Tests** durchführen

---

**Erstellt:** 23.10.2025  
**Version:** 1.0  
**Status:** Implementiert und funktionsfähig ✅
