# Address-Admin Quick Start

## Schnellstart

### Option 1: Standalone (empfohlen für Tests)

```bash
# Server starten
uvicorn admin.address_admin_app_compat:app --reload --port 8000

# Browser öffnen
http://localhost:8000
```

### Option 2: In bestehende App integrieren

1. **Router in `backend/app.py` hinzufügen:**

```python
# Nach Zeile 37 (bei den anderen Imports)
from routes.address_admin import router as address_admin_router

# In create_app() nach Zeile 146
app.include_router(address_admin_router)
```

2. **Server starten:**

```bash
python start_server.py --port 8111
```

3. **Zugriff:**
   - Web-Interface: http://localhost:8111/admin/address/
   - API: http://localhost:8111/admin/address/api/...

## Verwendung

### 1. Ausstehende Korrekturen anzeigen

Die Tabelle zeigt alle Adressen, die beim Geocoding fehlgeschlagen sind.

### 2. Koordinaten eingeben

1. Für eine Adresse in der Tabelle:
   - **Lat** (Breitengrad) eingeben, z.B. `51.05`
   - **Lon** (Längengrad) eingeben, z.B. `13.74`
   - Optional: Straßenname korrigieren
2. Auf **"Speichern"** klicken
3. Adresse wird automatisch aus Queue entfernt

### 3. Export

- **"Korrekturen exportieren (CSV)"** klicken
- Datei kann später über CLI importiert werden

## Features

✅ **Filter**: Nach Stadt oder PLZ filtern  
✅ **Statistiken**: Zeigt Anzahl ausstehender Korrekturen  
✅ **Einfache Bedienung**: Direkt im Browser koordinaten eingeben  
✅ **Automatische Erkennung**: Korrekturen werden bei nächstem Import verwendet  

## API-Endpunkte

### GET `/api/pending?limit=100`
Listet ausstehende Korrekturen

### GET `/api/stats`
Gibt Statistiken zurück:
```json
{
  "pending": 5,
  "corrections": 42
}
```

### POST `/api/resolve`
Speichert eine Korrektur:
```json
{
  "key": "hauptstraße 1|01067|dresden|DE",
  "lat": 51.05,
  "lon": 13.74,
  "street": "Hauptstraße 1",
  "source": "manual",
  "confidence": 1.0
}
```

### GET `/api/export`
Exportiert alle Korrekturen als CSV

## Konfiguration

```bash
# Datenbank-Pfad anpassen
export ADDR_DB_PATH=data/custom_address_corrections.sqlite3
```

## Troubleshooting

### "AddressCorrectionStore nicht gefunden"

Prüfe dass `backend/services/address_corrections.py` existiert.

### "Migration nicht gefunden"

Die App erstellt die Migration automatisch falls sie fehlt in:
- `db/migrations/020_address_corrections.sql`

### Frontend zeigt keine Daten

1. Prüfe Browser-Konsole (F12) auf Fehler
2. Prüfe dass API-Endpunkte erreichbar sind: `/api/pending`
3. Prüfe dass Datenbank existiert: `data/address_corrections.sqlite3`

