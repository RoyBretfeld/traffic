# LLM Code Guard - Funktionsweise erklärt

## 🎯 Was macht der LLM Code Guard?

Der LLM Code Guard analysiert automatisch Code-Änderungen auf potenzielle Risiken und Probleme. Er funktioniert in **zwei Modi**:

1. **Regelbasiert** (immer aktiv, ohne API-Key)
2. **KI-gestützt** (zusätzlich, mit OpenAI API-Key)

## 🔄 So funktioniert es

### Schritt 1: Git-Diff analysieren

Der Guard holt sich die Änderungen zwischen zwei Git-Versionen:

```python
# Vergleich aktueller Branch vs. origin/main
git diff origin/main...HEAD
```

**Beispiel:**
- Du hast `routes/tourplan_match.py` geändert
- Guard erkennt: "Diese Datei wurde geändert"

### Schritt 2: Regelbasierte Prüfung (automatisch)

Der Guard prüft sofort mehrere Regeln:

#### ✅ Kritische Bereiche erkennen

```python
CRITICAL_PATHS = [
    r"^backend/parsers/",      # Parser sind kritisch
    r"^routes/tourplan_",      # Tour-APIs sind kritisch
    r"^backend/services/",    # Services sind kritisch
    r"^services/geocode",     # Geocoding ist kritisch
]
```

**Beispiel:** Wenn `routes/tourplan_match.py` geändert wurde:
```
⚠️ KRITISCH: 1 Datei(en) in kritischen Bereichen geändert:
   - routes/tourplan_match.py
```

#### ✅ Fehlende Tests prüfen

Der Guard prüft:
- Wurden Python-Dateien geändert?
- Gibt es dazu Test-Dateien?

**Beispiel:**
```
⚠️ WARNUNG: 3 Python-Datei(en) geändert ohne Tests:
   - routes/tourplan_match.py
   - services/geocode_fill.py
   - backend/app.py
```

#### ✅ Migration-Änderungen erkennen

```
ℹ️ INFO: 1 Migration(s) geändert - bitte prüfen
```

### Schritt 3: KI-Analyse (optional, mit API-Key)

Wenn `OPENAI_API_KEY` gesetzt ist, analysiert GPT-4o-mini den Code-Diff **semantisch**:

**Der KI prüft auf:**
- 🔴 **Breaking Changes**: API-Brüche, Signatur-Änderungen
- 🔴 **Fehlerbehandlung**: Fehlende Try-Catch, unhandled Exceptions
- 🟡 **Performance**: Potentielle Bottlenecks, N+1 Queries
- 🟡 **Tests**: Fehlende Tests für neue Funktionen
- 🟡 **Seiteneffekte**: Unerwartete State-Änderungen
- 🟢 **Sicherheit**: SQL-Injection, XSS, unvalidierte Inputs

**KI-Prompt Beispiel:**
```
Du bist Code-Reviewer für Python FastAPI-Anwendung.

Prüfe diese Änderungen:
- routes/tourplan_match.py: Neue Funktion parse_tour() hinzugefügt
- services/geocode_fill.py: Geocoding-Logik geändert

Worauf zu achten:
- Breaking Changes
- Fehlende Fehlerbehandlung
- Performance-Probleme
- Fehlende Tests
```

**KI-Antwort Beispiel:**
```
Priority: HIGH
- Neuer Endpunkt parse_tour() ohne Error-Handling → kann crashen bei invalid input

Priority: MEDIUM  
- Geocoding-Änderung könnte Cache invalidation benötigen

Priority: LOW
- Funktion könnte async sein für bessere Performance
```

### Schritt 4: Report generieren

Der Guard erstellt einen JSON-Report:

```json
{
  "changed_files": ["routes/tourplan_match.py", "services/geocode_fill.py"],
  "critical_files": ["routes/tourplan_match.py"],
  "rule_based_findings": [
    "⚠️ KRITISCH: 1 Datei(en) in kritischen Bereichen geändert",
    "⚠️ WARNUNG: 2 Python-Datei(en) geändert ohne Tests"
  ],
  "llm_analysis": "Priority: HIGH - Neuer Endpunkt ohne Error-Handling...",
  "has_critical_changes": true
}
```

### Schritt 5: Exit-Code für CI

- **Exit 0**: Alles OK (oder nur Warnungen)
- **Exit 1**: Kritische Änderungen erkannt → CI kann fehlschlagen

## 📋 Konkrete Beispiele

### Beispiel 1: Kritische Änderung ohne Tests

**Szenario:** Du änderst `backend/services/address_corrections.py`

**Output:**
```
📋 Analysiere 1 geänderte Datei(en)...

🔴 Kritische Bereiche: 1
   - backend/services/address_corrections.py

📋 Regelbasierte Findings:
   ⚠️ KRITISCH: 1 Datei(en) in kritischen Bereichen geändert:
      - backend/services/address_corrections.py
   ⚠️ WARNUNG: 1 Python-Datei(en) geändert ohne Tests:
      - backend/services/address_corrections.py

🤖 LLM-Analyse (wenn API-Key vorhanden):
   Priority: HIGH
   - upsert() Methode geändert ohne Validierung → könnte Daten korrumpieren
   
   Priority: MEDIUM
   - Fehlende Tests für neue Logik
   
   Priority: LOW
   - SQL-Query könnte prepared statements verwenden

⚠️ KRITISCH: Änderungen in kritischen Bereichen erkannt!
Exit code: 1
```

**Resultat:** CI schlägt fehl, Pull Request blockiert (wenn so konfiguriert)

### Beispiel 2: Unkritische Änderung

**Szenario:** Du änderst nur `docs/README.md`

**Output:**
```
📋 Analysiere 1 geänderte Datei(en)...

ℹ️ Keine kritischen Bereiche betroffen
Exit code: 0
```

**Resultat:** CI läuft durch, alles OK

### Beispiel 3: Mit KI-Analyse (mit API-Key)

**Szenario:** Du fügst neue Funktion hinzu ohne Error-Handling

**KI findet:**
```
Priority: HIGH
- Neue Funktion geocode_batch() ohne Rate-Limiting → kann API-Limits überschreiten
- Fehlende Try-Except um externe API-Calls

Priority: MEDIUM
- Keine Validierung der Input-Parameter (addresses Liste könnte leer/None sein)

Priority: LOW
- Funktion könnte async sein für bessere Performance bei Batch-Operationen
- Logging fehlt für Debugging
```

## 🔧 Verwendung

### Lokal testen

```bash
# 1. Ohne API-Key (nur regelbasiert)
python tools/llm_code_guard.py

# 2. Mit API-Key (mit KI-Analyse)
export OPENAI_API_KEY=sk-...
python tools/llm_code_guard.py
```

### In GitHub Actions (automatisch)

Bei jedem Pull Request:
1. ✅ Ruff (Linting)
2. ✅ MyPy (Type Checking)
3. ✅ Pytest (Tests)
4. ✅ LLM Guard (Code-Analyse)

**Report erscheint in:**
- GitHub Actions Summary
- Als Artifact: `llm-guard-report`
- In Pull Request Comments (wenn konfiguriert)

### Als Pre-Commit Hook

```bash
# Installieren
pip install pre-commit
pre-commit install

# Automatisch bei jedem Commit (außer LLM-Guard - zu langsam)
# LLM-Guard kann manuell ausgeführt werden:
pre-commit run llm-guard --all-files
```

## 🎛️ Konfiguration

### Kritische Pfade anpassen

Edit `tools/llm_code_guard.py`:

```python
CRITICAL_PATHS = [
    r"^backend/parsers/",
    r"^routes/tourplan_",
    # Neuen Pfad hinzufügen:
    r"^services/my_new_service/",
]
```

### KI-Prompt anpassen

```python
PROMPT_SYSTEM = """Dein eigener Prompt..."""
```

### Git-Base ändern

```bash
export GIT_BASE=origin/develop  # Statt origin/main
python tools/llm_code_guard.py
```

## 💡 Tipps & Best Practices

### ✅ Was funktioniert gut

1. **Regelbasiert ist schnell** - läuft ohne API-Calls in < 1 Sekunde
2. **KI findet semantische Probleme** - erkennt Dinge, die Regeln nicht sehen
3. **GitHub Integration** - automatisch bei jedem PR
4. **Exit Codes** - CI kann darauf reagieren

### ⚠️ Was zu beachten ist

1. **KI-Analyse kostet** - ~$0.01 pro Analyse (GPT-4o-mini)
2. **KI ist langsam** - dauert 3-10 Sekunden
3. **False Positives möglich** - KI findet manchmal Probleme, die keine sind
4. **Nur bei Änderungen** - funktioniert nur in Git-Repository

### 🔍 False Positives reduzieren

Wenn KI zu viele False Positives findet:

1. **Prompt anpassen** - spezifischer werden
2. **Nur bei kritischen Änderungen** - KI-Analyse nur wenn `has_critical_changes == true`
3. **Manuelle Review** - KI-Ergebnisse sind als **Hilfe** gedacht, nicht als finales Urteil

## 📊 Vergleich: Regelbasiert vs. KI

| Aspekt | Regelbasiert | KI-gestützt |
|--------|--------------|-------------|
| **Geschwindigkeit** | < 1 Sekunde | 3-10 Sekunden |
| **Kosten** | Kostenlos | ~$0.01 pro Analyse |
| **Kritische Bereiche** | ✅ Ja | ✅ Ja |
| **Fehlende Tests** | ✅ Ja | ✅ Ja |
| **Breaking Changes** | ❌ Nein | ✅ Ja |
| **Performance-Probleme** | ❌ Nein | ✅ Ja |
| **Security Issues** | ❌ Nein | ✅ Ja |
| **Semantische Analyse** | ❌ Nein | ✅ Ja |

## 🎯 Zusammenfassung

**LLM Code Guard = Zwei-Stufen-Defense:**

1. **Stufe 1 (Regelbasiert):**
   - Schnell, kostenlos
   - Findet: Kritische Bereiche, fehlende Tests
   - Läuft immer

2. **Stufe 2 (KI-gestützt):**
   - Langsamer, kostet Geld
   - Findet: Breaking Changes, Performance, Security, semantische Probleme
   - Läuft nur mit API-Key

**Resultat:** Du bekommst **schnelle** Regel-basierte Checks **plus** **intelligente** KI-Analyse für komplexe Probleme.

**Für dein Projekt besonders nützlich:**
- ✅ Erkennt Änderungen an kritischen Parsern
- ✅ Warnt bei fehlenden Tests
- ✅ Findet API-Brüche durch KI-Analyse
- ✅ Integriert in GitHub Actions (automatisch bei PRs)

