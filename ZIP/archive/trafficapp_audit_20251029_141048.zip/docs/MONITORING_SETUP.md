# Monitoring & Code-Health Setup

## Übersicht

Vollständiges Setup für:
- **Grafana Monitoring**: Live-Metriken und Dashboards
- **LLM Code Guard**: KI-gestützte Code-Überwachung

## A) Grafana-Monitoring

### Installation

```bash
# Dependencies
pip install prometheus-client

# Docker Compose starten
cd monitoring
docker compose up -d
```

### Zugriff

- **Grafana**: http://localhost:3000 (admin/admin)
- **Prometheus**: http://localhost:9090
- **Metrics Endpoint**: http://localhost:8111/metrics

### Dashboard importieren

1. Grafana öffnen
2. Dashboards → Import
3. `monitoring/dashboards/trafficapp.json` hochladen

### Metriken im Code

Die Metriken sind bereits integriert in:
- `routes/tourplan_match.py` - Parse-Metriken (OK/WARN/BAD)
- `services/geocode_fill.py` - Geocoding-Metriken
- `backend/app.py` - Metrics-Endpunkt und periodische Updates

**Metriken werden automatisch alle 60 Sekunden aktualisiert.**

## B) LLM Code Guard

### Lokale Nutzung

```bash
# Ohne API-Key (nur regelbasiert)
python tools/llm_code_guard.py

# Mit API-Key (mit KI-Analyse)
export OPENAI_API_KEY=sk-...
python tools/llm_code_guard.py
```

### GitHub Actions

Automatisch aktiv bei Pull Requests:
- `.github/workflows/ci_llm_guard.yml`

**Features:**
- Linting mit Ruff
- Type Checking mit MyPy
- Tests ausführen
- LLM-Guard Analysis

### Pre-Commit Hooks

```bash
# Installieren
pip install pre-commit
pre-commit install

# Manuell ausführen
pre-commit run --all-files
```

## C) Integration in bestehende App

### Metriken bereits integriert

Die Metriken sind automatisch aktiv, wenn:
1. `prometheus_client` installiert ist
2. FastAPI-Server läuft
3. Endpoint `/metrics` ist verfügbar

**Prüfen:**
```bash
curl http://localhost:8111/metrics
```

### Metriken im Workflow verwenden

```python
from backend.observability.metrics import (
    PARSE_OK, PARSE_WARN, PARSE_BAD,
    GEOCODE_OK, GEOCODE_FAILED,
    measure_route_opt, measure_csv_process
)

# Beispiel: CSV-Verarbeitung messen
with measure_csv_process():
    process_csv_file(file_path)

# Beispiel: Parsing-Ergebnisse
PARSE_OK.inc(ok_count)
PARSE_WARN.inc(warn_count)
PARSE_BAD.inc(bad_count)
```

## D) Konfiguration

### Umgebungsvariablen

```bash
# Address Corrections DB (für Metriken)
ADDRESS_CORRECTIONS_DB=data/address_corrections.sqlite3

# LLM Guard
OPENAI_API_KEY=sk-...  # Optional
GIT_BASE=origin/main    # Branch für Diff
```

### Prometheus Konfiguration

`monitoring/prometheus.yml` anpassen:
```yaml
- targets: ['host.docker.internal:8111']  # Port anpassen
```

### Grafana Dashboard

Dashboard JSON bearbeiten: `monitoring/dashboards/trafficapp.json`

## Troubleshooting

### Metriken erscheinen nicht

1. **Prüfe FastAPI läuft:**
   ```bash
   curl http://localhost:8111/metrics
   ```

2. **Prüfe Prometheus Target:**
   - Prometheus → Status → Targets
   - Sollte "UP" sein

3. **Prüfe Docker:**
   ```bash
   docker compose ps
   docker compose logs prometheus
   ```

### LLM Guard zeigt Fehler

1. **Ohne API-Key:** Normal - nur regelbasierte Prüfung
2. **Mit API-Key:** Prüfe `OPENAI_API_KEY` ist gesetzt
3. **Git-Fehler:** Prüfe dass in Git-Repository

### Pre-Commit zu langsam

LLM-Guard ist als `manual` Stage markiert und wird nicht bei jedem Commit ausgeführt.

**Manuell ausführen:**
```bash
pre-commit run llm-guard --all-files
```

## Nächste Schritte

### Erweitern

1. **Weitere Metriken:** In `backend/observability/metrics.py` hinzufügen
2. **Custom Dashboards:** JSON in Grafana erstellen und exportieren
3. **Alerts:** In Grafana konfigurieren (z.B. bei hoher Queue-Größe)

### Logs integrieren

Optional: Loki + Promtail für Log-Aggregation
- Gleiche Grafana-Oberfläche
- Korrelierbar mit Metriken

## Zusammenfassung

✅ **Grafana Monitoring**: Vollständig eingerichtet  
✅ **Metriken-Integration**: Automatisch aktiv  
✅ **LLM Code Guard**: Lokal und CI verfügbar  
✅ **Pre-Commit Hooks**: Optional installierbar  

Alles ist **optional** - die App funktioniert auch ohne Monitoring.

