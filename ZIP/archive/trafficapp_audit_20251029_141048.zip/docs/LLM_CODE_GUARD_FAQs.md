# LLM Code Guard - Häufige Fragen

## ❓ Wie funktioniert die KI Code-Überwachung?

### Kurzfassung

Der LLM Code Guard arbeitet in **zwei Stufen**:

1. **Regelbasiert** (schnell, kostenlos, immer aktiv):
   - Prüft ob kritische Dateien geändert wurden
   - Warnt bei fehlenden Tests
   - Erkennt Migration-Änderungen
   - **Dauert: < 1 Sekunde**

2. **KI-gestützt** (langsamer, kostet, optional):
   - Analysiert Code-Diff semantisch mit GPT-4o-mini
   - Findet Breaking Changes, Performance-Probleme, Security-Issues
   - **Dauert: 3-10 Sekunden**
   - **Kostet: ~$0.01 pro Analyse**

## 🔍 Was wird genau geprüft?

### Regelbasierte Prüfungen (automatisch)

✅ **Kritische Bereiche:**
- `backend/parsers/` - Parser-Änderungen
- `routes/tourplan_*` - Tour-API-Änderungen
- `backend/services/` - Service-Änderungen
- `services/geocode*` - Geocoding-Änderungen
- `repositories/` - Datenbank-Layer

✅ **Fehlende Tests:**
- Python-Dateien geändert → Gibt es Tests dazu?

✅ **Migration-Änderungen:**
- SQL-Dateien geändert → Warnung

### KI-Prüfungen (mit API-Key)

🔴 **Breaking Changes:**
- API-Signaturen geändert?
- Funktionen entfernt?
- Neue required Parameter?

🔴 **Fehlerbehandlung:**
- Try-Except fehlt?
- Unhandled Exceptions möglich?

🟡 **Performance:**
- N+1 Queries?
- Ineffiziente Loops?
- Fehlende Caching?

🟡 **Tests:**
- Neue Funktionen ohne Tests?
- Kritische Pfade ungetestet?

🟢 **Security:**
- SQL-Injection möglich?
- Unvalidierte Inputs?
- XSS-Risiken?

## 💰 Was kostet die KI-Analyse?

- **Modell:** GPT-4o-mini
- **Kosten pro Analyse:** ~$0.01 (sehr günstig)
- **Nur bei Pull Requests:** Nicht bei jedem Commit
- **Ohne API-Key:** Regelbasierte Prüfung läuft trotzdem (kostenlos)

## ⚡ Wie schnell ist es?

- **Regelbasiert:** < 1 Sekunde
- **Mit KI:** 3-10 Sekunden
- **Gesamt (mit KI):** ~5-10 Sekunden pro Pull Request

## 🎯 Wann wird es ausgeführt?

1. **GitHub Actions:** Automatisch bei jedem Pull Request
2. **Lokal:** Manuell mit `python tools/llm_code_guard.py`
3. **Pre-Commit:** Optional (aber zu langsam für jeden Commit)

## 🔧 Wie aktiviere ich die KI-Analyse?

### Option 1: Lokal

```bash
export OPENAI_API_KEY=sk-...
python tools/llm_code_guard.py
```

### Option 2: GitHub Actions

1. GitHub Repository → Settings → Secrets
2. `OPENAI_API_KEY` hinzufügen
3. Fertig - läuft automatisch bei PRs

### Option 3: Ohne API-Key

```bash
# Nur regelbasiert (kostenlos, schneller)
python tools/llm_code_guard.py
```

## 📋 Beispiel-Output

### Mit kritischen Änderungen:

```
[*] Analysiere 3 geaenderte Datei(en)...

[!] Kritische Bereiche: 2
   - routes/tourplan_match.py
   - services/geocode_fill.py

[?] Regelbasierte Findings:
   [!] KRITISCH: 2 Datei(en) in kritischen Bereichen geändert:
      - routes/tourplan_match.py
      - services/geocode_fill.py
   [!] WARNUNG: 3 Python-Datei(en) geändert ohne Tests:
      - routes/tourplan_match.py
      - services/geocode_fill.py

[AI] LLM-Analyse:
   Priority: HIGH
   - Neue Funktion parse_tour() ohne Error-Handling
   
   Priority: MEDIUM
   - Geocoding könnte Rate-Limiting benötigen
   
   Priority: LOW
   - Async könnte Performance verbessern

[!] KRITISCH: Aenderungen in kritischen Bereichen erkannt!
Exit code: 1
```

### Ohne kritische Änderungen:

```
[*] Analysiere 1 geaenderte Datei(en)...

[?] Regelbasierte Findings:
   [i] INFO: 1 Migration(s) geändert - bitte prüfen

Exit code: 0
```

## ❌ Was wenn der Guard "zu viel" findet?

**Tipps:**

1. **False Positives sind OK:** Guard ist als **Hilfe** gedacht, nicht als finales Urteil
2. **KI-Ergebnisse prüfen:** Nicht alles was KI findet ist wirklich ein Problem
3. **Kritische Bereiche anpassen:** Edit `CRITICAL_PATHS` in `tools/llm_code_guard.py`
4. **Prompt anpassen:** Spezifischer werden für dein Projekt

## 🔄 Wie integriert es sich in CI/CD?

**GitHub Actions:** Automatisch bei jedem Pull Request:

```yaml
- name: Run LLM Guard
  env:
    OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
  run: python tools/llm_code_guard.py
```

**Exit Code:**
- `0` = OK (oder nur Warnungen)
- `1` = Kritische Änderungen → CI kann fehlschlagen

## 🛠️ Kann ich es anpassen?

**Ja!** In `tools/llm_code_guard.py`:

1. **Kritische Pfade ändern:**
```python
CRITICAL_PATHS = [
    r"^backend/parsers/",
    # Deine eigenen Pfade...
]
```

2. **KI-Prompt anpassen:**
```python
PROMPT_SYSTEM = """Dein eigener Prompt..."""
```

3. **Git-Base ändern:**
```bash
export GIT_BASE=origin/develop
```

## 🎓 Zusammenfassung

**LLM Code Guard = Zwei-Stufen-Defense:**

✅ **Stufe 1:** Schnelle, kostenlose Regelprüfung (immer aktiv)  
✅ **Stufe 2:** Intelligente KI-Analyse (optional mit API-Key)  

**Resultat:** Du bekommst sofortige Warnungen **plus** tiefe semantische Analyse komplexer Probleme.

**Besonders nützlich für:**
- ✅ Automatische Code-Reviews bei Pull Requests
- ✅ Erkennung von Breaking Changes
- ✅ Warnung bei fehlenden Tests
- ✅ Security & Performance-Probleme finden

**Kosten:** Praktisch kostenlos (~$0.01 pro PR-Analyse)

