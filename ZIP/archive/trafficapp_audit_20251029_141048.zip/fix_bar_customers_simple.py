#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BAR-Kunden Fix - Behebt unvollständige Adressen
"""
import sys
sys.path.append('.')

def fix_bar_customers():
    """Behebt BAR-Kunden mit unvollständigen Adressen"""
    try:
        from backend.parsers.tour_plan_parser import parse_tour_plan_to_dict
        
        # Analysiere die aktuelle CSV-Datei
        csv_file = 'tourplaene/Tourenplan 30.09.2025.csv'
        tour_data = parse_tour_plan_to_dict(csv_file)
        
        # Finde BAR-Kunden mit unvollständigen Adressen
        bar_customers = []
        incomplete_bar = []
        
        for customer in tour_data.get('customers', []):
            if customer.get('bar_flag', False):
                bar_customers.append(customer)
                
                # Prüfe auf unvollständige Adresse
                if (not customer.get('street') or customer.get('street', '').lower() in ['nan', ''] or 
                    not customer.get('postal_code') or customer.get('postal_code', '').lower() in ['nan', ''] or
                    not customer.get('city') or customer.get('city', '').lower() in ['nan', '']):
                    incomplete_bar.append(customer)
        
        print(f'BAR-Kunden gesamt: {len(bar_customers)}')
        print(f'BAR-Kunden mit unvollständigen Adressen: {len(incomplete_bar)}')
        print('=' * 60)
        
        if incomplete_bar:
            print('LÖSUNG: Depot-Adresse für BAR-Kunden ohne Adresse')
            print('Depot: Stuttgarter Str. 33, 01189 Dresden')
            print()
            
            for customer in incomplete_bar:
                print(f'VORHER: {customer["name"]} (KdNr: {customer["customer_number"]})')
                print(f'  Adresse: "{customer.get("street", "")}"')
                print(f'  PLZ: "{customer.get("postal_code", "")}"')
                print(f'  Stadt: "{customer.get("city", "")}"')
                
                # Depot-Adresse zuweisen
                customer['street'] = 'Stuttgarter Str. 33'
                customer['postal_code'] = '01189'
                customer['city'] = 'Dresden'
                
                print(f'NACHHER: {customer["name"]} (KdNr: {customer["customer_number"]})')
                print(f'  Adresse: "{customer["street"]}"')
                print(f'  PLZ: "{customer["postal_code"]}"')
                print(f'  Stadt: "{customer["city"]}"')
                print()
        else:
            print('OK: Alle BAR-Kunden haben vollständige Adressen')
            
        # Zeige alle BAR-Kunden nach dem Fix
        print('ALLE BAR-KUNDEN NACH FIX:')
        print('=' * 40)
        for i, customer in enumerate(bar_customers, 1):
            print(f'{i}. {customer["name"]} (KdNr: {customer["customer_number"]})')
            print(f'   {customer["street"]}, {customer["postal_code"]} {customer["city"]}')
            
    except Exception as e:
        print(f'Fehler: {e}')
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    fix_bar_customers()
