# -*- coding: utf-8 -*-
"""
Test für Duplikat-Deduplizierung in VRP Clustering
"""

import sys
from pathlib import Path
import logging

# Projekt-Root zum Python-Pfad hinzufügen
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from services.vrp_clustering import cluster_and_route_tours, vrp_service

def test_duplicate_deduplication():
    """Test der Duplikat-Deduplizierung"""
    
    # Logging konfigurieren
    logging.basicConfig(level=logging.INFO)
    
    print("=" * 60)
    print("DUPLIKAT-DEDUPLIZIERUNG TEST")
    print("=" * 60)
    
    # Test-Daten: Kunde ruft 3x an (Morgens, Mittags, Abends)
    test_stops_with_duplicates = [
        # Kunde 1: 3x Anrufe für 07:00 Uhr
        {"id": "K001", "lat": 51.050407, "lon": 13.737262, "name": "Bäckerei Müller", 
         "customer_number": "12345", "street": "Hauptstraße 1", "postal_code": "01067", "city": "Dresden"},
        {"id": "K001", "lat": 51.050407, "lon": 13.737262, "name": "Bäckerei Müller", 
         "customer_number": "12345", "street": "Hauptstraße 1", "postal_code": "01067", "city": "Dresden"},
        {"id": "K001", "lat": 51.050407, "lon": 13.737262, "name": "Bäckerei Müller", 
         "customer_number": "12345", "street": "Hauptstraße 1", "postal_code": "01067", "city": "Dresden"},
        
        # Kunde 2: 2x Anrufe für 07:00 Uhr
        {"id": "K002", "lat": 51.060407, "lon": 13.747262, "name": "Café Schmidt", 
         "customer_number": "12346", "street": "Bahnhofstraße 5", "postal_code": "01069", "city": "Dresden"},
        {"id": "K002", "lat": 51.060407, "lon": 13.747262, "name": "Café Schmidt", 
         "customer_number": "12346", "street": "Bahnhofstraße 5", "postal_code": "01069", "city": "Dresden"},
        
        # Kunde 3: 1x Anruf für 07:00 Uhr
        {"id": "K003", "lat": 51.040407, "lon": 13.727262, "name": "Restaurant Weber", 
         "customer_number": "12347", "street": "Marktplatz 3", "postal_code": "01065", "city": "Dresden"},
        
        # Kunde 4: Nur Adresse, keine ID
        {"lat": 51.070407, "lon": 13.757262, "name": "Imbiss Klein", 
         "street": "Schulstraße 10", "postal_code": "01071", "city": "Dresden"},
        {"lat": 51.070407, "lon": 13.757262, "name": "Imbiss Klein", 
         "street": "Schulstraße 10", "postal_code": "01071", "city": "Dresden"},
    ]
    
    # Depot-Koordinaten
    depot = {"lat": 51.050407, "lon": 13.737262}
    
    print(f"Test-Daten:")
    print(f"- {len(test_stops_with_duplicates)} Stopps (mit Duplikaten)")
    print(f"- Depot: {depot['lat']}, {depot['lon']}")
    print()
    
    # Teste Deduplizierung direkt
    print("Teste Deduplizierung direkt:")
    deduplicated = vrp_service.deduplicate_customers(test_stops_with_duplicates)
    print(f"- Nach Deduplizierung: {len(deduplicated)} Stopps")
    print()
    
    # Zeige deduplizierte Stopps
    print("Deduplizierte Stopps:")
    for i, stop in enumerate(deduplicated):
        print(f"  {i+1}. {stop.get('name', 'Unbekannt')} "
              f"(ID: {stop.get('id', 'N/A')}, "
              f"KdNr: {stop.get('customer_number', 'N/A')})")
    print()
    
    # Teste VRP-Clustering mit Duplikaten
    print("Teste VRP-Clustering mit Duplikaten:")
    tours = cluster_and_route_tours(test_stops_with_duplicates, depot)
    
    print(f"\nErgebnis: {len(tours)} Touren erstellt")
    print()
    
    # Detaillierte Ergebnisse
    for i, tour in enumerate(tours):
        print(f"Tour {i+1}:")
        print(f"  Kunden: {len(tour)}")
        
        # Tour-Dauer berechnen
        duration, driving_time, service_time = vrp_service.calculate_tour_duration(tour, depot)
        print(f"  Gesamtdauer: {duration:.1f} Min")
        print(f"  Fahrzeit: {driving_time:.1f} Min")
        print(f"  Servicezeit: {service_time:.1f} Min")
        
        # Validierung
        result = vrp_service.validate_tour(tour, depot)
        if result.is_valid:
            print(f"  Status: VALID")
        else:
            print(f"  Status: INVALID - {result.violations}")
        
        print(f"  Route: ", end="")
        for j, stop in enumerate(tour):
            if j > 0:
                print(" -> ", end="")
            print(f"{stop.get('name', 'Unbekannt')}", end="")
        print()
        print()
    
    # Statistiken
    if tours:
        stats = vrp_service.get_clustering_stats(tours, depot)
        print("STATISTIKEN:")
        print(f"- Gesamte Touren: {stats['total_tours']}")
        print(f"- Gesamte Kunden: {stats['total_customers']}")
        print(f"- Durchschnitt Kunden/Tour: {stats['avg_customers_per_tour']:.1f}")
        print(f"- Gesamteinsatzzeit: {stats['total_work_time']:.1f} Min")
        
        if stats['work_time_violation']:
            print(f"- WARNUNG: Gesamteinsatzzeit überschritten!")
        else:
            print(f"- OK: Gesamteinsatzzeit OK")
    else:
        print("STATISTIKEN:")
        print("- Keine Touren erstellt")
    
    print()
    
    # Test verschiedene Deduplizierungs-Szenarien
    print("WEITERE DEDUPLIZIERUNGS-TESTS:")
    print()
    
    # Test 1: Nur Koordinaten-Duplikate
    print("Test 1: Koordinaten-Duplikate")
    coord_duplicates = [
        {"lat": 51.050407, "lon": 13.737262, "name": "Kunde A"},
        {"lat": 51.050407, "lon": 13.737262, "name": "Kunde B"},  # Gleiche Koordinaten
        {"lat": 51.050407, "lon": 13.737262, "name": "Kunde C"},  # Gleiche Koordinaten
    ]
    dedup_coord = vrp_service.deduplicate_customers(coord_duplicates)
    print(f"  {len(coord_duplicates)} Stopps -> {len(dedup_coord)} Stopps")
    print()
    
    # Test 2: Gemischte Duplikate
    print("Test 2: Gemischte Duplikate")
    mixed_duplicates = [
        {"id": "K001", "name": "Kunde 1", "lat": 51.05, "lon": 13.74},
        {"customer_number": "12345", "name": "Kunde 1", "lat": 51.05, "lon": 13.74},  # Gleicher Kunde, andere ID
        {"name": "Kunde 2", "lat": 51.06, "lon": 13.75},
        {"name": "Kunde 2", "lat": 51.06, "lon": 13.75},  # Duplikat
    ]
    dedup_mixed = vrp_service.deduplicate_customers(mixed_duplicates)
    print(f"  {len(mixed_duplicates)} Stopps -> {len(dedup_mixed)} Stopps")
    print()
    
    print("=" * 60)
    print("DUPLIKAT-DEDUPLIZIERUNG TEST ABGESCHLOSSEN")
    print("=" * 60)

if __name__ == "__main__":
    test_duplicate_deduplication()
