-- db/migrations/020_address_corrections.sql
-- Adress-Korrektur-Workflow: Korrekturtabelle und Warteschlange

PRAGMA foreign_keys = ON;
-- WAL-Modus für bessere Concurrency (reduziert "database is locked")
PRAGMA journal_mode = WAL;

-- Dauerhafte Adress-Korrekturen (manuell gepflegt)
CREATE TABLE IF NOT EXISTS address_corrections (
  key TEXT PRIMARY KEY,
  street_canonical TEXT NOT NULL,
  postal_code TEXT NOT NULL,
  city TEXT NOT NULL,
  country TEXT NOT NULL DEFAULT 'DE',
  lat REAL,
  lon REAL,
  source TEXT NOT NULL DEFAULT 'manual',
  confidence REAL NOT NULL DEFAULT 1.0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Warteschlange für "rote" (fehlgeschlagene) Adressen
CREATE TABLE IF NOT EXISTS address_exception_queue (
  key TEXT PRIMARY KEY,
  street TEXT NOT NULL,
  postal_code TEXT NOT NULL,
  city TEXT NOT NULL,
  country TEXT NOT NULL DEFAULT 'DE',
  last_seen TEXT NOT NULL DEFAULT (datetime('now')),
  times_seen INTEGER NOT NULL DEFAULT 1,
  note TEXT,
  status TEXT NOT NULL DEFAULT 'pending', -- pending|resolved|ignored
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Trigger für automatisches updated_at bei address_corrections
CREATE TRIGGER IF NOT EXISTS trg_address_corrections_updated
AFTER UPDATE ON address_corrections
FOR EACH ROW BEGIN
  UPDATE address_corrections SET updated_at = datetime('now') WHERE key = OLD.key;
END;

-- Trigger für automatisches updated_at bei address_exception_queue
CREATE TRIGGER IF NOT EXISTS trg_address_exception_queue_updated
AFTER UPDATE ON address_exception_queue
FOR EACH ROW BEGIN
  UPDATE address_exception_queue SET updated_at = datetime('now') WHERE key = OLD.key;
END;

-- Indizes für bessere Performance
CREATE INDEX IF NOT EXISTS ix_address_corrections_country ON address_corrections(country);
CREATE INDEX IF NOT EXISTS ix_address_exception_queue_status ON address_exception_queue(status);
CREATE INDEX IF NOT EXISTS ix_address_exception_queue_last_seen ON address_exception_queue(last_seen DESC);
CREATE INDEX IF NOT EXISTS ix_address_exception_queue_times_seen ON address_exception_queue(times_seen DESC);

