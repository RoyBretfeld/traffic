#!/usr/bin/env python3
"""
API Key Setup Script für FAMO TrafficApp

Verschlüsselt den OpenAI API Key für sichere Speicherung.
"""

import os
import sys
from pathlib import Path

# Füge das Projektverzeichnis zum Python-Pfad hinzu
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from services.secure_key_manager import encrypt_and_save_key

def main():
    print("FAMO TrafficApp - API Key Setup")
    print("=" * 50)
    
    # API Key aus der Cloud-Version
    api_key = "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"
    
    print(f"API Key gefunden: {api_key[:20]}...")
    print("Verschlüssele API Key...")
    
    try:
        # Verschlüssele und speichere den Key
        encrypt_and_save_key(api_key, "openai")
        
        print("API Key erfolgreich verschlüsselt und gespeichert!")
        print("Speicherort: config/secure_keys.json")
        print("Der Key ist jetzt sicher verschlüsselt gespeichert.")
        
        # Teste den Key
        print("\nTeste API Key...")
        from services.secure_key_manager import get_secure_key
        
        decrypted_key = get_secure_key("openai")
        if decrypted_key == api_key:
            print("API Key erfolgreich entschlüsselt!")
            print("LLM-Integration ist bereit!")
        else:
            print("Fehler beim Entschlüsseln des API Keys!")
            
    except Exception as e:
        print(f"Fehler beim Setup: {e}")
        return 1
    
    print("\nSetup abgeschlossen!")
    print("Nächste Schritte:")
    print("   1. Server starten: python start_server.py")
    print("   2. LLM-Features testen")
    print("   3. Unterrouten-Generierung aktivieren")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
