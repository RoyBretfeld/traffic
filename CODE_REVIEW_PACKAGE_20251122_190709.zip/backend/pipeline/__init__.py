"""Pipeline-Module für CSV-Ingest"""

